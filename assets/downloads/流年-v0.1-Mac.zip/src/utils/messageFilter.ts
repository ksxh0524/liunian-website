/**
 * 消息过滤工具
 * 用于隐藏技术细节输出，只显示用户关心的内容
 */

// 需要过滤的模式列表
const FILTER_PATTERNS = [
  // Skill 调用信息
  /\[Skill:[\s\S]*?\]/g,
  // Tool 工具输出
  /\[Tool:[\s\S]*?\]/g,
  // 系统提示
  /<system-reminder>[\s\S]*?<\/system-reminder>/g,
  // debug 代码块
  /```debug[\s\S]*?```/g,
  // 函数调用信息
  /<function_calls>[\s\S]*?<\/function_calls>/g,
  // 参数信息
  /<parameters>[\s\S]*?<\/parameters>/g,
  // 思考过程标签
  /<thinking>[\s\S]*?<\/thinking>/g,
  /<thought>[\s\S]*?<\/thought>/g,
];

/**
 * 过滤消息内容，移除技术细节
 * @param content 原始消息内容
 * @returns 过滤后的消息内容
 */
export function filterMessageContent(content: string): string {
  if (!content) return content;

  let filtered = content;

  // 应用所有过滤模式
  for (const pattern of FILTER_PATTERNS) {
    filtered = filtered.replace(pattern, '');
  }

  // 清理多余的空行（超过2个连续空行）
  filtered = filtered.replace(/\n{3,}/g, '\n\n');

  // 清理首尾空白
  filtered = filtered.trim();

  // 如果过滤后为空，返回原始内容
  return filtered || content;
}

/**
 * 检查消息是否应该被完全隐藏
 * @param content 消息内容
 * @returns 是否应该隐藏
 */
export function shouldHideMessage(content: string): boolean {
  if (!content) return false;

  // 如果消息只包含技术细节，则隐藏
  const filtered = filterMessageContent(content);
  return filtered.trim().length === 0;
}

/**
 * 检查内容是否包含技术细节
 * @param content 消息内容
 * @returns 是否包含技术细节
 */
export function hasTechnicalContent(content: string): boolean {
  if (!content) return false;

  return FILTER_PATTERNS.some(pattern => pattern.test(content));
}
