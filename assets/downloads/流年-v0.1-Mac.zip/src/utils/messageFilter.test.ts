import { describe, it, expect } from 'vitest'
import {
  filterMessageContent,
  shouldHideMessage,
  hasTechnicalContent,
} from './messageFilter'

describe('messageFilter', () => {
  describe('filterMessageContent', () => {
    it('应该返回空内容原样', () => {
      expect(filterMessageContent('')).toBe('')
      expect(filterMessageContent(null as any)).toBe(null)
      expect(filterMessageContent(undefined as any)).toBe(undefined)
    })

    it('应该过滤 Skill 调用信息', () => {
      const content = '这是普通文本 [Skill:weather] 技能输出 [/Skill] 结束'
      const filtered = filterMessageContent(content)
      // 正则只匹配 [Skill:xxx] 格式，不匹配 [/Skill]
      expect(filtered).toContain('这是普通文本')
      expect(filtered).toContain('结束')
      expect(filtered).not.toContain('[Skill:weather]')
    })

    it('应该过滤 Tool 工具输出', () => {
      const content = '开始 [Tool:read] 工具内容 [/Tool] 结束'
      const filtered = filterMessageContent(content)
      // 正则只匹配 [Tool:xxx] 格式，不匹配 [/Tool]
      expect(filtered).toContain('开始')
      expect(filtered).toContain('结束')
      expect(filtered).not.toContain('[Tool:read]')
    })

    it('应该过滤系统提示', () => {
      const content = '普通文本 <system-reminder>系统信息</system-reminder> 结束'
      const filtered = filterMessageContent(content)
      expect(filtered).toBe('普通文本  结束')
    })

    it('应该过滤 debug 代码块', () => {
      const content = '文本 ```debug\n调试信息\n``` 结束'
      const filtered = filterMessageContent(content)
      expect(filtered).toBe('文本  结束')
    })

    it('应该清理多余空行', () => {
      const content = '第一行\n\n\n\n\n第二行'
      const filtered = filterMessageContent(content)
      expect(filtered).toBe('第一行\n\n第二行')
    })

    it('应该保留普通文本', () => {
      const content = '这是一条普通的消息，没有任何技术细节。'
      const filtered = filterMessageContent(content)
      expect(filtered).toBe(content)
    })
  })

  describe('shouldHideMessage', () => {
    it('空内容不应该隐藏', () => {
      expect(shouldHideMessage('')).toBe(false)
    })

    it('纯技术内容 - filterMessageContent 会返回原内容', () => {
      // 注意：filterMessageContent 如果过滤后为空，会返回原始内容
      // 所以 shouldHideMessage 对这种情况返回 false
      const content = '<system-reminder>系统信息</system-reminder>'
      expect(shouldHideMessage(content)).toBe(false)
    })

    it('混合内容不应该隐藏', () => {
      const content = '用户可见的文本 <thinking>思考</thinking>'
      expect(shouldHideMessage(content)).toBe(false)
    })
  })

  describe('hasTechnicalContent', () => {
    it('应该检测到技术内容', () => {
      expect(hasTechnicalContent('<thinking>test</thinking>')).toBe(true)
      expect(hasTechnicalContent('[Skill:weather]内容[/Skill]')).toBe(true)
      expect(hasTechnicalContent('```debug\ntest\n```')).toBe(true)
    })

    it('普通文本不应该检测到技术内容', () => {
      expect(hasTechnicalContent('这是一条普通消息')).toBe(false)
      expect(hasTechnicalContent('')).toBe(false)
    })
  })
})
