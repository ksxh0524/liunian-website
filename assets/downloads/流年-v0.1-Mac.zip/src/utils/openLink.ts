/**
 * 在外部浏览器中打开链接
 * 使用 Tauri 的 shell 插件来安全地打开外部链接
 */
export async function openLink(url: string): Promise<void> {
  try {
    // 动态导入 Tauri shell 模块
    const { open } = await import('@tauri-apps/plugin-shell');
    await open(url);
  } catch (error) {
    // 如果 Tauri 不可用（如在浏览器中开发），使用 window.open
    console.warn('Tauri shell not available, falling back to window.open:', error);
    window.open(url, '_blank', 'noopener,noreferrer');
  }
}

/**
 * 创建一个点击处理器，用于打开外部链接
 */
export function handleExternalClick(e: React.MouseEvent<HTMLAnchorElement>, url: string): void {
  e.preventDefault();
  openLink(url);
}
