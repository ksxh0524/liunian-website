import { useState, useCallback, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { Sidebar } from './components/Sidebar';
import { ChatPage, type ChatSession } from './pages/ChatPage';
import { MemoryPage } from './pages/MemoryPage';
import { OpenClawIntegration } from './pages/OpenClawIntegration';
import { SettingsPage } from './pages/SettingsPage';
import { TutorialPage } from './pages/TutorialPage';
import './App.css';

function AppContent() {
  const navigate = useNavigate();
  
  // 会话管理
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);

  // 从 localStorage 加载会话
  useEffect(() => {
    const savedSessions = localStorage.getItem('chat-sessions');
    const savedCurrentId = localStorage.getItem('current-session-id');
    
    if (savedSessions) {
      try {
        const parsed = JSON.parse(savedSessions);
        setSessions(parsed);
        if (savedCurrentId && parsed.find((s: ChatSession) => s.id === savedCurrentId)) {
          setCurrentSessionId(savedCurrentId);
        }
      } catch (e) {
        console.error('Failed to load sessions:', e);
      }
    }
  }, []);

  // 保存会话到 localStorage
  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem('chat-sessions', JSON.stringify(sessions));
    } else {
      localStorage.removeItem('chat-sessions');
    }
    if (currentSessionId) {
      localStorage.setItem('current-session-id', currentSessionId);
    } else {
      localStorage.removeItem('current-session-id');
    }
  }, [sessions, currentSessionId]);

  // 创建新会话（只设置 currentSessionId，不添加到 sessions 列表）
  const handleNewSession = useCallback(() => {
    setCurrentSessionId(null);
  }, []);

  // 选择会话
  const handleSelectSession = useCallback((id: string) => {
    setCurrentSessionId(id);
  }, []);

  // 删除会话
  const handleDeleteSession = useCallback((id: string) => {
    if (confirm('确定要删除这个对话吗？')) {
      setSessions(prev => prev.filter(s => s.id !== id));
      if (currentSessionId === id) {
        setCurrentSessionId(null);
      }
    }
  }, [currentSessionId]);

  // 创建会话（当发送第一条消息时调用）
  const handleCreateSession = useCallback((session: ChatSession) => {
    setSessions(prev => [session, ...prev]);
    setCurrentSessionId(session.id);
  }, []);

  // 更新会话
  const handleSessionUpdate = useCallback((updatedSession: ChatSession) => {
    setSessions(prev => {
      const exists = prev.find(s => s.id === updatedSession.id);
      if (!exists) {
        // 如果会话不存在，添加到列表
        return [updatedSession, ...prev].sort((a, b) => b.updatedAt - a.updatedAt);
      }
      // 如果会话存在，更新它
      return prev.map(s => s.id === updatedSession.id ? updatedSession : s)
        .sort((a, b) => b.updatedAt - a.updatedAt);
    });
  }, []);

  // 清空会话
  const handleClearSession = useCallback((sessionId: string) => {
    setSessions(prev => 
      prev.map(s => 
        s.id === sessionId 
          ? { ...s, messages: [], title: '新对话', updatedAt: Date.now() }
          : s
      )
    );
  }, []);

  // 打开设置
  const handleOpenSettings = useCallback(() => {
    navigate('/settings');
  }, [navigate]);

  // 获取当前会话
  const currentSession = sessions.find(s => s.id === currentSessionId) || null;

  return (
    <div className="app">
      {/* 侧边栏 */}
      <Sidebar
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={handleSelectSession}
        onNewSession={handleNewSession}
        onDeleteSession={handleDeleteSession}
        onOpenSettings={handleOpenSettings}
      />

      {/* 主内容区 */}
      <main className="main-content">
        <Routes>
          <Route 
            path="/" 
            element={
              <ChatPage
                currentSession={currentSession}
                onCreateSession={handleCreateSession}
                onSessionUpdate={handleSessionUpdate}
                onNewSession={handleNewSession}
                onClearSession={handleClearSession}
              />
            } 
          />
          <Route path="/memory" element={<MemoryPage />} />
          <Route path="/openclaw" element={<OpenClawIntegration />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/tutorial" element={<TutorialPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;