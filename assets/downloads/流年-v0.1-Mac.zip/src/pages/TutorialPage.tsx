import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ExternalLink, Copy, Check } from 'lucide-react';
import './Tutorial.css';

interface TutorialStep {
  title: string;
  description: string;
  image: string;
  details?: string[];
}

const TUTORIAL_STEPS: TutorialStep[] = [
  {
    title: '创建飞书应用',
    description: '访问飞书开放平台，创建一个自建应用',
    image: '/images/tutorial/01-create-app.png',
    details: [
      '访问飞书开放平台：https://open.feishu.cn/app',
      '点击「创建企业自建应用」按钮',
      '填写应用名称和描述，例如「流年 AI 助手」',
      '创建成功后进入应用详情页'
    ]
  },
  {
    title: '获取应用凭证',
    description: '复制 App ID 和 App Secret，用于应用配置',
    image: '/images/tutorial/02-app-credentials.png',
    details: [
      '在应用详情页左侧菜单点击「凭证与基础信息」',
      '找到「App ID」和「App Secret」',
      'App ID 以「cli_」开头',
      'App Secret 点击「查看」后显示',
      '将这两个值填入流年应用的设置页面'
    ]
  },
  {
    title: '配置权限（一）',
    description: '为应用开通消息接收相关权限',
    image: '/images/tutorial/03-permissions-1.png',
    details: [
      '在左侧菜单点击「权限管理」',
      '搜索并开通以下权限：',
      '• 获取与更新用户信息',
      '• 获取用户基本信息',
      '• 获取用户统一 ID',
      '• 获取用户手机号'
    ]
  },
  {
    title: '配置权限（二）',
    description: '开通消息发送和接收权限',
    image: '/images/tutorial/04-permissions-2.png',
    details: [
      '继续搜索并开通消息相关权限：',
      '• 获取与发送单聊、群聊消息',
      '• 接收群聊消息',
      '• 以应用身份读取群聊消息',
      '• 获取群组信息'
    ]
  },
  {
    title: '创建应用版本',
    description: '创建应用版本并申请发布',
    image: '/images/tutorial/05-version-1.png',
    details: [
      '在左侧菜单点击「版本管理与发布」',
      '点击「创建版本」按钮',
      '填写版本号，例如「1.0.0」',
      '填写版本更新说明'
    ]
  },
  {
    title: '申请发布',
    description: '提交版本审核申请',
    image: '/images/tutorial/06-version-2.png',
    details: [
      '确认应用信息无误',
      '点击「申请发布」',
      '选择可用范围（全员可见或指定人员）'
    ]
  },
  {
    title: '等待审核',
    description: '等待管理员审核通过',
    image: '/images/tutorial/07-version-3.png',
    details: [
      '提交后等待企业管理员审核',
      '审核通过后应用即可使用',
      '可以联系管理员加急审核'
    ]
  },
  {
    title: '配置事件订阅',
    description: '启用消息接收功能',
    image: '/images/tutorial/08-version-4.png',
    details: [
      '在左侧菜单点击「事件订阅」',
      '配置请求网址（需使用内网穿透或公网地址）',
      '添加事件：接收消息 (im.message.receive_v1)',
      '保存配置'
    ]
  }
];

// 飞书权限配置 - 用户可直接复制
const FEISHU_PERMISSIONS = [
  { key: 'contact:user.base:readonly', name: '获取用户基本信息' },
  { key: 'contact:user:readonly', name: '获取用户统一 ID' },
  { key: 'contact:user.phone:readonly', name: '获取用户手机号' },
  { key: 'im:chat', name: '获取与发送单聊、群聊消息' },
  { key: 'im:chat:readonly', name: '获取群组信息' },
  { key: 'im:message', name: '发送消息' },
  { key: 'im:message:send_as_bot', name: '以应用身份发消息' },
  { key: 'im:message:readonly', name: '读取消息' },
  { key: 'im:resource', name: '上传与下载图片、文件等资源' }
];

// 用于导入的权限 JSON 格式
const FEISHU_PERMISSIONS_JSON = {
  "permissions": FEISHU_PERMISSIONS.map(p => p.key)
};

export const TutorialPage: React.FC = () => {
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(JSON.stringify(FEISHU_PERMISSIONS_JSON, null, 2));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('复制失败:', err);
    }
  };

  const handleBackToSettings = () => {
    navigate('/', { state: { openSettings: true, activeTab: 'feishu' } });
  };

  return (
    <div className="tutorial-page">
      <div className="tutorial-header">
        <button className="back-link" onClick={handleBackToSettings}>
          <ArrowLeft size={16} />
          返回设置
        </button>
        <h1>飞书机器人配置教程</h1>
      </div>

      <div className="tutorial-content">
        {TUTORIAL_STEPS.map((step, index) => (
          <div key={index} className="tutorial-step">
            <div className="step-number">{index + 1}</div>
            <div className="step-content">
              <h2>{step.title}</h2>
              <p>{step.description}</p>
              {step.details && (
                <ul>
                  {step.details.map((detail, i) => (
                    <li key={i}>{detail}</li>
                  ))}
                </ul>
              )}
              <div className="tutorial-image">
                <img
                  src={step.image}
                  alt={step.title}
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        ))}

        {/* 权限配置 JSON 区域 */}
        <div className="permission-json-section">
          <h2>
            <span className="step-number">9</span>
            一键导入权限配置
          </h2>
          <p className="section-desc">
            复制下方 JSON，在飞书开放平台的「权限管理」页面点击「导入权限配置」即可快速开通所有权限。
          </p>
          
          <div className="permission-list">
            <h4>包含的权限：</h4>
            <ul>
              {FEISHU_PERMISSIONS.map((p, i) => (
                <li key={i}>
                  <code>{p.key}</code>
                  <span className="permission-name">{p.name}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="code-block">
            <div className="code-header">
              <span>权限配置 JSON（点击复制）</span>
              <button className="copy-btn" onClick={handleCopy}>
                {copied ? <Check size={14} /> : <Copy size={14} />}
                {copied ? '已复制' : '复制 JSON'}
              </button>
            </div>
            <pre>{JSON.stringify(FEISHU_PERMISSIONS_JSON, null, 2)}</pre>
          </div>

          <div className="tip">
            <strong>💡 使用方法：</strong>
            <ol>
              <li>点击上方「复制 JSON」按钮</li>
              <li>打开飞书开放平台 → 你的应用 → 权限管理</li>
              <li>点击页面上的「导入权限配置」或「批量添加」按钮</li>
              <li>粘贴 JSON 并确认</li>
              <li>完成后创建新版本并发布</li>
            </ol>
          </div>
        </div>

        <div className="tutorial-note">
          <h3>注意事项</h3>
          <ul>
            <li>App Secret 只会显示一次，请妥善保存</li>
            <li>权限配置后需要重新创建版本才能生效</li>
            <li>事件订阅需要公网可访问的地址，可使用内网穿透工具</li>
            <li>机器人服务启动后，会自动使用 WebSocket 长连接接收消息</li>
          </ul>
        </div>

        <div className="tutorial-links">
          <h3>相关链接</h3>
          <div className="link-buttons">
            <button
              className="btn btn-primary"
              onClick={() => window.open('https://open.feishu.cn/app', '_blank')}
            >
              <ExternalLink size={14} />
              飞书开放平台
            </button>
            <button
              className="btn btn-secondary"
              onClick={handleBackToSettings}
            >
              返回设置
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TutorialPage;