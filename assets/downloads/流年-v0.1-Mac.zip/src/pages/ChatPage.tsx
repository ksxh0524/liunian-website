import { useState, useRef, useEffect } from 'react';
import { Send, Trash2, Plus, ChevronDown, Search, RefreshCw } from 'lucide-react';
import { chat, getSettings, getAvailableModels } from '../services/api';
import './ChatPage.css';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
  updatedAt: number;
}

interface ChatPageProps {
  currentSession: ChatSession | null;
  onCreateSession: (session: ChatSession) => void;
  onSessionUpdate: (session: ChatSession) => void;
  onNewSession: () => void;
  onClearSession: (sessionId: string) => void;
}

interface Model {
  id: string;
  name: string;
  provider: string;
}

// 示例提示
const EXAMPLE_PROMPTS = [
  {
    title: '帮我写代码',
    description: '用 Python 写一个快速排序算法',
  },
  {
    title: '解释概念',
    description: '什么是机器学习中的过拟合？',
  },
  {
    title: '创意写作',
    description: '帮我写一个关于太空探索的短篇故事',
  },
  {
    title: '头脑风暴',
    description: '帮我头脑风暴一些创业点子',
  },
];

export function ChatPage({ currentSession, onCreateSession, onSessionUpdate, onNewSession, onClearSession }: ChatPageProps) {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [currentModel, setCurrentModel] = useState('');
  const [showModelSelector, setShowModelSelector] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const modelSelectorRef = useRef<HTMLDivElement>(null);
  
  // 模型列表
  const [models, setModels] = useState<Model[]>([]);
  const [modelsLoading, setModelsLoading] = useState(false);
  const [modelSearch, setModelSearch] = useState('');

  // 加载默认模型和模型列表
  useEffect(() => {
    const loadSettings = async () => {
      try {
        const settings = await getSettings();
        // 后端返回驼峰格式
        if (settings.model) {
          setCurrentModel(settings.model);
        }
      } catch (error) {
        console.error('Failed to load settings:', error);
      }
    };
    loadSettings();
  }, []);

  // 点击外部关闭模型选择器
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (modelSelectorRef.current && !modelSelectorRef.current.contains(event.target as Node)) {
        setShowModelSelector(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // 自动调整 textarea 高度
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 200) + 'px';
    }
  }, [input]);

  // 自动滚动到底部
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentSession?.messages, loading]);

  // 发送消息
  const handleSend = async () => {
    if (!input.trim() || loading) return;

    let session = currentSession;
    
    // 如果没有当前会话，创建一个新的
    if (!session) {
      const newSession: ChatSession = {
        id: `session-${Date.now()}`,
        title: '新对话',
        messages: [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      session = newSession;
      onCreateSession(newSession);
    }

    const userMessage: Message = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: input.trim(),
      timestamp: Date.now(),
    };

    const updatedMessages = [...session.messages, userMessage];
    const updatedSession = {
      ...session,
      messages: updatedMessages,
      updatedAt: Date.now(),
      title: session.messages.length === 0 
        ? input.trim().slice(0, 20) + (input.trim().length > 20 ? '...' : '')
        : session.title,
    };

    onSessionUpdate(updatedSession);
    setInput('');
    setLoading(true);

    try {
      const response = await chat(input.trim(), session.id, currentModel);
      
      const assistantMessage: Message = {
        id: `msg-${Date.now()}`,
        role: 'assistant',
        content: response.response,
        timestamp: Date.now(),
      };

      onSessionUpdate({
        ...updatedSession,
        messages: [...updatedMessages, assistantMessage],
        updatedAt: Date.now(),
      });
    } catch (error) {
      console.error('Chat error:', error);
      const errorMessage: Message = {
        id: `msg-${Date.now()}`,
        role: 'assistant',
        content: `抱歉，发生了错误：${error instanceof Error ? error.message : '未知错误'}`,
        timestamp: Date.now(),
      };
      onSessionUpdate({
        ...updatedSession,
        messages: [...updatedMessages, errorMessage],
        updatedAt: Date.now(),
      });
    } finally {
      setLoading(false);
    }
  };

  // 清空对话
  const handleClear = () => {
    if (currentSession && confirm('确定要清空当前对话吗？')) {
      onClearSession(currentSession.id);
    }
  };

  // 使用示例提示
  const handleUseExample = (description: string) => {
    setInput(description);
    textareaRef.current?.focus();
  };

  // 按键处理
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // 加载模型列表
  const loadModels = async () => {
    setModelsLoading(true);
    try {
      const modelList = await getAvailableModels();
      setModels(modelList);
    } catch (error) {
      console.error('Failed to load models:', error);
    } finally {
      setModelsLoading(false);
    }
  };

  // 当打开模型选择器时加载模型
  useEffect(() => {
    if (showModelSelector && models.length === 0) {
      loadModels();
    }
  }, [showModelSelector]);

  // 筛选模型
  const filteredModels = models.filter(m => 
    m.name.toLowerCase().includes(modelSearch.toLowerCase()) ||
    m.id.toLowerCase().includes(modelSearch.toLowerCase()) ||
    m.provider.toLowerCase().includes(modelSearch.toLowerCase())
  );

  // 获取选中的模型名称
  const selectedModelName = models.find(m => m.id === currentModel)?.name || currentModel || '选择模型';

  // 格式化消息内容（简单的代码块处理）
  const formatMessage = (content: string) => {
    // 检测代码块
    const parts = content.split(/(```[\s\S]*?```)/g);
    
    return parts.map((part, index) => {
      if (part.startsWith('```') && part.endsWith('```')) {
        const code = part.slice(3, -3).trim();
        const lines = code.split('\n');
        const language = lines[0] && !lines[0].includes(' ') ? lines[0] : '';
        const codeContent = language ? lines.slice(1).join('\n') : code;
        
        return (
          <div key={index} className="code-block">
            {language && <div className="code-language">{language}</div>}
            <pre><code>{codeContent}</code></pre>
          </div>
        );
      }
      
      // 处理行内代码
      return part.split(/(`[^`]+`)/g).map((inlinePart, inlineIndex) => {
        if (inlinePart.startsWith('`') && inlinePart.endsWith('`')) {
          return <code key={`${index}-${inlineIndex}`} className="inline-code">{inlinePart.slice(1, -1)}</code>;
        }
        return <span key={`${index}-${inlineIndex}`}>{inlinePart}</span>;
      });
    });
  };

  const messages = currentSession?.messages || [];
  const isEmpty = messages.length === 0;

  return (
    <div className="chat-page">
      {/* 模型选择器 - 左上角 */}
      <div className="model-selector-container" ref={modelSelectorRef}>
        <button
          className="model-selector-button"
          onClick={() => setShowModelSelector(!showModelSelector)}
        >
          <span className="logo-icon">流</span>
          <span>{selectedModelName}</span>
          <ChevronDown size={16} />
        </button>
        
        {showModelSelector && (
          <div className="model-selector-dropdown">
            <div className="model-search">
              <Search size={16} />
              <input
                type="text"
                value={modelSearch}
                onChange={e => setModelSearch(e.target.value)}
                placeholder="搜索模型..."
                autoFocus
              />
              {modelsLoading && <RefreshCw size={16} className="spin" />}
            </div>
            
            <div className="model-list">
              {filteredModels.length === 0 && !modelsLoading && (
                <div className="no-models">
                  {models.length === 0 ? '请先在设置中配置 API' : '没有匹配的模型'}
                </div>
              )}
              
              {filteredModels.map(model => (
                <button
                  key={model.id}
                  className={`model-option ${currentModel === model.id ? 'selected' : ''}`}
                  onClick={() => {
                    setCurrentModel(model.id);
                    setShowModelSelector(false);
                  }}
                >
                  <div className="model-option-name">{model.name}</div>
                  <div className="model-option-desc">{model.provider}</div>
                </button>
              ))}
            </div>
            
            <button 
              className="refresh-models-btn"
              onClick={loadModels}
              disabled={modelsLoading}
            >
              <RefreshCw size={14} className={modelsLoading ? 'spin' : ''} />
              刷新模型列表
            </button>
          </div>
        )}
      </div>

      {/* 消息区域 */}
      <div className="chat-messages">
        {isEmpty ? (
          <div className="welcome-screen">
            <div className="welcome-content">
              <div className="welcome-logo">
                <span className="logo-large">流</span>
              </div>
              <h1 className="welcome-title">有什么可以帮你的？</h1>
              <p className="welcome-subtitle">与 AI 助手开始对话</p>
              
              <div className="example-cards">
                {EXAMPLE_PROMPTS.map((prompt, index) => (
                  <button
                    key={index}
                    className="example-card"
                    onClick={() => handleUseExample(prompt.description)}
                  >
                    <div className="example-title">{prompt.title}</div>
                    <div className="example-description">{prompt.description}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="messages-list">
            {messages.map((msg) => (
              <div key={msg.id} className={`message ${msg.role}`}>
                <div className="message-container">
                  <div className="message-avatar">
                    {msg.role === 'user' ? (
                      <div className="avatar user-avatar">👤</div>
                    ) : (
                      <div className="avatar ai-avatar">流</div>
                    )}
                  </div>
                  <div className="message-content">
                    <div className="message-text">
                      {formatMessage(msg.content)}
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            {loading && (
              <div className="message assistant">
                <div className="message-container">
                  <div className="message-avatar">
                    <div className="avatar ai-avatar">流</div>
                  </div>
                  <div className="message-content">
                    <div className="message-loading">
                      <span className="loading-dot"></span>
                      <span className="loading-dot"></span>
                      <span className="loading-dot"></span>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* 输入区域 */}
      <div className="chat-input-container">
        <div className="input-wrapper">
          {!isEmpty && (
            <div className="input-actions-top">
              <button 
                className="action-btn new-chat-btn" 
                onClick={onNewSession}
                title="新对话"
              >
                <Plus size={16} />
                新对话
              </button>
              <button 
                className="action-btn clear-btn" 
                onClick={handleClear}
                title="清空对话"
              >
                <Trash2 size={16} />
              </button>
            </div>
          )}
          
          <div className="input-box">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="输入消息..."
              disabled={loading}
              rows={1}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || loading}
              className="send-button"
              title="发送"
            >
              <Send size={18} />
            </button>
          </div>
          
          <div className="input-hint">
            按 Enter 发送，Shift + Enter 换行
          </div>
        </div>
      </div>
    </div>
  );
}