import { useState, useEffect, useRef } from 'react';
import { Check, X, RefreshCw, Search, Loader2, ExternalLink, Play, Square, AlertCircle, Copy, FileJson, Database, FileText } from 'lucide-react';
import { getSettings, updateSettings, getAvailableModels, getModelsFromBackend, getFeishuStatus, startFeishuBot } from '../services/api';
import './SettingsPage.css';

interface Model {
  id: string;
  name: string;
  provider: string;
}

const DEFAULT_BASE_URL = 'https://api.n1n.ai';
const INVITE_LINK = 'https://api.n1n.ai/register?aff=ieRd';

export function SettingsPage() {
  // API 配置
  const [apiKey, setApiKey] = useState('');
  const [hasApiKey, setHasApiKey] = useState(false); // 是否有保存的 apiKey
  const [baseUrl, setBaseUrl] = useState(DEFAULT_BASE_URL);
  const [defaultModel, setDefaultModel] = useState('');
  
  // 飞书配置
  const [feishuAppId, setFeishuAppId] = useState('');
  const [feishuAppSecret, setFeishuAppSecret] = useState('');
  const [feishuHasSecret, setFeishuHasSecret] = useState(false); // 是否有保存的 secret
  const [feishuStatus, setFeishuStatus] = useState('Stopped');
  const [feishuStarting, setFeishuStarting] = useState(false);
  const [feishuStopping, setFeishuStopping] = useState(false);
  const [feishuError, setFeishuError] = useState<string | null>(null);
  
  // 导出状态
  const [exporting, setExporting] = useState<string | null>(null); // 'json' | 'sqlite' | 'markdown' | null
  const [exportError, setExportError] = useState<string | null>(null);
  
  // 测试状态
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<'success' | 'error' | null>(null);
  const [testMessage, setTestMessage] = useState('');
  
  // 模型列表
  const [models, setModels] = useState<Model[]>([]);
  const [modelsLoading, setModelsLoading] = useState(false);
  const [modelSearch, setModelSearch] = useState('');
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const modelSelectorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadSettings();
  }, []);

  // 点击外部关闭模型选择器
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (modelSelectorRef.current && !modelSelectorRef.current.contains(event.target as Node)) {
        setShowModelDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const loadSettings = async () => {
    try {
      const settings = await getSettings();
      // 后端返回格式：{ apiKey, baseUrl, model, hasApiKey, feishu: { appId, hasSecret } }
      if (settings.baseUrl) setBaseUrl(settings.baseUrl);
      if (settings.model) setDefaultModel(settings.model);
      
      // 标记是否有保存的 apiKey
      if (settings.hasApiKey) {
        setHasApiKey(true);
        // 设置占位符，让用户知道已配置
        setApiKey('••••••••••••••••');
      }
      
      if (settings.feishu?.appId) {
        setFeishuAppId(settings.feishu.appId);
      }
      // 标记是否有保存的 secret
      if (settings.feishu?.hasSecret) {
        setFeishuHasSecret(true);
      }
      
      // 如果有 apiKey，加载模型列表
      if (settings.hasApiKey) {
        loadModels(); // 使用后端接口（不需要传参数）
      }
      
      loadFeishuStatus();
    } catch (error) {
      console.error('Failed to load settings:', error);
    }
  };

  const loadModels = async (url?: string, key?: string) => {
    setModelsLoading(true);
    try {
      let modelList;
      if (key) {
        // 如果传入了 apiKey，直接调用外部 API
        modelList = await getAvailableModels(url || baseUrl, key);
      } else {
        // 否则调用后端（使用保存的 apiKey）
        modelList = await getModelsFromBackend();
      }
      setModels(modelList);
    } catch (error) {
      console.error('Failed to load models:', error);
    } finally {
      setModelsLoading(false);
    }
  };

  const loadFeishuStatus = async () => {
    try {
      const result = await getFeishuStatus();
      const status = result.status || 'Stopped';
      // 只有在明确的状态才更新，避免误判
      if (['Running', 'Starting', 'Error', 'Stopped'].includes(status)) {
        setFeishuStatus(status);
      }
    } catch (e) {
      console.error('获取飞书状态失败:', e);
      // 失败时保持默认状态，不设置为 Error
    }
  };

  const testConnection = async () => {
    if (!baseUrl) {
      setTestResult('error');
      setTestMessage('请填写 Base URL');
      return;
    }
    
    setTesting(true);
    setTestResult(null);
    
    try {
      // 如果用户输入了新的 apiKey，使用新的；否则使用后端保存的
      const keyToUse = apiKey && apiKey !== '••••••••••••••••' ? apiKey : undefined;
      let modelList;
      
      if (keyToUse) {
        // 使用新的 apiKey 测试
        modelList = await getAvailableModels(baseUrl, keyToUse);
        // 测试成功后保存
        await updateSettings({ baseUrl, apiKey: keyToUse });
      } else {
        // 使用后端保存的 apiKey 测试
        modelList = await getModelsFromBackend();
        await updateSettings({ baseUrl });
      }
      
      if (modelList.length > 0) {
        setTestResult('success');
        setTestMessage(`连接成功！发现 ${modelList.length} 个模型（已保存）`);
        setModels(modelList);
        setHasApiKey(true);
      } else {
        setTestResult('error');
        setTestMessage('连接成功，但未发现可用模型');
      }
    } catch (error: any) {
      setTestResult('error');
      setTestMessage('连接失败: ' + (error.message || '未知错误'));
    } finally {
      setTesting(false);
    }
  };

  const autoSave = async (newSettings: any) => {
    // 立即保存，不要延迟
    try {
      await updateSettings(newSettings);
    } catch (error) {
      console.error('自动保存失败:', error);
    }
  };

  const handleBaseUrlChange = (value: string) => {
    setBaseUrl(value);
    autoSave({ baseUrl: value });
  };

  const handleApiKeyChange = (value: string) => {
    setApiKey(value);
    setHasApiKey(true); // 用户输入了新的 apiKey
    autoSave({ apiKey: value });
  };

  const handleModelChange = (modelId: string) => {
    setDefaultModel(modelId);
    setShowModelDropdown(false);
    autoSave({ model: modelId });
  };

  const handleFeishuAppIdChange = (value: string) => {
    setFeishuAppId(value);
  };

  const handleFeishuSecretChange = (value: string) => {
    setFeishuAppSecret(value);
  };

  const saveFeishuConfig = async () => {
    if (!feishuAppId || !feishuAppSecret) {
      setFeishuError('请填写飞书 App ID 和 Secret');
      return;
    }

    setFeishuError(null);
    
    try {
      await updateSettings({
        feishuAppId: feishuAppId,
        feishuAppSecret: feishuAppSecret,
      });
      // 标记已有配置
      setFeishuHasSecret(true);
      // 保存成功后自动启动
      await startFeishu();
    } catch (e: any) {
      setFeishuError('保存失败: ' + e.toString());
    }
  };

  const startFeishu = async () => {
    setFeishuStarting(true);
    setFeishuError(null);
    try {
      await startFeishuBot();
      setFeishuStatus('Running');
    } catch (e: any) {
      setFeishuStatus('Stopped');
      setFeishuError('启动失败: ' + e.message);
    } finally {
      setFeishuStarting(false);
    }
  };

  const stopFeishu = async () => {
    setFeishuStopping(true);
    setFeishuError(null);
    try {
      await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:3001'}/api/feishu/stop`, {
        method: 'POST',
      });
      setFeishuStatus('Stopped');
    } catch (e: any) {
      setFeishuError('停止失败: ' + e.toString());
    } finally {
      setFeishuStopping(false);
    }
  };

  // 别名，用于按钮
  const stopFeishuBot = stopFeishu;

  // 导出功能
  const handleExport = async (format: 'json' | 'sqlite' | 'markdown') => {
    setExporting(format);
    setExportError(null);
    
    try {
      const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
      const response = await fetch(`${apiUrl}/api/export/${format}`);
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || '导出失败');
      }
      
      // 获取文件名
      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = `liunian-memory-${new Date().toISOString().slice(0, 10)}`;
      if (contentDisposition) {
        const match = contentDisposition.match(/filename="(.+)"/);
        if (match) {
          filename = match[1];
        }
      } else {
        // 根据格式设置扩展名
        if (format === 'json') filename += '.json';
        else if (format === 'sqlite') filename += '.db';
        else if (format === 'markdown') filename += '.md';
      }
      
      // 下载文件
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
    } catch (error: any) {
      console.error('导出失败:', error);
      setExportError(error.message || '导出失败');
    } finally {
      setExporting(null);
    }
  };

  const filteredModels = models.filter(m => 
    m.name.toLowerCase().includes(modelSearch.toLowerCase()) ||
    m.id.toLowerCase().includes(modelSearch.toLowerCase())
  );

  const selectedModelName = models.find(m => m.id === defaultModel)?.name || defaultModel || '选择默认模型';

  const getFeishuStatusColor = () => {
    switch (feishuStatus) {
      case 'Running': return 'status-running';
      case 'Starting': return 'status-starting';
      case 'Error': return 'status-error';
      default: return 'status-stopped';
    }
  };

  const getFeishuStatusText = () => {
    switch (feishuStatus) {
      case 'Running': return '运行中';
      case 'Starting': return '启动中...';
      case 'Error': return '错误';
      default: return '已停止';
    }
  };

  return (
    <div className="settings-page">
      <div className="settings-container">
        <header className="settings-header">
          <h1>设置</h1>
          <p>配置流年的 API 和飞书机器人</p>
        </header>

        <div className="settings-body">
          {/* API 配置 */}
          <section className="settings-card">
            <div className="card-header">
              <span className="card-icon">🔑</span>
              <h2>API 配置</h2>
            </div>
            
            <div className="form-group">
              <label>Base URL</label>
              <input
                type="text"
                value={baseUrl}
                onChange={e => handleBaseUrlChange(e.target.value)}
                placeholder={DEFAULT_BASE_URL}
              />
              <p className="hint">
                默认: {DEFAULT_BASE_URL} · 
                <a href={INVITE_LINK} target="_blank" rel="noopener noreferrer">
                  获取 API Key <ExternalLink size={12} />
                </a>
              </p>
            </div>
            
            <div className="form-group">
              <label>API Key</label>
              <div className="input-row">
                <input
                  type="password"
                  value={apiKey}
                  onChange={e => handleApiKeyChange(e.target.value)}
                  onFocus={() => {
                    // 如果是占位符，清空
                    if (apiKey === '••••••••••••••••') {
                      setApiKey('');
                    }
                  }}
                  placeholder={hasApiKey ? "已配置（点击修改）" : "输入你的 API Key"}
                />
                <button
                  className="btn-test"
                  onClick={testConnection}
                  disabled={testing || !baseUrl}
                >
                  {testing ? <Loader2 size={16} className="spin" /> : <Check size={16} />}
                  {testing ? '测试中' : '测试'}
                </button>
              </div>
              {testResult && (
                <div className={`test-result ${testResult}`}>
                  {testResult === 'success' ? <Check size={14} /> : <X size={14} />}
                  <span>{testMessage}</span>
                </div>
              )}
            </div>

            <div className="form-group">
              <label>默认模型</label>
              <div className="model-selector" ref={modelSelectorRef}>
                <button 
                  className="model-btn"
                  onClick={() => setShowModelDropdown(!showModelDropdown)}
                  disabled={!hasApiKey}
                >
                  <span>{selectedModelName}</span>
                  <span className="arrow">▼</span>
                </button>
                
                {showModelDropdown && (
                  <div className="model-dropdown">
                    <div className="model-search">
                      <Search size={16} />
                      <input
                        type="text"
                        value={modelSearch}
                        onChange={e => setModelSearch(e.target.value)}
                        placeholder="搜索模型..."
                        autoFocus
                      />
                      {modelsLoading && <Loader2 size={16} className="spin" />}
                    </div>
                    
                    <div className="model-list">
                      {filteredModels.length === 0 && !modelsLoading && (
                        <div className="no-models">
                          {models.length === 0 ? '请先测试 API 连接' : '没有匹配的模型'}
                        </div>
                      )}
                      
                      {filteredModels.map(model => (
                        <button
                          key={model.id}
                          className={`model-option ${defaultModel === model.id ? 'selected' : ''}`}
                          onClick={() => handleModelChange(model.id)}
                        >
                          <span className="model-name">{model.name}</span>
                          <span className="model-provider">{model.provider}</span>
                        </button>
                      ))}
                    </div>
                    
                    <button 
                      className="refresh-btn"
                      onClick={() => loadModels()}
                      disabled={modelsLoading}
                    >
                      <RefreshCw size={14} className={modelsLoading ? 'spin' : ''} />
                      刷新模型列表
                    </button>
                  </div>
                )}
              </div>
            </div>
          </section>

          {/* 飞书配置 */}
          <section className="settings-card">
            <div className="card-header">
              <span className="card-icon">💬</span>
              <h2>飞书机器人</h2>
            </div>

            <div className="form-group">
              <label>App ID</label>
              <input
                type="text"
                value={feishuAppId}
                onChange={e => handleFeishuAppIdChange(e.target.value)}
                placeholder="cli_xxxxxxxxxx"
              />
            </div>

            <div className="form-group">
              <label>App Secret</label>
              <input
                type="password"
                value={feishuAppSecret}
                onChange={e => handleFeishuSecretChange(e.target.value)}
                placeholder={feishuHasSecret ? "已配置（无需重新输入）" : "应用密钥"}
              />
            </div>

            <div className="status-row">
              <span className="status-label">服务状态:</span>
              <span className={`status-badge ${getFeishuStatusColor()}`}>
                {getFeishuStatusText()}
              </span>
            </div>

            {feishuError && (
              <div className="feishu-error">
                <AlertCircle size={16} />
                <span>{feishuError}</span>
              </div>
            )}

            <div className="button-row">
              {/* 如果已停止且有保存的配置，显示启动按钮；否则显示保存并启动 */}
              {feishuStatus === 'Stopped' && feishuAppId && feishuHasSecret ? (
                <button
                  className="btn-start"
                  onClick={startFeishu}
                  disabled={feishuStarting}
                >
                  {feishuStarting ? <Loader2 size={16} className="spin" /> : <Play size={16} />}
                  {feishuStarting ? '启动中...' : '启动'}
                </button>
              ) : (
                <button
                  className="btn-start"
                  onClick={saveFeishuConfig}
                  disabled={!feishuAppId || !feishuAppSecret || feishuStarting}
                >
                  {feishuStarting ? <Loader2 size={16} className="spin" /> : <Play size={16} />}
                  {feishuStarting ? '启动中...' : '保存并启动'}
                </button>
              )}
              <button
                className="btn-stop"
                onClick={stopFeishuBot}
                disabled={feishuStatus === 'Stopped' || feishuStopping}
              >
                {feishuStopping ? <Loader2 size={16} className="spin" /> : <Square size={16} />}
                {feishuStopping ? '停止中...' : '停止'}
              </button>
            </div>

            <div className="config-steps">
              <h4>📋 配置步骤</h4>
              <ol>
                <li>
                  <strong>创建飞书应用</strong>
                  <br />
                  <a href="https://open.feishu.cn/app" target="_blank" rel="noopener noreferrer">
                    打开飞书开放平台 →
                  </a>
                </li>
                <li>
                  <strong>获取凭证</strong>
                  <br />
                  在「凭证与基础信息」页面复制 App ID 和 App Secret
                </li>
                <li>
                  <strong>配置权限</strong>
                  <br />
                  在「权限管理」→「批量导入」中粘贴以下权限：
                  <div className="permission-box">
                    <textarea
                      readOnly
                      value={`{
  "scopes": {
    "tenant": [
      "im:resource",
      "application:application.app_message_stats.overview:readonly",
      "im:chat.access_event.bot_p2p_chat:read",
      "application:bot.menu:write",
      "corehr:file:download",
      "docs:document.content:read",
      "im:message:readonly",
      "application:application:self_manage",
      "im:message.p2p_msg:readonly",
      "im:message.group_at_msg:readonly",
      "im:message:send_as_bot",
      "sheets:spreadsheet",
      "contact:contact.base:readonly",
      "aily:file:read",
      "im:chat",
      "im:chat.members:bot_access",
      "im:message.group_msg",
      "cardkit:card:write",
      "im:message",
      "aily:file:write",
      "contact:user.employee_id:readonly",
      "event:ip_list",
      "wiki:wiki:readonly"
    ],
    "user": []
  }
}`}
                    />
                    <button onClick={(e) => {
                      const permissions = `{
  "scopes": {
    "tenant": [
      "im:resource",
      "application:application.app_message_stats.overview:readonly",
      "im:chat.access_event.bot_p2p_chat:read",
      "application:bot.menu:write",
      "corehr:file:download",
      "docs:document.content:read",
      "im:message:readonly",
      "application:application:self_manage",
      "im:message.p2p_msg:readonly",
      "im:message.group_at_msg:readonly",
      "im:message:send_as_bot",
      "sheets:spreadsheet",
      "contact:contact.base:readonly",
      "aily:file:read",
      "im:chat",
      "im:chat.members:bot_access",
      "im:message.group_msg",
      "cardkit:card:write",
      "im:message",
      "aily:file:write",
      "contact:user.employee_id:readonly",
      "event:ip_list",
      "wiki:wiki:readonly"
    ],
    "user": []
  }
}`;
                      navigator.clipboard.writeText(permissions);
                      const btn = e.currentTarget;
                      const originalText = btn.innerHTML;
                      btn.innerHTML = '✓ 已复制';
                      setTimeout(() => {
                        btn.innerHTML = originalText;
                      }, 2000);
                    }}>
                      <Copy size={14} /> 复制权限列表
                    </button>
                  </div>
                </li>
                <li>
                  <strong>添加事件订阅</strong>
                  <br />
                  在「事件与回调」→「事件配置」中：
                  <ul>
                    <li>订阅方式选择「<strong>使用长连接接收事件</strong>」</li>
                    <li>添加事件：<code>im.message.receive_v1</code></li>
                  </ul>
                </li>
                <li>
                  <strong>保存并启动</strong>
                  <br />
                  点击「保存配置」→「启动」
                </li>
                <li>
                  <strong>发布应用</strong>
                  <br />
                  在「版本管理与发布」中创建版本并发布到企业
                </li>
              </ol>
            </div>
          </section>

          {/* 导出功能 */}
          <section className="settings-card">
            <div className="card-header">
              <span className="card-icon">📦</span>
              <h2>数据导出</h2>
            </div>

            <p className="export-description">
              导出你的记忆数据，方便备份和迁移。数据包含对话历史、事实、实体等信息。
            </p>

            {exportError && (
              <div className="feishu-error">
                <AlertCircle size={16} />
                <span>{exportError}</span>
              </div>
            )}

            <div className="export-buttons">
              <button
                className="export-btn export-json"
                onClick={() => handleExport('json')}
                disabled={exporting !== null}
              >
                {exporting === 'json' ? (
                  <Loader2 size={18} className="spin" />
                ) : (
                  <FileJson size={18} />
                )}
                <span>
                  {exporting === 'json' ? '导出中...' : '导出 JSON'}
                </span>
                <small>结构化数据，方便迁移</small>
              </button>

              <button
                className="export-btn export-sqlite"
                onClick={() => handleExport('sqlite')}
                disabled={exporting !== null}
              >
                {exporting === 'sqlite' ? (
                  <Loader2 size={18} className="spin" />
                ) : (
                  <Database size={18} />
                )}
                <span>
                  {exporting === 'sqlite' ? '导出中...' : '导出 SQLite'}
                </span>
                <small>完整备份，可直接恢复</small>
              </button>

              <button
                className="export-btn export-markdown"
                onClick={() => handleExport('markdown')}
                disabled={exporting !== null}
              >
                {exporting === 'markdown' ? (
                  <Loader2 size={18} className="spin" />
                ) : (
                  <FileText size={18} />
                )}
                <span>
                  {exporting === 'markdown' ? '导出中...' : '导出 Markdown'}
                </span>
                <small>人类可读，方便查看</small>
              </button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
