import { useState, useEffect } from 'react';
import { Search, RefreshCw, Brain, Sparkles, Trash2, Edit2, Plus, X, Check } from 'lucide-react';
import { searchMemory, getAllMemories, deleteMemory, updateMemory, addMemory } from '../services/api';
import type { Memory as MemoryType } from '../services/api';
import type { SearchResult } from '../services/api';
import './MemoryPage.css';

export function MemoryPage() {
  const [memories, setMemories] = useState<MemoryType[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [hasLoaded, setHasLoaded] = useState(false);
  
  // 编辑状态
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const [editCategory, setEditCategory] = useState('');
  
  // 添加弹窗
  const [showAddModal, setShowAddModal] = useState(false);
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState('general');
  const [newImportance, setNewImportance] = useState(0.8);

  // 组件加载时自动获取记忆
  useEffect(() => {
    loadMemories();
  }, []);

  const loadMemories = async () => {
    setLoading(true);
    try {
      const allMemories = await getAllMemories();
      setMemories(allMemories);
      setHasLoaded(true);
    } catch (error) {
      console.error('Failed to load memories:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      loadMemories();
      return;
    }

    setLoading(true);
    try {
      const results: SearchResult = await searchMemory(searchQuery, 10);
      const formatted: MemoryType[] = [];
      
      if (results.episodes) {
        for (const ep of results.episodes) {
          formatted.push({
            id: ep.id,
            content: `${ep.user_message}\n${ep.assistant_response}`,
            category: 'event',
            importance: 0.8,
            created_at: Math.floor(new Date(ep.created_at).getTime() / 1000)
          });
        }
      }
      
      if (results.facts) {
        for (const fact of results.facts) {
          formatted.push({
            id: fact.id,
            content: `${fact.subject} ${fact.predicate} ${fact.object}`,
            category: 'knowledge',
            importance: Math.min((fact.confidence || 1) * 0.5 + 0.5, 1.0),
            created_at: Math.floor(new Date(fact.created_at).getTime() / 1000)
          });
        }
      }
      
      if (results.entities) {
        for (const entity of results.entities) {
          formatted.push({
            id: entity.id,
            content: `${entity.name} (${entity.type})`,
            category: 'profile',
            importance: 0.7,
            created_at: Math.floor(new Date(entity.created_at).getTime() / 1000)
          });
        }
      }
      
      setMemories(formatted);
      setHasLoaded(true);
    } catch (error) {
      console.error('Failed to search memories:', error);
    } finally {
      setLoading(false);
    }
  };

  // 删除记忆
  const handleDelete = async (id: string) => {
    if (!confirm('确定要删除这条记忆吗？')) return;
    
    try {
      await deleteMemory(id);
      setMemories(memories.filter(m => m.id !== id));
    } catch (error) {
      console.error('删除失败:', error);
      alert('删除失败');
    }
  };

  // 开始编辑
  const startEdit = (memory: MemoryType) => {
    setEditingId(memory.id);
    setEditContent(memory.content);
    setEditCategory(memory.category);
  };

  // 取消编辑
  const cancelEdit = () => {
    setEditingId(null);
    setEditContent('');
    setEditCategory('');
  };

  // 保存编辑
  const saveEdit = async () => {
    if (!editingId) return;
    
    try {
      await updateMemory(editingId, editContent, editCategory);
      setMemories(memories.map(m => 
        m.id === editingId 
          ? { ...m, content: editContent, category: editCategory }
          : m
      ));
      cancelEdit();
    } catch (error) {
      console.error('修改失败:', error);
      alert('修改失败');
    }
  };

  // 添加记忆
  const handleAdd = async () => {
    if (!newContent.trim()) return;
    
    try {
      const memory = await addMemory(newContent, newCategory, newImportance);
      setMemories([memory, ...memories]);
      setShowAddModal(false);
      setNewContent('');
      setNewCategory('general');
      setNewImportance(0.8);
    } catch (error) {
      console.error('添加失败:', error);
      alert('添加失败');
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp * 1000).toLocaleString('zh-CN');
  };

  const getCategoryLabel = (category: string) => {
    const labels: Record<string, string> = {
      preference: '偏好',
      profile: '画像',
      event: '事件',
      knowledge: '知识',
      general: '一般',
    };
    return labels[category] || category;
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      preference: '#4caf50',
      profile: '#2196f3',
      event: '#ff9800',
      knowledge: '#9c27b0',
      general: '#607d8b',
    };
    return colors[category] || '#607d8b';
  };

  return (
    <div className="memory-page">
      <div className="memory-header">
        <h1>
          <Brain size={28} />
          记忆系统
        </h1>
        <p className="memory-subtitle">
          <Sparkles size={16} />
          AI 自动记住所有重要信息
        </p>
        <div className="memory-stats">
          <span className="stat">已记住：{memories.length} 条信息</span>
        </div>
      </div>

      <div className="memory-content">
        {/* 说明 */}
        <div className="info-banner">
          <p>💡 记忆系统在后台自动运行，你只需要正常聊天，AI 会自动记住重要信息。你也可以手动添加、编辑或删除记忆。</p>
        </div>

        {/* 工具栏 */}
        <div className="memory-toolbar">
          <div className="search-box">
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              onKeyPress={e => e.key === 'Enter' && handleSearch()}
              placeholder="搜索 AI 记住的内容..."
            />
            <button onClick={handleSearch} disabled={loading}>
              <Search size={20} />
              搜索
            </button>
          </div>

          <div className="toolbar-actions">
            <button onClick={() => setShowAddModal(true)} className="add-button">
              <Plus size={20} />
              添加记忆
            </button>
            <button onClick={loadMemories} disabled={loading} className="secondary-button">
              <RefreshCw size={20} />
              刷新
            </button>
          </div>
        </div>

        {/* 记忆列表 */}
        <div className="memories-list">
          {loading ? (
            <div className="loading">加载中...</div>
          ) : !hasLoaded ? (
            <div className="loading">正在加载记忆...</div>
          ) : memories.length === 0 ? (
            <div className="empty-state">
              <Brain size={48} />
              <p>还没有记忆</p>
              <p className="hint">和 AI 聊天，它会自动记住重要信息</p>
            </div>
          ) : (
            memories.map(memory => (
              <div key={memory.id} className="memory-card">
                {editingId === memory.id ? (
                  // 编辑模式
                  <div className="memory-edit-form">
                    <div className="edit-row">
                      <label>类别：</label>
                      <select 
                        value={editCategory} 
                        onChange={e => setEditCategory(e.target.value)}
                      >
                        <option value="general">一般</option>
                        <option value="knowledge">知识</option>
                        <option value="profile">画像</option>
                        <option value="event">事件</option>
                        <option value="preference">偏好</option>
                      </select>
                    </div>
                    <textarea
                      value={editContent}
                      onChange={e => setEditContent(e.target.value)}
                      rows={3}
                    />
                    <div className="edit-actions">
                      <button onClick={saveEdit} className="save-button">
                        <Check size={16} />
                        保存
                      </button>
                      <button onClick={cancelEdit} className="cancel-button">
                        <X size={16} />
                        取消
                      </button>
                    </div>
                  </div>
                ) : (
                  // 查看模式
                  <>
                    <div className="memory-header-row">
                      <span
                        className="memory-category"
                        style={{ backgroundColor: getCategoryColor(memory.category) }}
                      >
                        {getCategoryLabel(memory.category)}
                      </span>
                      <span className="memory-importance">
                        重要性：{(memory.importance * 100).toFixed(0)}%
                      </span>
                      <div className="memory-actions">
                        <button 
                          onClick={() => startEdit(memory)} 
                          className="icon-button"
                          title="编辑"
                        >
                          <Edit2 size={16} />
                        </button>
                        <button 
                          onClick={() => handleDelete(memory.id)} 
                          className="icon-button delete"
                          title="删除"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                    <div className="memory-content-text">{memory.content}</div>
                    <div className="memory-footer">
                      <span className="memory-time">记录于 {formatDate(memory.created_at)}</span>
                    </div>
                  </>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {/* 添加记忆弹窗 */}
      {showAddModal && (
        <div className="modal-overlay" onClick={() => setShowAddModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>添加记忆</h2>
              <button onClick={() => setShowAddModal(false)} className="close-button">
                <X size={20} />
              </button>
            </div>
            <div className="modal-body">
              <div className="form-row">
                <label>类别：</label>
                <select 
                  value={newCategory} 
                  onChange={e => setNewCategory(e.target.value)}
                >
                  <option value="general">一般</option>
                  <option value="knowledge">知识（格式：主体 关系 客体）</option>
                  <option value="profile">画像（格式：名称 (类型)）</option>
                </select>
              </div>
              <div className="form-row">
                <label>内容：</label>
                <textarea
                  value={newContent}
                  onChange={e => setNewContent(e.target.value)}
                  placeholder={
                    newCategory === 'knowledge' 
                      ? '例如：用户 喜欢 编程' 
                      : newCategory === 'profile'
                      ? '例如：张三 (朋友)'
                      : '输入记忆内容...'
                  }
                  rows={3}
                />
              </div>
              <div className="form-row">
                <label>重要性：{(newImportance * 100).toFixed(0)}%</label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={newImportance}
                  onChange={e => setNewImportance(parseFloat(e.target.value))}
                />
              </div>
            </div>
            <div className="modal-footer">
              <button onClick={() => setShowAddModal(false)} className="cancel-button">
                取消
              </button>
              <button onClick={handleAdd} className="save-button">
                添加
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
