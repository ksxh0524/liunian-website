import { useState } from 'react';
import { Copy, Check } from 'lucide-react';
import './OpenClawIntegration.css';

// 简单的 curl 命令高亮
function highlightCurl(code: string): React.ReactElement {
  // 使用简单的正则替换
  let html = code
    // curl 命令
    .replace(/^curl/g, '<span class="hl-cmd">curl</span>')
    // -X POST/PUT/DELETE/GET
    .replace(/(-X)\s+(POST|PUT|DELETE|GET)/g, '<span class="hl-flag">$1</span> <span class="hl-method">$2</span>')
    // -H "..."
    .replace(/(-H)\s+"([^"]+)"/g, '<span class="hl-flag">$1</span> <span class="hl-string">"$2"</span>')
    // -d '...'
    .replace(/(-d)\s+'([^']+)'/g, (_match, flag, json) => {
      const highlightedJson = json
        .replace(/"([^"]+)":/g, '<span class="hl-key">"$1"</span>:')
        .replace(/:(\s*)"([^"]*)"/g, ':$1<span class="hl-value">"$2"</span>')
        .replace(/:(\s*)([\d.]+)/g, ':$1<span class="hl-number">$2</span>');
      return `<span class="hl-flag">${flag}</span> '<span class="hl-json">${highlightedJson}</span>'`;
    })
    // URL
    .replace(/(https?:\/\/[^\s"']+)/g, '<span class="hl-url">$1</span>');
  
  return <span dangerouslySetInnerHTML={{ __html: html }} />;
}

export function OpenClawIntegration() {
  const [copied, setCopied] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const skillContent = `# 流年记忆系统 - OpenClaw Skill

## 基础配置

API 基础 URL: http://localhost:3001
数据格式: JSON
认证: 无需（本地服务）

## 核心 API

### 读取记忆
- GET /api/memory/all          # 获取所有记忆
- GET /api/memory/search       # 搜索记忆（query=关键词, limit=数量）

### 写入记忆
- POST /api/memory/add         # 添加记忆
- PUT /api/memory/:id          # 修改记忆
- DELETE /api/memory/:id       # 删除记忆

## 记忆格式

{
  "content": "记忆内容",
  "category": "knowledge",
  "importance": 0.8
}

## 类别说明

- knowledge: 知识（格式：主体 关系 客体，例：用户 喜欢 编程）
- profile: 画像（格式：名称 (类型)，例：张三 (朋友)）
- event: 事件（对话记录，自动保存）
- general: 一般（自由格式）

## 使用示例

# 搜索记忆
curl "http://localhost:3001/api/memory/search?query=编程&limit=5"

# 添加记忆
curl -X POST http://localhost:3001/api/memory/add \\
  -H "Content-Type: application/json" \\
  -d '{"content":"用户 喜欢使用 TypeScript","category":"knowledge","importance":0.8}'

---

流年：润物细无声，自动记住一切 ✨`;

  const copySkill = () => {
    copyToClipboard(skillContent, 'skill');
  };

  const apiEndpoints = [
    {
      method: 'GET',
      path: '/api/memory/search',
      desc: '搜索记忆',
      example: `curl "http://localhost:3001/api/memory/search?query=编程&limit=5"`,
    },
    {
      method: 'GET',
      path: '/api/memory/all',
      desc: '获取所有记忆',
      example: `curl http://localhost:3001/api/memory/all`,
    },
    {
      method: 'POST',
      path: '/api/memory/add',
      desc: '添加记忆',
      example: `curl -X POST http://localhost:3001/api/memory/add \\
  -H "Content-Type: application/json" \\
  -d '{"content":"用户 正在使用 macOS","category":"knowledge","importance":0.8}'`,
    },
    {
      method: 'PUT',
      path: '/api/memory/:id',
      desc: '修改记忆',
      example: `curl -X PUT http://localhost:3001/api/memory/abc123 \\
  -H "Content-Type: application/json" \\
  -d '{"content":"用户 精通 Rust 开发"}'`,
    },
    {
      method: 'DELETE',
      path: '/api/memory/:id',
      desc: '删除记忆',
      example: `curl -X DELETE http://localhost:3001/api/memory/abc123`,
    },
  ];

  return (
    <div className="openclaw-integration">
      <header className="doc-header">
        <h1>流年 API 文档</h1>
        <p>本地记忆系统 · 无需认证 · JSON 格式</p>
      </header>

      <div className="doc-body">
        {/* Skill 文件 */}
        <section className="doc-section skill-section">
          <h2>🦞 OpenClaw Skill</h2>
          <p className="section-desc">复制以下内容到 OpenClaw 的 skills 目录</p>
          <div className="code-block">
            <pre>{skillContent}</pre>
            <button
              onClick={copySkill}
              className="copy-btn"
            >
              {copied === 'skill' ? <Check size={14} /> : <Copy size={14} />}
              {copied === 'skill' ? '已复制' : '复制'}
            </button>
          </div>
        </section>

        <section className="doc-section">
          <h2>基础信息</h2>
          <table className="info-table">
            <tbody>
              <tr>
                <td className="label">Base URL</td>
                <td><code>http://localhost:3001</code></td>
              </tr>
              <tr>
                <td className="label">数据格式</td>
                <td><code>JSON</code></td>
              </tr>
              <tr>
                <td className="label">认证</td>
                <td>无需（本地服务）</td>
              </tr>
            </tbody>
          </table>
        </section>

        <section className="doc-section">
          <h2>API 端点</h2>
          <div className="endpoint-list">
            {apiEndpoints.map((api, idx) => (
              <div key={idx} className="endpoint-item">
                <div className="endpoint-header">
                  <span className={`method ${api.method.toLowerCase()}`}>{api.method}</span>
                  <code className="path">{api.path}</code>
                  <span className="desc">{api.desc}</span>
                </div>
                <div className="code-block">
                  <pre className="hl-code">{highlightCurl(api.example)}</pre>
                  <button
                    onClick={() => copyToClipboard(api.example, `api-${idx}`)}
                    className="copy-btn"
                  >
                    {copied === `api-${idx}` ? <Check size={14} /> : <Copy size={14} />}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="doc-section">
          <h2>记忆格式</h2>
          <div className="code-block">
            <pre className="hl-code" dangerouslySetInnerHTML={{ __html: `{
  <span class="hl-key">"id"</span>: <span class="hl-value">"abc123"</span>,
  <span class="hl-key">"content"</span>: <span class="hl-value">"用户 喜欢 编程"</span>,
  <span class="hl-key">"category"</span>: <span class="hl-value">"knowledge"</span>,
  <span class="hl-key">"importance"</span>: <span class="hl-number">0.8</span>,
  <span class="hl-key">"created_at"</span>: <span class="hl-number">1709400000</span>
}` }} />
          </div>
          <table className="info-table">
            <thead>
              <tr>
                <th>字段</th>
                <th>说明</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><code>content</code></td>
                <td>记忆内容</td>
              </tr>
              <tr>
                <td><code>category</code></td>
                <td>knowledge / profile / event / general</td>
              </tr>
              <tr>
                <td><code>importance</code></td>
                <td>重要度 0.0-1.0（可选）</td>
              </tr>
            </tbody>
          </table>
        </section>

        <section className="doc-section">
          <h2>类别说明</h2>
          <table className="info-table">
            <thead>
              <tr>
                <th>类别</th>
                <th>格式</th>
                <th>示例</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><code>knowledge</code></td>
                <td>主体 关系 客体</td>
                <td>用户 喜欢 编程</td>
              </tr>
              <tr>
                <td><code>profile</code></td>
                <td>名称 (类型)</td>
                <td>张三 (朋友)</td>
              </tr>
              <tr>
                <td><code>event</code></td>
                <td>对话记录</td>
                <td>自动保存</td>
              </tr>
              <tr>
                <td><code>general</code></td>
                <td>自由格式</td>
                <td>通用记忆</td>
              </tr>
            </tbody>
          </table>
        </section>
      </div>
    </div>
  );
}
