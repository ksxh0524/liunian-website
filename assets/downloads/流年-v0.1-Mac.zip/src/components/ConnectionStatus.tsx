import React from 'react';
import { Wifi, WifiOff, Loader } from 'lucide-react';
import type { ServiceStatus } from '../types';
import './ConnectionStatus.css';

interface ConnectionStatusProps {
  status: ServiceStatus;
}

export const ConnectionStatus: React.FC<ConnectionStatusProps> = ({ status }) => {
  const statusConfig = {
    running: {
      icon: Wifi,
      text: '已连接',
      className: 'connected',
    },
    starting: {
      icon: Loader,
      text: '连接中',
      className: 'connecting',
    },
    error: {
      icon: WifiOff,
      text: '连接失败',
      className: 'error',
    },
    stopped: {
      icon: WifiOff,
      text: '未连接',
      className: 'disconnected',
    },
  };

  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <div className={`connection-status ${config.className}`}>
      <Icon size={14} className={status === 'starting' ? 'spin' : ''} />
      <span>{config.text}</span>
    </div>
  );
};
