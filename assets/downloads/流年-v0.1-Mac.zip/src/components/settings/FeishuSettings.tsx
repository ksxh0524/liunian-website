import React, { useState, useEffect } from 'react';
import { 
  MessageSquare, 
  Play, 
  Square, 
  Check, 
  AlertCircle, 
  Loader, 
  ExternalLink
} from 'lucide-react';
import { getSettings, updateSettings, getFeishuStatus, startFeishuBot } from '../../services/api';
import './FeishuSettings.css';

interface FeishuSettingsProps {
  onNavigateToTutorial?: () => void;
}

export const FeishuSettings: React.FC<FeishuSettingsProps> = ({ onNavigateToTutorial }) => {
  const [appId, setAppId] = useState('');
  const [appSecret, setAppSecret] = useState('');
  const [testResult, setTestResult] = useState<'success' | 'error' | null>(null);
  const [testMessage, setTestMessage] = useState('');
  const [saving, setSaving] = useState(false);
  
  const [botStatus, setBotStatus] = useState<string>('Stopped');
  const [starting, setStarting] = useState(false);
  const [stopping, setStopping] = useState(false);
  const [configSaved, setConfigSaved] = useState(false);

  // 加载配置
  useEffect(() => {
    loadConfig();
    loadBotStatus();
  }, []);

  const loadConfig = async () => {
    try {
      const settings = await getSettings();
      if (settings.feishu_app_id) {
        setAppId(settings.feishu_app_id);
        setConfigSaved(true);
      }
    } catch (e) {
      console.error('加载配置失败:', e);
    }
  };

  const loadBotStatus = async () => {
    try {
      const result = await getFeishuStatus();
      const status = result.status || 'Stopped';
      setBotStatus(status === 'Running' ? 'Running' : 
                   status === 'Starting' ? 'Starting' : 
                   status === 'Error' ? 'Error' : 'Stopped');
    } catch (e) {
      console.error('获取状态失败:', e);
    }
  };

  const saveConfig = async () => {
    if (!appId || !appSecret) {
      setTestResult('error');
      setTestMessage('请填写 App ID 和 App Secret');
      return;
    }

    setSaving(true);
    setTestResult(null);
    
    try {
      await updateSettings({
        feishu_app_id: appId,
        feishu_app_secret: appSecret,
      });
      setTestResult('success');
      setTestMessage('配置已保存');
      setConfigSaved(true);
    } catch (e: any) {
      setTestResult('error');
      setTestMessage('保存失败: ' + e.toString());
    } finally {
      setSaving(false);
    }
  };

  const startBot = async () => {
    setStarting(true);
    try {
      await startFeishuBot();
      setBotStatus('Running');
      setTestResult('success');
      setTestMessage('飞书机器人已启动');
    } catch (e: any) {
      setBotStatus('Error');
      setTestResult('error');
      setTestMessage('启动失败: ' + e.message);
    } finally {
      setStarting(false);
    }
  };

  const stopBot = async () => {
    setStopping(true);
    try {
      await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:3001'}/api/feishu/stop`, {
        method: 'POST',
      });
      setBotStatus('Stopped');
    } catch (e: any) {
      setTestResult('error');
      setTestMessage('停止失败: ' + e.toString());
    } finally {
      setStopping(false);
    }
  };

  const getStatusColor = () => {
    switch (botStatus) {
      case 'Running': return 'status-running';
      case 'Starting': return 'status-starting';
      case 'Error': return 'status-error';
      default: return 'status-stopped';
    }
  };

  const getStatusText = () => {
    switch (botStatus) {
      case 'Running': return '运行中';
      case 'Starting': return '启动中...';
      case 'Error': return '错误';
      default: return '已停止';
    }
  };

  return (
    <div className="feishu-settings">
      {/* 配置区域 */}
      <div className="settings-section">
        <div className="section-header">
          <MessageSquare size={18} />
          <h3>飞书应用配置</h3>
        </div>

        <div className="form-group">
          <label>App ID</label>
          <input
            type="text"
            value={appId}
            onChange={(e) => {
              setAppId(e.target.value);
              setConfigSaved(false);
            }}
            placeholder="cli_xxxxxxxxxx"
            className="input"
          />
        </div>

        <div className="form-group">
          <label>App Secret</label>
          <input
            type="password"
            value={appSecret}
            onChange={(e) => {
              setAppSecret(e.target.value);
              setConfigSaved(false);
            }}
            placeholder="应用密钥"
            className="input"
          />
        </div>

        {/* 测试结果 */}
        {testResult && (
          <div className={`test-result ${testResult}`}>
            {testResult === 'success' ? <Check size={16} /> : <AlertCircle size={16} />}
            <span>{testMessage}</span>
          </div>
        )}

        <div className="button-row">
          <button
            className="btn btn-primary"
            onClick={saveConfig}
            disabled={!appId || !appSecret || saving}
          >
            {saving ? <Loader size={16} className="spin" /> : null}
            {saving ? '保存中' : '保存配置'}
          </button>
        </div>

        {onNavigateToTutorial && (
          <button className="btn btn-link" onClick={onNavigateToTutorial}>
            <ExternalLink size={14} />
            查看配置教程
          </button>
        )}
      </div>

      {/* 机器人服务控制 */}
      <div className="settings-section">
        <div className="section-header">
          <Play size={18} />
          <h3>机器人服务</h3>
        </div>

        <div className="status-row">
          <span className="status-label">服务状态:</span>
          <span className={`status-badge ${getStatusColor()}`}>
            {getStatusText()}
          </span>
        </div>

        <div className="button-row">
          <button
            className="btn btn-success"
            onClick={startBot}
            disabled={botStatus === 'Running' || starting || !configSaved}
          >
            {starting ? <Loader size={16} className="spin" /> : <Play size={16} />}
            {starting ? '启动中' : '启动服务'}
          </button>
          <button
            className="btn btn-danger"
            onClick={stopBot}
            disabled={botStatus === 'Stopped' || stopping}
          >
            {stopping ? <Loader size={16} className="spin" /> : <Square size={16} />}
            {stopping ? '停止中' : '停止服务'}
          </button>
        </div>

        {!configSaved && (
          <div className="warning-hint">
            <AlertCircle size={14} />
            <span>请先保存配置后再启动服务</span>
          </div>
        )}

        {/* 配置步骤 */}
        <div className="config-steps">
          <h4>📋 配置步骤（重要！）</h4>
          <ol>
            <li>
              <strong>创建飞书应用</strong>
              <br />
              <a href="https://open.feishu.cn/app" target="_blank" rel="noopener noreferrer">
                打开飞书开放平台 →
              </a>
            </li>
            <li>
              <strong>获取凭证</strong>
              <br />
              在「凭证与基础信息」页面复制 App ID 和 App Secret，填入上方表单
            </li>
            <li>
              <strong>配置权限</strong>
              <br />
              在「权限管理」中添加：
              <ul>
                <li>获取与发送消息 (im:message)</li>
                <li>获取用户信息 (contact:user.base:readonly)</li>
              </ul>
            </li>
            <li>
              <strong>添加事件订阅</strong>
              <br />
              在「事件与回调」→「事件配置」中：
              <ul>
                <li>订阅方式选择「<strong>使用长连接接收事件</strong>」</li>
                <li>添加事件：<code>im.message.receive_v1</code>（接收消息）</li>
              </ul>
            </li>
            <li>
              <strong>保存并启动</strong>
              <br />
              点击上方「保存配置」→「启动服务」
            </li>
            <li>
              <strong>发布应用</strong>
              <br />
              在「版本管理与发布」中创建版本并发布到企业
            </li>
          </ol>
          <div className="hint-note warning">
            ⚠️ 如果启动失败，请确保：
            <ul>
              <li>已在飞书后台选择「使用长连接接收事件」</li>
              <li>已添加 im.message.receive_v1 事件</li>
              <li>App ID 和 Secret 正确</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeishuSettings;
