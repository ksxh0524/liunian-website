import React, { useState, useEffect } from 'react';
import { X, Key, Check, Globe, Loader, AlertCircle, CheckCircle, RefreshCw, MessageSquare } from 'lucide-react';
import { openLink } from '../../utils/openLink';
import * as api from '../../services/api';
import type { ModelInfo } from '../../types';
import { FeishuSettings } from '../settings/FeishuSettings';
import './SettingsDrawer.css';

interface SettingsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onConfigSaved: (key: string, baseUrl: string, model: string) => Promise<void>;
  initialConfig?: {
    apiKey?: string;
    baseUrl?: string;
    model?: string;
  };
}

type SettingsTab = 'api' | 'feishu';

export const SettingsDrawer: React.FC<SettingsDrawerProps> = ({
  isOpen,
  onClose,
  onConfigSaved,
  initialConfig,
}) => {
  const [activeTab, setActiveTab] = useState<SettingsTab>('api');
  const [apiKey, setApiKey] = useState('');
  const [baseUrl, setBaseUrl] = useState('https://api.n1n.ai');
  const [selectedModel, setSelectedModel] = useState('');
  const [models, setModels] = useState<ModelInfo[]>([]);
  const [modelSearch, setModelSearch] = useState('');
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const [testingAPI, setTestingAPI] = useState(false);
  const [testResult, setTestResult] = useState<'success' | 'error' | null>(null);
  const [testMessage, setTestMessage] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // 加载初始配置
  useEffect(() => {
    if (isOpen && initialConfig) {
      setApiKey(initialConfig.apiKey || '');
      setBaseUrl(initialConfig.baseUrl || 'https://api.n1n.ai');
      setSelectedModel(initialConfig.model || '');
      
      // 如果有 API Key，加载模型列表
      if (initialConfig.apiKey) {
        loadModels();
      }
    }
  }, [isOpen, initialConfig]);

  // 测试 API Key 并获取模型列表
  const testAPI = async () => {
    if (!apiKey.trim()) {
      setTestResult('error');
      setTestMessage('请先输入 API Key');
      return;
    }

    setTestingAPI(true);
    setTestResult(null);
    setTestMessage('');
    setModels([]);

    try {
      // 调用 /v1/models 获取模型列表
      const response = await fetch(`${baseUrl}/v1/models`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
        },
      });

      if (!response.ok) {
        throw new Error(`API 返回 ${response.status}`);
      }

      const data = await response.json();
      
      if (data.data && Array.isArray(data.data)) {
        // 过滤并格式化模型
        const chatModels = data.data
          .filter((m: any) => {
            const id = m.id || '';
            // 过滤掉非聊天模型
            return !id.includes('embed') && 
                   !id.includes('whisper') && 
                   !id.includes('tts') && 
                   !id.includes('dall-e');
          })
          .map((m: any) => ({
            id: m.id,
            name: formatModelName(m.id),
            provider: formatProviderName(m.owned_by || ''),
            description: '',
          }))
          .sort((a: any, b: any) => a.name.localeCompare(b.name));

        setModels(chatModels);
        
        if (chatModels.length > 0) {
          setTestResult('success');
          setTestMessage(`连接成功！发现 ${chatModels.length} 个可用模型`);
          // 默认选择第一个模型
          if (!selectedModel) {
            setSelectedModel(chatModels[0].id);
          }
        } else {
          setTestResult('error');
          setTestMessage('未找到可用的聊天模型');
        }
      } else {
        setTestResult('error');
        setTestMessage('响应格式不正确');
      }
    } catch (error: any) {
      console.error('测试失败:', error);
      setTestResult('error');
      setTestMessage(error.message || '连接失败，请检查 API Key 和地址');
    } finally {
      setTestingAPI(false);
    }
  };

  // 格式化模型名称
  const formatModelName = (id: string): string => {
    const nameMap: Record<string, string> = {
      'gpt-4o': 'GPT-4o',
      'gpt-4o-mini': 'GPT-4o Mini',
      'gpt-4-turbo': 'GPT-4 Turbo',
      'gpt-4': 'GPT-4',
      'gpt-3.5-turbo': 'GPT-3.5 Turbo',
    };
    
    if (nameMap[id]) return nameMap[id];
    if (id.startsWith('claude-3-5-sonnet')) return 'Claude 3.5 Sonnet';
    if (id.startsWith('claude-3-5-haiku')) return 'Claude 3.5 Haiku';
    if (id.startsWith('claude-3-opus')) return 'Claude 3 Opus';
    if (id.startsWith('glm-')) return `GLM ${id.replace('glm-', '')}`;
    if (id.startsWith('deepseek-')) return `DeepSeek ${id.replace('deepseek-', '')}`;
    if (id.startsWith('gemini-')) return `Gemini ${id.replace('gemini-', '')}`;
    
    return id;
  };

  // 格式化提供商名称
  const formatProviderName = (owner: string): string => {
    const providerMap: Record<string, string> = {
      'openai': 'OpenAI',
      'anthropic': 'Anthropic',
      'google': 'Google',
      'gemini': 'Google',
      'zhipu': '智谱',
      'zhipuai': '智谱',
      'deepseek': 'DeepSeek',
      'moonshot': 'Moonshot',
      'alibaba': '阿里',
      'qwen': '阿里',
      'baidu': '百度',
    };
    
    return providerMap[owner.toLowerCase()] || owner;
  };

  // 过滤模型
  const filteredModels = models.filter(model => {
    if (!modelSearch.trim()) return true;
    const search = modelSearch.toLowerCase();
    return (
      model.id.toLowerCase().includes(search) ||
      model.name.toLowerCase().includes(search) ||
      model.provider.toLowerCase().includes(search)
    );
  });

  // 获取选中的模型信息
  const selectedModelInfo = models.find(m => m.id === selectedModel);

  // 选择模型
  const handleSelectModel = (model: ModelInfo) => {
    setSelectedModel(model.id);
    setModelSearch('');
    setShowModelDropdown(false);
  };

  // 点击外部关闭下拉菜单
  useEffect(() => {
    const handleClickOutside = () => {
      setShowModelDropdown(false);
    };

    if (showModelDropdown) {
      document.addEventListener('click', handleClickOutside);
      return () => document.removeEventListener('click', handleClickOutside);
    }
  }, [showModelDropdown]);

  // 从后端加载模型列表
  const loadModels = async () => {
    try {
      const modelList = await api.getAvailableModels();
      setModels(modelList);
      if (modelList.length > 0 && !selectedModel) {
        setSelectedModel(modelList[0].id);
      }
    } catch (error) {
      console.error('加载模型列表失败:', error);
    }
  };

  // 保存配置
  const handleSave = async () => {
    if (!apiKey.trim()) {
      setTestResult('error');
      setTestMessage('请先输入 API Key');
      return;
    }

    if (models.length === 0) {
      setTestResult('error');
      setTestMessage('请先测试 API Key');
      return;
    }

    if (!selectedModel) {
      setTestResult('error');
      setTestMessage('请选择一个模型');
      return;
    }

    setSaving(true);

    try {
      await onConfigSaved(apiKey.trim(), baseUrl.trim(), selectedModel);
      
      setSaved(true);
      setTimeout(() => {
        setSaved(false);
        onClose();
      }, 1500);
    } catch (error) {
      console.error('保存失败:', error);
      setTestResult('error');
      setTestMessage('保存失败，请重试');
    } finally {
      setSaving(false);
    }
  };

  // 导航到教程页面
  const handleNavigateToTutorial = () => {
    onClose();
    // 可以通过路由导航到教程页面
    window.location.href = '/tutorial';
  };

  if (!isOpen) return null;

  return (
    <div className="settings-overlay" onClick={onClose}>
      <div className="settings-drawer" onClick={(e) => e.stopPropagation()}>
        <div className="settings-header">
          <h2>设置</h2>
          <button className="close-btn" onClick={onClose}>
            <X size={20} />
          </button>
        </div>

        {/* 标签页 */}
        <div className="settings-tabs">
          <button
            className={`tab ${activeTab === 'api' ? 'active' : ''}`}
            onClick={() => setActiveTab('api')}
          >
            <Key size={14} />
            API 配置
          </button>
          <button
            className={`tab ${activeTab === 'feishu' ? 'active' : ''}`}
            onClick={() => setActiveTab('feishu')}
          >
            <MessageSquare size={14} />
            飞书机器人
          </button>
        </div>

        <div className="settings-content">
          {/* API 配置 */}
          {activeTab === 'api' && (
            <div className="settings-section">
              <div className="n1n-promo">
                <div className="n1n-logo">🟣</div>
                <div className="n1n-info">
                  <div className="n1n-name">N1N.AI</div>
                  <div className="n1n-desc">多模型聚合平台，支持 GPT/Claude/GLM 等</div>
                </div>
                <button
                  className="n1n-link"
                  onClick={() => openLink('https://api.n1n.ai/register?aff=ieRd')}
                >
                  注册充值
                </button>
              </div>

              <div className="form-group">
                <label>API Key</label>
                <div className="api-key-row">
                  <input
                    type="password"
                    value={apiKey}
                    onChange={(e) => {
                      setApiKey(e.target.value);
                      setTestResult(null);
                      setModels([]);
                    }}
                    placeholder="输入 API Key"
                    className="input"
                  />
                  <button
                    className="test-btn"
                    onClick={testAPI}
                    disabled={!apiKey.trim() || testingAPI}
                  >
                    {testingAPI ? (
                      <Loader size={16} className="spin" />
                    ) : (
                      <RefreshCw size={16} />
                    )}
                    {testingAPI ? '测试中' : '测试'}
                  </button>
                </div>
                <button
                  className="get-key-link"
                  onClick={() => openLink('https://api.n1n.ai/console/token')}
                >
                  获取 API Key →
                </button>
              </div>

              <div className="form-group">
                <label>
                  <Globe size={14} style={{ marginRight: 4 }} />
                  API 地址
                </label>
                <input
                  type="text"
                  value={baseUrl}
                  onChange={(e) => {
                    setBaseUrl(e.target.value);
                    setTestResult(null);
                    setModels([]);
                  }}
                  placeholder="https://api.n1n.ai"
                  className="input"
                />
                <p className="hint">
                  默认使用 N1N.AI。也支持其他 OpenAI 兼容的 API 地址
                </p>
              </div>

              {/* 测试结果提示 */}
              {testResult && (
                <div className={`test-result ${testResult}`}>
                  {testResult === 'success' ? (
                    <CheckCircle size={16} />
                  ) : (
                    <AlertCircle size={16} />
                  )}
                  <span>{testMessage}</span>
                </div>
              )}

              {/* 模型选择 */}
              {models.length > 0 && (
                <div className="form-group">
                  <label>选择模型</label>
                  <div className="model-selector">
                    <div 
                      className="model-selector-input"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowModelDropdown(!showModelDropdown);
                      }}
                    >
                      {selectedModelInfo ? (
                        <div className="selected-model">
                          <span className="model-name">{selectedModelInfo.name}</span>
                          <span className="model-provider">{selectedModelInfo.provider}</span>
                        </div>
                      ) : (
                        <span className="placeholder">选择一个模型...</span>
                      )}
                      <span className="dropdown-icon">▼</span>
                    </div>
                    
                    {showModelDropdown && (
                      <div className="model-dropdown" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="text"
                          className="model-search"
                          placeholder="搜索模型（输入 gem、gpt、claude 等）"
                          value={modelSearch}
                          onChange={(e) => setModelSearch(e.target.value)}
                          onClick={(e) => e.stopPropagation()}
                          autoFocus
                        />
                        <div className="model-list">
                          {filteredModels.length > 0 ? (
                            filteredModels.map((model) => (
                              <div
                                key={model.id}
                                className={`model-option ${model.id === selectedModel ? 'selected' : ''}`}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleSelectModel(model);
                                }}
                              >
                                <span className="model-name">{model.name}</span>
                                <span className="model-provider">{model.provider}</span>
                              </div>
                            ))
                          ) : (
                            <div className="no-results">未找到匹配的模型</div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                  <p className="hint">
                    共 {models.length} 个可用模型{modelSearch && `，筛选出 ${filteredModels.length} 个`}
                  </p>
                </div>
              )}

              <button
                className="save-btn full-width"
                onClick={handleSave}
                disabled={!apiKey.trim() || models.length === 0 || !selectedModel || saving}
              >
                {saving ? (
                  <>
                    <Loader size={16} className="spin" />
                    保存中...
                  </>
                ) : saved ? (
                  <>
                    <Check size={16} />
                    已保存
                  </>
                ) : (
                  '保存配置'
                )}
              </button>
            </div>
          )}

          {/* 飞书配置 */}
          {activeTab === 'feishu' && (
            <FeishuSettings onNavigateToTutorial={handleNavigateToTutorial} />
          )}
        </div>
      </div>
    </div>
  );
};
