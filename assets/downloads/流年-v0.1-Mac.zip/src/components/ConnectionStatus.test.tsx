import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { ConnectionStatus } from './ConnectionStatus'

describe('ConnectionStatus', () => {
  it('应该正确显示 running 状态', () => {
    render(<ConnectionStatus status="running" />)
    expect(screen.getByText('已连接')).toBeInTheDocument()
  })

  it('应该正确显示 starting 状态', () => {
    render(<ConnectionStatus status="starting" />)
    expect(screen.getByText('连接中')).toBeInTheDocument()
  })

  it('应该正确显示 error 状态', () => {
    render(<ConnectionStatus status="error" />)
    expect(screen.getByText('连接失败')).toBeInTheDocument()
  })

  it('应该正确显示 stopped 状态', () => {
    render(<ConnectionStatus status="stopped" />)
    expect(screen.getByText('未连接')).toBeInTheDocument()
  })
})
