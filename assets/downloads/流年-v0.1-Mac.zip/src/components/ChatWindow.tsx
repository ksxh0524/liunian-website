import React, { useState, useRef, useEffect } from 'react';
import { Send, ArrowDown, Settings, ChevronDown, Check } from 'lucide-react';
import type { ChatMessage, ModelInfo } from '../types';
import { filterMessageContent, shouldHideMessage } from '../utils/messageFilter';
import * as api from '../services/api';
import './ChatWindow.css';

interface ChatWindowProps {
  messages: ChatMessage[];
  onSendMessage: (content: string) => void;
  isLoading?: boolean;
  initialized?: boolean;
  onOpenSettings: () => void;
  currentModel?: string;
  onModelChange?: (model: string) => void;
}

export const ChatWindow: React.FC<ChatWindowProps> = ({
  messages,
  onSendMessage,
  isLoading = false,
  initialized = true,
  onOpenSettings,
  currentModel = 'gpt-4o-mini',
  onModelChange,
}) => {
  const [input, setInput] = useState('');
  const [models, setModels] = useState<ModelInfo[]>([]);
  const [showModelSelector, setShowModelSelector] = useState(false);
  const [modelSearch, setModelSearch] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [showScrollButton, setShowScrollButton] = useState(false);

  // 筛选模型
  const filteredModels = models.filter(model => {
    if (!modelSearch) return true;
    const search = modelSearch.toLowerCase();
    return (
      model.id.toLowerCase().includes(search) ||
      model.name.toLowerCase().includes(search) ||
      model.provider.toLowerCase().includes(search)
    );
  });

  // 加载模型列表
  useEffect(() => {
    const loadModels = async () => {
      try {
        const modelList = await api.getAvailableModels();
        setModels(modelList);
      } catch (error) {
        console.error('加载模型列表失败:', error);
      }
    };
    
    if (initialized) {
      loadModels();
    }
  }, [initialized]);

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.style.height = `${Math.min(inputRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
      setShowScrollButton(!isNearBottom);
    };

    container.addEventListener('scroll', handleScroll);
    return () => container.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    
    onSendMessage(input.trim());
    setInput('');
    
    setTimeout(() => {
      if (inputRef.current) {
        inputRef.current.style.height = 'auto';
      }
    }, 0);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)} 分钟前`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)} 小时前`;
    
    return date.toLocaleString('zh-CN', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const hasMessages = messages.length > 0;
  const visibleMessages = messages.filter(m => !shouldHideMessage(m.content));

  // 获取当前模型信息
  const currentModelInfo = models.find(m => m.id === currentModel);

  return (
    <div className="chat-window">
      {/* 模型选择器 - 放到左上角 */}
      {initialized && models.length > 0 && (
        <div className="model-selector-top-left">
          <div
            className="model-selector-trigger"
            onClick={() => setShowModelSelector(!showModelSelector)}
          >
            <span className="current-model-name">
              {currentModelInfo?.name || currentModel}
            </span>
            <ChevronDown size={14} className={showModelSelector ? 'rotated' : ''} />
          </div>

          {showModelSelector && (
            <>
              <div className="model-selector-backdrop" onClick={() => {
                setShowModelSelector(false);
                setModelSearch('');
              }} />
              <div className="model-selector-dropdown-top">
                <div className="model-search-box">
                  <input
                    type="text"
                    placeholder="搜索模型..."
                    value={modelSearch}
                    onChange={(e) => setModelSearch(e.target.value)}
                    onClick={(e) => e.stopPropagation()}
                    autoFocus
                  />
                </div>
                <div className="model-list">
                  {filteredModels.length > 0 ? (
                    filteredModels.map((model) => (
                      <div
                        key={model.id}
                        className={`model-option ${model.id === currentModel ? 'selected' : ''}`}
                        onClick={() => {
                          if (onModelChange) {
                            onModelChange(model.id);
                          }
                          setShowModelSelector(false);
                          setModelSearch('');
                        }}
                      >
                        <div className="model-option-info">
                          <span className="model-option-name">{model.name}</span>
                          <span className="model-option-provider">{model.provider}</span>
                        </div>
                        {model.id === currentModel && (
                          <Check size={14} className="check-icon" />
                        )}
                      </div>
                    ))
                  ) : (
                    <div className="model-no-results">
                      没有找到匹配的模型
                    </div>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      )}

      <div className="messages-container" ref={containerRef}>
        {hasMessages ? (
          <>
            {visibleMessages.map((message) => (
              <div
                key={message.id}
                className={`message ${message.role}`}
              >
                <div className="message-avatar">
                  {message.role === 'user' ? '我' : 'AI'}
                </div>
                <div className="message-content">
                  <div className="message-header">
                    <span className="message-role">
                      {message.role === 'user' ? '你' : '流年'}
                    </span>
                    <span className="message-time">
                      {formatTime(message.timestamp)}
                    </span>
                  </div>
                  <div className="message-text">{filterMessageContent(message.content)}</div>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="message assistant loading">
                <div className="message-avatar">AI</div>
                <div className="message-content">
                  <div className="message-header">
                    <span className="message-role">流年</span>
                  </div>
                  <div className="message-text loading">
                    <div className="typing-indicator">
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />

            {showScrollButton && (
              <button className="scroll-to-bottom" onClick={scrollToBottom}>
                <ArrowDown size={18} />
              </button>
            )}
          </>
        ) : (
          <div className="empty-state"></div>
        )}
      </div>

      <div className={`input-container-wrapper ${hasMessages ? 'at-bottom' : 'centered'}`}>
        {!initialized && (
          <button className="setup-btn" onClick={onOpenSettings}>
            <Settings size={16} />
            请先配置 API Key
          </button>
        )}
        <form className="input-container" onSubmit={handleSubmit}>
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={initialized ? "输入消息..." : ""}
            rows={1}
            disabled={isLoading || !initialized}
          />
          <button
            type="submit"
            className="send-button"
            disabled={!input.trim() || isLoading || !initialized}
          >
            <Send size={18} />
          </button>
        </form>
      </div>
    </div>
  );
};
