import { Settings, Trash2, Plus, MessageSquare, MessageSquarePlus, MessageCircle, Brain, Shrimp } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import type { ChatSession } from '../types';
import './Sidebar.css';

interface SidebarProps {
  sessions: ChatSession[];
  currentSessionId: string | null;
  onSelectSession: (id: string) => void;
  onNewSession: () => void;
  onDeleteSession: (id: string) => void;
  onOpenSettings: () => void;
}

export const Sidebar = ({
  sessions,
  currentSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onOpenSettings: _onOpenSettings, // 保留接口，暂未使用
}: SidebarProps) => {
  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return '今天';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return '昨天';
    } else {
      return date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' });
    }
  };

  // 按日期分组会话
  const groupedSessions = sessions.reduce((groups, session) => {
    const date = formatDate(session.updatedAt);
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(session);
    return groups;
  }, {} as Record<string, ChatSession[]>);

  const groupOrder = ['今天', '昨天'];
  const sortedGroups = Object.keys(groupedSessions).sort((a, b) => {
    const aIndex = groupOrder.indexOf(a);
    const bIndex = groupOrder.indexOf(b);
    if (aIndex !== -1 && bIndex !== -1) return aIndex - bIndex;
    if (aIndex !== -1) return -1;
    if (bIndex !== -1) return 1;
    return 0;
  });

  return (
    <aside className="sidebar">
      {/* 品牌 */}
      <div className="sidebar-brand">
        <span className="brand-title">流年</span>
      </div>

      {/* 新对话按钮 */}
      <div className="sidebar-header">
        <button className="new-chat-btn" onClick={onNewSession}>
          <Plus size={18} />
          <span>新对话</span>
        </button>
      </div>

      {/* 会话列表 */}
      <div className="sidebar-content">
        {sessions.length === 0 ? (
          <div className="sidebar-empty">
            <MessageSquarePlus size={32} />
            <p>暂无对话</p>
            <span>点击上方按钮开始</span>
          </div>
        ) : (
          sortedGroups.map((group) => (
            <div key={group} className="conversation-group">
              <div className="conversation-group-title">{group}</div>
              {groupedSessions[group].map((session) => (
                <div
                  key={session.id}
                  className={`conversation-item ${session.id === currentSessionId ? 'active' : ''}`}
                  onClick={() => onSelectSession(session.id)}
                >
                  <MessageSquare size={16} />
                  <span className="conversation-item-title truncate">
                    {session.title}
                  </span>
                  <button
                    className="conversation-item-delete"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteSession(session.id);
                    }}
                    title="删除对话"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          ))
        )}
      </div>

      {/* 底部导航 */}
      <div className="sidebar-footer">
        <nav className="sidebar-nav">
          <NavLink to="/" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
            <MessageCircle size={18} />
            <span>聊天</span>
          </NavLink>
          <NavLink to="/memory" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
            <Brain size={18} />
            <span>记忆</span>
          </NavLink>
          <NavLink to="/openclaw" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
            <Shrimp size={18} />
            <span>龙虾</span>
          </NavLink>
          <NavLink to="/settings" className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}>
            <Settings size={18} />
            <span>设置</span>
          </NavLink>
        </nav>
      </div>
    </aside>
  );
};