// API 服务 - 连接到 Node.js 后端

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:3001';

// ==================== 类型定义 ====================

export interface ChatRequest {
  message: string;
  chat_id?: string;
  model?: string;
}

export interface ChatResponse {
  response: string;
  chat_id: string;
}

export interface Memory {
  id: string;
  content: string;
  category: string;
  importance: number;
  created_at: number;
}

export interface AddMemoryRequest {
  content: string;
  category: string;
  importance?: number;
}

export interface SyncRequest {
  last_sync_time: number;
  memories_from_openclaw: AddMemoryRequest[];
}

export interface SyncResponse {
  memories_from_liunian: Memory[];
  sync_time: number;
}

// 搜索结果
export interface SearchResult {
  episodes: any[];
  facts: any[];
  entities: any[];
}

// ==================== API 函数 ====================

/**
 * 健康检查
 */
export async function healthCheck(): Promise<string> {
  const response = await fetch(`${API_BASE}/health`);
  return response.text();
}

/**
 * 聊天
 */
export async function chat(message: string, chatId?: string, model?: string): Promise<ChatResponse> {
  const response = await fetch(`${API_BASE}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message, chat_id: chatId, model } as ChatRequest),
  });
  
  if (!response.ok) {
    throw new Error(`Chat failed: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * 搜索记忆
 */
export async function searchMemory(query: string, limit: number = 5): Promise<SearchResult> {
  const response = await fetch(
    `${API_BASE}/api/memory/search?query=${encodeURIComponent(query)}&limit=${limit}`
  );
  
  if (!response.ok) {
    throw new Error(`Search memory failed: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * 获取所有记忆
 */
export async function getAllMemories(): Promise<Memory[]> {
  const response = await fetch(`${API_BASE}/api/memory/all`);
  
  if (!response.ok) {
    throw new Error(`Get all memories failed: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * 删除记忆
 */
export async function deleteMemory(id: string): Promise<{ success: boolean }> {
  const response = await fetch(`${API_BASE}/api/memory/${id}`, {
    method: 'DELETE',
  });
  
  if (!response.ok) {
    throw new Error(`Delete memory failed: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * 修改记忆
 */
export async function updateMemory(id: string, content: string, category: string): Promise<{ success: boolean }> {
  const response = await fetch(`${API_BASE}/api/memory/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content, category }),
  });
  
  if (!response.ok) {
    throw new Error(`Update memory failed: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * 添加记忆（通用接口）
 */
export async function addMemory(content: string, category: string, importance?: number): Promise<Memory> {
  const response = await fetch(`${API_BASE}/api/memory/add`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content, category, importance }),
  });
  
  if (!response.ok) {
    throw new Error(`Add memory failed: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * 同步记忆
 */
export async function syncMemory(request: SyncRequest): Promise<SyncResponse> {
  const response = await fetch(`${API_BASE}/api/memory/sync`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(request),
  });
  
  if (!response.ok) {
    throw new Error(`Sync memory failed: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * 获取设置
 */
export async function getSettings(): Promise<Record<string, any>> {
  const response = await fetch(`${API_BASE}/api/settings`);
  
  if (!response.ok) {
    throw new Error(`Get settings failed: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * 更新设置
 */
export async function updateSettings(settings: Record<string, any>): Promise<Record<string, any>> {
  const response = await fetch(`${API_BASE}/api/settings`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(settings),
  });
  
  if (!response.ok) {
    throw new Error(`Update settings failed: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * 获取飞书状态
 */
export async function getFeishuStatus(): Promise<Record<string, any>> {
  const response = await fetch(`${API_BASE}/api/feishu/status`);
  
  if (!response.ok) {
    throw new Error(`Get feishu status failed: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * 启动飞书机器人
 */
export async function startFeishuBot(): Promise<Record<string, any>> {
  const response = await fetch(`${API_BASE}/api/feishu/start`, {
    method: 'POST',
  });
  
  if (!response.ok) {
    throw new Error(`Start feishu bot failed: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * 获取可用模型列表（从后端获取，使用保存的 apiKey）
 */
export async function getModelsFromBackend(): Promise<{ id: string; name: string; provider: string }[]> {
  try {
    const response = await fetch(`${API_BASE}/api/models`);
    
    if (!response.ok) {
      console.error('Failed to fetch models from backend:', response.status);
      return [];
    }
    
    const models = await response.json();
    return models;
  } catch (error) {
    console.error('Failed to get models from backend:', error);
    return [];
  }
}

/**
 * 获取可用模型列表（从 API 动态获取）
 */
export async function getAvailableModels(baseUrl?: string, apiKey?: string): Promise<{ id: string; name: string; provider: string }[]> {
  try {
    // 从设置获取 baseUrl 和 apiKey
    let settings = { baseUrl: '', apiKey: '', hasApiKey: false, model: '' };
    
    if (baseUrl && apiKey) {
      settings = { baseUrl, apiKey, hasApiKey: true, model: '' };
    } else {
      const s = await getSettings();
      // 后端返回驼峰格式
      settings = {
        baseUrl: s.baseUrl || s.base_url || '',
        apiKey: s.apiKey || s.api_key || '',
        hasApiKey: s.hasApiKey || false,
        model: s.model || s.default_model || '',
      };
    }
    
    // 如果没有配置 API Key，返回空数组
    if (!settings.hasApiKey && !settings.apiKey) {
      return [];
    }
    
    // 如果只有 hasApiKey 但没有实际的 apiKey（从后端获取的情况）
    // 需要从后端 /api/models 获取模型列表
    if (settings.hasApiKey && !settings.apiKey) {
      // 调用后端 API 获取模型列表
      const response = await fetch(`${API_BASE}/api/models`);
      if (!response.ok) {
        console.error('Failed to fetch models from backend:', response.status);
        return [];
      }
      return response.json();
    }
    
    const base = (settings.baseUrl || 'https://api.openai.com').replace(/\/$/, '');
    
    const response = await fetch(`${base}/v1/models`, {
      headers: {
        'Authorization': `Bearer ${settings.apiKey}`,
      },
    });
    
    if (!response.ok) {
      console.error('Failed to fetch models:', response.status);
      return [];
    }
    
    const data = await response.json();
    
    // 过滤并格式化模型列表
    const models = (data.data || [])
      .filter((m: any) => {
        // 过滤掉非聊天模型
        const id = m.id.toLowerCase();
        return !id.includes('embed') && 
               !id.includes('whisper') && 
               !id.includes('tts') && 
               !id.includes('dall-e') &&
               !id.includes('moderation');
      })
      .map((m: any) => ({
        id: m.id,
        name: formatModelName(m.id),
        provider: formatProviderName(m.owned_by || m.id.split('/')[0]),
      }))
      .sort((a: any, b: any) => a.name.localeCompare(b.name));
    
    return models;
  } catch (error) {
    console.error('Failed to get models:', error);
    return [];
  }
}

// 格式化模型名称
function formatModelName(id: string): string {
  // 常见模型的友好名称
  const nameMap: Record<string, string> = {
    'gpt-4o': 'GPT-4o',
    'gpt-4o-mini': 'GPT-4o Mini',
    'gpt-4-turbo': 'GPT-4 Turbo',
    'gpt-4': 'GPT-4',
    'gpt-3.5-turbo': 'GPT-3.5 Turbo',
  };
  
  if (nameMap[id]) return nameMap[id];
  
  // 模式匹配
  if (id.includes('claude-3-5-sonnet')) return 'Claude 3.5 Sonnet';
  if (id.includes('claude-3-5-haiku')) return 'Claude 3.5 Haiku';
  if (id.includes('claude-3-opus')) return 'Claude 3 Opus';
  if (id.startsWith('glm-')) return `GLM ${id.replace('glm-', '').toUpperCase()}`;
  if (id.startsWith('deepseek-')) return `DeepSeek ${id.replace('deepseek-', '').toUpperCase()}`;
  if (id.startsWith('gemini-')) return `Gemini ${id.replace('gemini-', '')}`;
  if (id.startsWith('qwen')) return `Qwen ${id.replace('qwen', '')}`;
  
  return id;
}

// 格式化提供商名称
function formatProviderName(owner: string): string {
  const providerMap: Record<string, string> = {
    'openai': 'OpenAI',
    'anthropic': 'Anthropic',
    'google': 'Google',
    'gemini': 'Google',
    'zhipu': '智谱',
    'zhipuai': '智谱',
    'deepseek': 'DeepSeek',
    'moonshot': 'Moonshot',
    'alibaba': '阿里',
    'qwen': '阿里',
  };
  
  return providerMap[owner.toLowerCase()] || owner;
}
