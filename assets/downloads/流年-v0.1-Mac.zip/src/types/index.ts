// ==================== 模型相关 ====================

export interface ModelInfo {
  id: string;
  name: string;
  provider: string;
  description?: string;
}

// ==================== 消息类型 ====================

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
}

// ==================== 用户画像 ====================

export interface UserFact {
  id: string;
  subject: string;     // 例如: "用户"
  predicate: string;   // 例如: "喜欢"
  object: string;      // 例如: "编程"
  createdAt: number;
}

// ==================== 配置 ====================

export interface ApiConfig {
  api_key: string | null;
  base_url: string;
  model: string;
}

export interface MemoryConfig {
  max_turns: number;
  similarity_threshold: number;
}

export interface Config {
  api: ApiConfig;
  memory: MemoryConfig;
  data_dir: string;
}

// ==================== 飞书配置（保留兼容） ====================

export interface FeishuConfig {
  appId: string;
  appSecret: string;
  openId?: string;
}

export interface CliConfig {
  useSystemCli: boolean;
  builtinVersion?: string;
}

export interface ProviderConfig {
  name: string;
  displayName: string;
  configured: boolean;
  link?: string;
  inviteCode?: string;
}

// ==================== 服务状态（保留兼容） ====================

export type ServiceStatus = 'stopped' | 'starting' | 'running' | 'error';

export interface BotServiceState {
  status: ServiceStatus;
  message: string;
  lastStarted?: number;
  error?: string;
}

export interface AppSettings {
  feishu?: FeishuConfig;
  cli: CliConfig;
  zhipuApiKey?: string;
  anthropicApiKey?: string;
}

export interface CliCheckResult {
  available: boolean;
  path: string;
  version?: string;
  error?: string;
}
