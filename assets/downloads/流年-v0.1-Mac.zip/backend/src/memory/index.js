/**
 * Memory System - 记忆系统核心
 * 完整迁移自 Rust 版本
 */

import { nanoid } from 'nanoid';
import episodeStore from '../stores/episode.js';
import factStore from '../stores/fact.js';
import entityStore from '../stores/entity.js';
import blockStore from '../stores/block.js';
import LLMClient from '../llm/client.js';
import MemoryExtractor from '../llm/extractor.js';
import Summarizer from '../llm/summarizer.js';

export class MemorySystem {
  constructor(config) {
    this.config = config;
    this.llm = new LLMClient(config);
    this.extractor = new MemoryExtractor(this.llm);
    this.summarizer = new Summarizer(this.llm);

    // 记忆配置
    this.maxRecentEpisodes = config.maxRecentEpisodes || 10;
    this.maxFactsInContext = config.maxFactsInContext || 20;
    this.enableAutoExtract = config.enableAutoExtract !== false;
    this.enableEmbedding = config.enableEmbedding !== false; // 默认启用

    // 自动压缩配置
    this.lastChatTime = new Map(); // 每个 chatId 的最后聊天时间

    // 生产环境：2 小时未使用触发压缩
    // 开发环境：10 秒（方便测试）
    const isDev = !process.env.NODE_ENV || process.env.NODE_ENV === 'development';
    this.compressionInterval = isDev ? 10 * 1000 : 2 * 60 * 60 * 1000; // 10 秒或 2 小时

    if (isDev) {
      console.log('⚠️  压缩间隔已设置为 10 秒（开发模式）');
    } else {
      console.log('✅ 压缩间隔已设置为 2 小时（生产模式）');
    }
    this.modelContextWindows = {
      'gpt-4o-mini': 128000,
      'gpt-4o': 128000,
      'gpt-4-turbo': 128000,
      'gpt-3.5-turbo': 16385,
      'claude-3-5-sonnet': 200000,
      'claude-3-5-haiku': 200000,
      'glm-4': 128000,
      'glm-4-flash': 128000,
      'default': 128000
    };
  }

  /**
   * 更新配置
   */
  updateConfig(config) {
    this.llm.updateConfig(config);
    if (config.maxRecentEpisodes) this.maxRecentEpisodes = config.maxRecentEpisodes;
    if (config.maxFactsInContext) this.maxFactsInContext = config.maxFactsInContext;
    if (config.enableEmbedding !== undefined) this.enableEmbedding = config.enableEmbedding;
  }

  /**
   * 聊天（带记忆）
   */
  async chat(chatId, userMessage) {
    // 0. 检查并压缩其他会话（如果长时间未使用）
    await this.compressInactiveSessions(chatId);

    // 1. 构建系统提示
    const systemPrompt = this.buildSystemPrompt(chatId);

    // 2. 获取对话历史
    const history = episodeStore.getRecent(chatId, this.maxRecentEpisodes);

    // 3. 构建消息
    const messages = [
      { role: 'system', content: systemPrompt }
    ];

    // 添加历史对话
    for (const ep of history) {
      messages.push({ role: 'user', content: ep.user_message });
      messages.push({ role: 'assistant', content: ep.assistant_response });
    }

    // 添加当前消息
    messages.push({ role: 'user', content: userMessage });

    // 4. 检查是否需要压缩当前会话（基于 token 数）
    await this.compressIfNeeded(chatId, messages);

    // 5. 调用 AI
    const response = await this.llm.chat(messages);

    // 6. 更新最后聊天时间
    this.lastChatTime.set(chatId, Date.now());

    // 7. 保存对话（带 embedding）
    let episodeId;
    if (this.enableEmbedding) {
      try {
        // 生成 embedding
        const textToEmbed = `${userMessage}\n${response}`;
        const embedding = await this.llm.embed(textToEmbed);
        episodeId = episodeStore.save(chatId, userMessage, response, embedding);
      } catch (err) {
        console.error('生成 embedding 失败:', err.message);
        // 失败时降级为无 embedding
        episodeId = episodeStore.save(chatId, userMessage, response);
      }
    } else {
      episodeId = episodeStore.save(chatId, userMessage, response);
    }

    // 8. 异步提取事实（不阻塞）
    if (this.enableAutoExtract) {
      this.extractAndSaveFacts(userMessage, response, episodeId).catch(err => {
        console.error('事实提取失败:', err.message);
      });
    }

    return response;
  }

  /**
   * 构建系统提示
   */
  buildSystemPrompt(chatId) {
    const parts = [];
    
    // 1. 记忆块
    const blocks = blockStore.buildSystemPrompt(2000);
    if (blocks) {
      parts.push(blocks);
    }
    
    // 2. 相关事实
    const facts = factStore.getAll(this.maxFactsInContext);
    if (facts.length > 0) {
      const factsText = facts
        .map(f => `- ${f.subject} ${f.predicate} ${f.object}`)
        .join('\n');
      parts.push(`[已知事实]\n${factsText}`);
    }
    
    // 3. 基础提示
    parts.push(`你是流年，一个有长期记忆的 AI 助手。你会记住用户告诉你的重要信息，并在后续对话中使用。`);
    
    return parts.join('\n\n');
  }

  /**
   * 提取并保存事实
   */
  async extractAndSaveFacts(userMessage, assistantResponse, episodeId) {
    const facts = await this.extractor.extract(userMessage, assistantResponse);
    
    for (const fact of facts) {
      // 检查是否已存在类似事实
      const existing = factStore.searchBySubject(fact.subject);
      const duplicate = existing.find(f => 
        f.predicate === fact.predicate && f.object === fact.object
      );
      
      if (duplicate) {
        // 增加提及次数
        factStore.incrementMentions(duplicate.id);
      } else {
        // 保存新事实（带 embedding）
        if (this.enableEmbedding) {
          try {
            const factText = `${fact.subject} ${fact.predicate} ${fact.object}`;
            const embedding = await this.llm.embed(factText);
            factStore.save(fact.subject, fact.predicate, fact.object, episodeId, 1.0, embedding);
          } catch (err) {
            console.error('生成事实 embedding 失败:', err.message);
            factStore.save(fact.subject, fact.predicate, fact.object, episodeId);
          }
        } else {
          factStore.save(fact.subject, fact.predicate, fact.object, episodeId);
        }
      }
    }
    
    // 提取实体
    const entities = await this.extractor.extractEntities(userMessage + ' ' + assistantResponse);
    for (const entity of entities) {
      entityStore.upsert(entity.name, entity.type);
    }
  }

  /**
   * 手动添加事实
   */
  addFact(subject, predicate, object) {
    return factStore.save(subject, predicate, object, 'manual');
  }

  /**
   * 搜索记忆
   */
  async searchMemory(query) {
    let episodes, facts, entities;
    
    // 如果启用 embedding，使用向量搜索
    if (this.enableEmbedding) {
      try {
        const queryEmbedding = await this.llm.embed(query);
        episodes = episodeStore.searchByVector(queryEmbedding, 5);
        facts = factStore.searchByVector(queryEmbedding, 5);
      } catch (err) {
        console.error('向量搜索失败，降级为关键词搜索:', err.message);
        episodes = episodeStore.search(query, 5);
        facts = factStore.search(query, 5);
      }
    } else {
      // 关键词搜索
      episodes = episodeStore.search(query, 5);
      facts = factStore.search(query, 5);
    }
    
    entities = entityStore.search(query, 5);
    
    return { episodes, facts, entities };
  }

  /**
   * 获取所有记忆（前端期望的格式）
   */
  getAllMemory() {
    const memories = [];

    // 1. 转换 episodes
    const episodes = episodeStore.getAll(100);
    for (const ep of episodes) {
      memories.push({
        id: ep.id,
        content: `${ep.user_message}\n${ep.assistant_response}`,
        category: 'event',
        importance: 0.8,
        created_at: Math.floor(new Date(ep.created_at).getTime() / 1000)
      });
    }

    // 2. 转换 facts
    const facts = factStore.getAll(100);
    for (const fact of facts) {
      memories.push({
        id: fact.id,
        content: `${fact.subject} ${fact.predicate} ${fact.object}`,
        category: 'knowledge',
        importance: Math.min(fact.mentions * 0.1 + 0.5, 1.0),
        created_at: Math.floor(new Date(fact.created_at).getTime() / 1000)
      });
    }

    // 3. 转换 entities
    const entities = entityStore.getAll(100);
    for (const entity of entities) {
      memories.push({
        id: entity.id,
        content: `${entity.name} (${entity.type})`,
        category: 'profile',
        importance: 0.7,
        created_at: Math.floor(new Date(entity.created_at).getTime() / 1000)
      });
    }

    // 4. 转换 blocks
    const blocks = blockStore.getAll();
    for (const block of blocks) {
      memories.push({
        id: block.label,
        content: block.value,
        category: 'general',
        importance: 0.9,
        created_at: Math.floor(Date.now() / 1000)
      });
    }

    // 按时间排序（最新的在前）
    memories.sort((a, b) => b.created_at - a.created_at);

    return memories;
  }

  /**
   * 清空对话历史
   */
  clearHistory(chatId) {
    // better-sqlite3 没有异步 API，这里简化处理
    // 实际可以用 db.prepare().run()
    console.log('清空历史:', chatId);
  }

  /**
   * 更新记忆块
   */
  updateBlock(label, value) {
    blockStore.update(label, value);
  }

  /**
   * 获取记忆块
   */
  getBlock(label) {
    return blockStore.get(label);
  }

  /**
   * 删除单条记忆
   */
  deleteMemory(id) {
    // 尝试从各个 store 删除
    const deleted = 
      episodeStore.delete(id) ||
      factStore.delete(id) ||
      entityStore.delete(id) ||
      blockStore.delete(id);
    
    return deleted;
  }

  /**
   * 修改单条记忆
   */
  updateMemory(id, content, category) {
    // 根据类别处理
    if (category === 'knowledge') {
      // 事实：解析 content（格式：subject predicate object）
      const parts = content.split(' ').filter(p => p);
      if (parts.length >= 3) {
        return factStore.update(id, parts[0], parts[1], parts.slice(2).join(' '));
      }
    } else if (category === 'general') {
      // 记忆块：直接更新值
      return blockStore.update(id, content);
    } else if (category === 'profile') {
      // 实体：更新摘要
      return entityStore.updateSummary(id, content);
    }
    return false;
  }

  /**
   * 手动添加记忆（通用接口）
   */
  addMemory(content, category = 'general', importance = 0.8) {
    const id = nanoid();
    const now = Math.floor(Date.now() / 1000);
    
    if (category === 'knowledge') {
      // 事实：解析 content
      const parts = content.split(' ').filter(p => p);
      if (parts.length >= 3) {
        const factId = factStore.save(parts[0], parts[1], parts.slice(2).join(' '), 'manual', importance);
        return {
          id: factId,
          content,
          category,
          importance,
          created_at: now
        };
      }
    } else if (category === 'general') {
      // 记忆块：创建或更新
      const label = `custom_${id}`;
      blockStore.create(label, content, '用户手动添加');
      return {
        id: label,
        content,
        category,
        importance,
        created_at: now
      };
    } else if (category === 'profile') {
      // 实体
      const match = content.match(/(.+?)\s*\((.+?)\)/);
      if (match) {
        const entityId = entityStore.upsert(match[1], match[2], '');
        return {
          id: entityId,
          content,
          category,
          importance,
          created_at: now
        };
      }
    }
    
    // 默认返回
    return {
      id,
      content,
      category,
      importance,
      created_at: now
    };
  }

  /**
   * 清空所有记忆
   */
  clearAllMemory() {
    episodeStore.clear();
    factStore.clear();
    entityStore.clear();
    // 不清空 blocks，因为那是系统配置
    console.log('✅ 所有记忆已清空');
  }

  /**
   * 获取模型的上下文窗口大小
   */
  getModelContextWindow(model) {
    return this.modelContextWindows[model] || this.modelContextWindows['default'];
  }

  /**
   * 估算消息的 token 数（简单估算：1 token ≈ 4 字符）
   */
  estimateTokens(messages) {
    const text = messages.map(m => m.content).join('');
    return Math.ceil(text.length / 4);
  }

  /**
   * 压缩不活跃的会话
   */
  async compressInactiveSessions(currentChatId) {
    const now = Date.now();

    for (const [chatId, lastTime] of this.lastChatTime.entries()) {
      // 跳过当前会话
      if (chatId === currentChatId) continue;

      // 检查是否超过 2 小时未使用
      if (now - lastTime > this.compressionInterval) {
        try {
          await this.compressSession(chatId);
          console.log(`✅ 会话 ${chatId} 已压缩（${Math.floor((now - lastTime) / 1000 / 60)} 分钟未使用）`);
        } catch (err) {
          console.error(`压缩会话 ${chatId} 失败:`, err.message);
        }
      }
    }
  }

  /**
   * 压缩单个会话
   */
  async compressSession(chatId) {
    // 获取所有对话
    const allEpisodes = episodeStore.getRecent(chatId, 1000);

    if (allEpisodes.length < 5) {
      return; // 太少了，不压缩
    }

    // 保留最近 5 条
    const recentEpisodes = allEpisodes.slice(-5);
    const oldEpisodes = allEpisodes.slice(0, -5);

    if (oldEpisodes.length === 0) {
      return;
    }

    // 生成摘要
    const summary = await this.summarizer.summarizeEpisodes(oldEpisodes);

    if (!summary) {
      return;
    }

    // 将摘要保存为记忆块
    const blockLabel = `summary_${chatId}_${Date.now()}`;
    blockStore.create(blockLabel, summary, `会话 ${chatId} 的历史摘要`);

    // 删除相关的事实（避免外键约束错误）
    for (const ep of oldEpisodes) {
      factStore.deleteByEpisode(ep.id);
    }

    // 删除旧的对话
    for (const ep of oldEpisodes) {
      episodeStore.delete(ep.id);
    }

    console.log(`✅ 会话 ${chatId} 已压缩：${oldEpisodes.length} 条对话 → 1 条摘要`);
  }

  /**
   * 如果需要则压缩当前会话（基于 token 数）
   */
  async compressIfNeeded(chatId, messages) {
    const contextWindow = this.getModelContextWindow(this.config.model);
    const currentTokens = this.estimateTokens(messages);

    // 如果超过上下文窗口的 70%，触发压缩
    if (currentTokens > contextWindow * 0.7) {
      console.log(`⚠️ 会话 ${chatId} 接近上下文限制：${currentTokens} / ${contextWindow} tokens`);

      // 压缩策略：保留最近 5 条，压缩旧的
      await this.compressSession(chatId);
    }
  }
}

export default MemorySystem;
