/**
 * 数据库 Schema - 完整迁移自 Rust 版本
 */

export const CREATE_TABLES = `
-- Episodes (对话历史)
CREATE TABLE IF NOT EXISTS episodes (
    id TEXT PRIMARY KEY,
    chat_id TEXT NOT NULL,
    user_message TEXT NOT NULL,
    assistant_response TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    embedding BLOB
);

CREATE INDEX IF NOT EXISTS idx_episodes_chat ON episodes(chat_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_episodes_created ON episodes(created_at DESC);

-- Facts (事实)
CREATE TABLE IF NOT EXISTS facts (
    id TEXT PRIMARY KEY,
    subject TEXT NOT NULL,
    predicate TEXT NOT NULL,
    object TEXT NOT NULL,
    valid_at TIMESTAMP NOT NULL,
    invalid_at TIMESTAMP,
    source_episode TEXT NOT NULL,
    confidence REAL DEFAULT 1.0,
    mention_count INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    embedding BLOB,
    FOREIGN KEY (source_episode) REFERENCES episodes(id)
);

CREATE INDEX IF NOT EXISTS idx_facts_subject ON facts(subject);
CREATE INDEX IF NOT EXISTS idx_facts_valid ON facts(invalid_at, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_facts_source ON facts(source_episode);
CREATE INDEX IF NOT EXISTS idx_facts_confidence ON facts(confidence DESC);

-- Entities (实体)
CREATE TABLE IF NOT EXISTS entities (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    type TEXT NOT NULL,
    summary TEXT,
    mention_count INTEGER DEFAULT 1,
    first_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_mentioned TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    embedding BLOB
);

CREATE INDEX IF NOT EXISTS idx_entities_name ON entities(name);
CREATE INDEX IF NOT EXISTS idx_entities_mentions ON entities(mention_count DESC);

-- Memory Blocks (记忆块)
CREATE TABLE IF NOT EXISTS memory_blocks (
    id TEXT PRIMARY KEY,
    label TEXT NOT NULL UNIQUE,
    description TEXT NOT NULL,
    value TEXT DEFAULT '',
    "limit" INTEGER DEFAULT 500,
    priority INTEGER DEFAULT 5,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_blocks_priority ON memory_blocks(priority DESC);
CREATE INDEX IF NOT EXISTS idx_blocks_label ON memory_blocks(label);

-- Config (配置)
CREATE TABLE IF NOT EXISTS config (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Graph Nodes (图谱节点)
CREATE TABLE IF NOT EXISTS graph_nodes (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    type TEXT NOT NULL,
    properties TEXT DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_graph_nodes_name ON graph_nodes(name);
CREATE INDEX IF NOT EXISTS idx_graph_nodes_type ON graph_nodes(type);

-- Graph Edges (图谱边)
CREATE TABLE IF NOT EXISTS graph_edges (
    id TEXT PRIMARY KEY,
    source_id TEXT NOT NULL,
    target_id TEXT NOT NULL,
    relation TEXT NOT NULL,
    weight REAL DEFAULT 1.0,
    temporal TEXT,
    context TEXT,
    confidence REAL DEFAULT 1.0,
    source_episode TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (source_id) REFERENCES graph_nodes(id),
    FOREIGN KEY (target_id) REFERENCES graph_nodes(id),
    FOREIGN KEY (source_episode) REFERENCES episodes(id)
);

CREATE INDEX IF NOT EXISTS idx_graph_edges_source ON graph_edges(source_id);
CREATE INDEX IF NOT EXISTS idx_graph_edges_target ON graph_edges(target_id);
CREATE INDEX IF NOT EXISTS idx_graph_edges_relation ON graph_edges(relation);

-- Feishu Bindings (飞书绑定)
CREATE TABLE IF NOT EXISTS feishu_bindings (
    open_id TEXT PRIMARY KEY,
    user_info TEXT DEFAULT '{}',
    bind_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_feishu_bindings_open_id ON feishu_bindings(open_id);
`;
