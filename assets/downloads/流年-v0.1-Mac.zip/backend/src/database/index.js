/**
 * 数据库初始化
 */

import Database from 'better-sqlite3';
import { join } from 'path';
import { existsSync, mkdirSync } from 'fs';
import { CREATE_TABLES } from './schema.js';

const CONFIG_DIR = join(process.env.HOME || '', '.liunian');
const DB_FILE = join(CONFIG_DIR, 'memory.db');

// 确保配置目录存在
if (!existsSync(CONFIG_DIR)) {
  mkdirSync(CONFIG_DIR, { recursive: true });
}

// 创建数据库连接
const db = new Database(DB_FILE);

// 启用 WAL 模式和外键约束
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// 初始化表结构
db.exec(CREATE_TABLES);

console.log('✅ 数据库已初始化:', DB_FILE);

export default db;
