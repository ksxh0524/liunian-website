/**
 * LLM Client - AI 调用客户端
 */

import { Agent, setGlobalDispatcher } from 'undici';

// 禁用 SSL 验证（仅开发环境）
setGlobalDispatcher(new Agent({
  connect: {
    rejectUnauthorized: false
  }
}));

export class LLMClient {
  constructor(config) {
    this.baseUrl = config.baseUrl || 'https://api.n1n.ai';
    this.apiKey = config.apiKey || '';
    this.model = config.model || 'gpt-4o-mini';
    this.embeddingModel = config.embeddingModel || 'text-embedding-3-small';
    this.embeddingBaseUrl = config.embeddingBaseUrl || config.baseUrl || 'https://api.n1n.ai';
  }

  /**
   * 更新配置
   */
  updateConfig(config) {
    if (config.baseUrl) this.baseUrl = config.baseUrl;
    if (config.apiKey) this.apiKey = config.apiKey;
    if (config.model) this.model = config.model;
    if (config.embeddingModel) this.embeddingModel = config.embeddingModel;
    if (config.embeddingBaseUrl) this.embeddingBaseUrl = config.embeddingBaseUrl;
  }

  /**
   * 聊天
   */
  async chat(messages, options = {}) {
    if (!this.apiKey) {
      throw new Error('API Key 未配置');
    }

    const response = await fetch(`${this.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`
      },
      body: JSON.stringify({
        model: options.model || this.model,
        messages,
        max_tokens: options.maxTokens || 1000,
        temperature: options.temperature ?? 0.7,
        ...options
      })
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`AI API 错误: ${response.status} - ${error}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  }

  /**
   * 获取嵌入向量
   */
  async embed(text) {
    if (!this.apiKey) {
      throw new Error('API Key 未配置');
    }

    const response = await fetch(`${this.embeddingBaseUrl}/v1/embeddings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`
      },
      body: JSON.stringify({
        model: this.embeddingModel,
        input: text
      })
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Embedding API 错误: ${response.status} - ${error}`);
    }

    const data = await response.json();
    return data.data[0].embedding;
  }

  /**
   * 获取可用模型列表
   */
  async getModels() {
    if (!this.apiKey) return [];

    const response = await fetch(`${this.baseUrl}/v1/models`, {
      headers: { 'Authorization': `Bearer ${this.apiKey}` }
    });

    if (!response.ok) return [];

    const data = await response.json();
    return (data.data || [])
      .filter(m => !m.id.includes('embed') && !m.id.includes('whisper') && !m.id.includes('tts'))
      .map(m => ({ id: m.id, name: m.id, provider: m.owned_by || 'Unknown' }));
  }
}

export default LLMClient;
