/**
 * Summarizer - 摘要生成器
 * 对长对话进行摘要压缩
 */

export class Summarizer {
  constructor(llmClient) {
    this.llm = llmClient;
  }

  /**
   * 摘要对话历史
   */
  async summarizeEpisodes(episodes) {
    if (episodes.length === 0) return '';

    const conversationText = episodes
      .map(ep => `用户: ${ep.user_message}\n助手: ${ep.assistant_response}`)
      .join('\n\n');

    const prompt = `请对以下对话历史进行简洁的摘要，保留关键信息：

${conversationText}

要求：
1. 保留重要的事实和决定
2. 保留用户的偏好和需求
3. 删除无关的寒暄和重复内容
4. 使用简洁的语言
5. 控制在 200 字以内`;

    try {
      const summary = await this.llm.chat([
        { role: 'system', content: '你是一个专业的对话摘要助手。' },
        { role: 'user', content: prompt }
      ], { maxTokens: 300, temperature: 0.5 });

      return summary;
    } catch (error) {
      console.error('摘要生成失败:', error.message);
      return '';
    }
  }

  /**
   * 摘要事实列表
   */
  async summarizeFacts(facts) {
    if (facts.length === 0) return '';

    const factsText = facts
      .map(f => `${f.subject} ${f.predicate} ${f.object}`)
      .join('\n');

    const prompt = `请将以下事实整合成一段连贯的描述：

${factsText}

要求：
1. 合并重复或相关的事实
2. 按主题分组
3. 使用自然语言
4. 控制在 150 字以内`;

    try {
      const summary = await this.llm.chat([
        { role: 'system', content: '你是一个信息整合助手。' },
        { role: 'user', content: prompt }
      ], { maxTokens: 200, temperature: 0.5 });

      return summary;
    } catch (error) {
      console.error('事实摘要失败:', error.message);
      return '';
    }
  }
}

export default Summarizer;
