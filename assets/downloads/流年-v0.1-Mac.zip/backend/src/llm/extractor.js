/**
 * Memory Extractor - 事实提取器
 * 从对话中自动提取重要事实
 */

export class MemoryExtractor {
  constructor(llmClient) {
    this.llm = llmClient;
  }

  /**
   * 从对话中提取事实
   */
  async extract(userMessage, assistantResponse) {
    const prompt = `分析以下对话，提取重要的长期记忆事实。

用户: ${userMessage}
助手: ${assistantResponse}

请提取以下类型的信息：
1. 用户偏好（喜欢/不喜欢什么）
2. 用户信息（姓名、职业、位置等）
3. 重要事件（时间、地点、人物）
4. 关系信息（用户与他人的关系）

【重要】必须严格遵守以下JSON格式，不要添加任何其他文本：
[
  {"subject": "用户", "predicate": "喜欢", "object": "编程"},
  {"subject": "用户", "predicate": "职业是", "object": "程序员"}
]

如果没有重要事实，返回空数组 []。
现在请直接返回JSON数组，不要任何解释：`;

    let result = '';
    try {
      result = await this.llm.chat([
        { role: 'system', content: '你是一个信息提取专家。你必须只返回严格的JSON格式，不要添加任何其他文本。' },
        { role: 'user', content: prompt }
      ], { maxTokens: 500, temperature: 0.3 });

      // 尝试提取 JSON 部分
      let jsonStr = result.trim();

      // 尝试找到 JSON 数组的开始和结束
      const jsonMatch = jsonStr.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        jsonStr = jsonMatch[0];
      }

      // 解析 JSON
      const facts = JSON.parse(jsonStr);
      return Array.isArray(facts) ? facts : [];
    } catch (error) {
      console.error('事实提取失败:', error.message);
      if (result) {
        console.error('原始响应:', result.substring(0, 200));
      }
      return [];
    }
  }

  /**
   * 提取实体
   */
  async extractEntities(text) {
    const prompt = `从以下文本中提取实体（人名、地点、组织、概念等）：

${text}

【重要】必须严格遵守以下JSON格式，不要添加任何其他文本：
[
  {"name": "张三", "type": "person"},
  {"name": "北京", "type": "location"}
]

现在请直接返回JSON数组，不要任何解释：`;

    let result = '';
    try {
      result = await this.llm.chat([
        { role: 'system', content: '你是一个实体识别专家。你必须只返回严格的JSON格式，不要添加任何其他文本。' },
        { role: 'user', content: prompt }
      ], { maxTokens: 300, temperature: 0.2 });

      // 尝试提取 JSON 部分
      let jsonStr = result.trim();

      // 尝试找到 JSON 数组的开始和结束
      const jsonMatch = jsonStr.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        jsonStr = jsonMatch[0];
      }

      const entities = JSON.parse(jsonStr);
      return Array.isArray(entities) ? entities : [];
    } catch (error) {
      console.error('实体提取失败:', error.message);
      if (result) {
        console.error('原始响应:', result.substring(0, 200));
      }
      return [];
    }
  }
}

export default MemoryExtractor;
