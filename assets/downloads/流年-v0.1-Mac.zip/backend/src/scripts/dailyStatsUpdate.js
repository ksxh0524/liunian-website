#!/bin/bash

# 流年 v0.1 - 每日数据统计更新脚本
# 用法: ./dailyStatsUpdate.sh

set -e

echo "========================================"
echo "  流年 - 每日数据统计更新"
echo "  $(date '+%Y-%m-%d %H:%M:%S')"
echo "========================================"
echo ""

# 切换到后端目录
cd "$(dirname "$0")/.."

# 读取配置（从 localStorage 或配置文件）
# TODO: 实现配置读取逻辑

# 调用后端 API 拉取数据
echo "📊 拉取数据..."
curl -X POST http://localhost:3001/api/stats/fetch \
  -H "Content-Type: application/json" \
  -d '{
    "youtube": { "channelId": "YOUR_CHANNEL_ID" },
    "bilibili": { "mid": "YOUR_MID" },
    "twitter": { "username": "YOUR_USERNAME" }
  }'

echo ""
echo "✅ 数据更新完成"
echo ""

# TODO: 同步到飞书多维表格
# echo "📤 同步到飞书多维表格..."
# node syncToFeishu.js

echo "========================================"
