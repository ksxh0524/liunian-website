#!/usr/bin/env node
/**
 * 流年 - 社交媒体数据统计定时任务
 * 每小时自动拉取数据并更新到飞书多维表格
 */

import axios from 'axios';
import { readFileSync, writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const CONFIG_FILE = join(__dirname, '../../../.openclaw/workspace/stats-accounts.json');

// 读取配置
function loadConfig() {
  try {
    const data = readFileSync(CONFIG_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error('❌ 配置文件读取失败:', error.message);
    return null;
  }
}

// 保存配置
function saveConfig(config) {
  try {
    writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
    console.log('✅ 配置已保存');
  } catch (error) {
    console.error('❌ 配置保存失败:', error.message);
  }
}

// 拉取 B站数据
async function fetchBilibili(mid) {
  if (!mid) return null;
  
  try {
    const response = await axios.get(`https://api.bilibili.com/x/relation/stat?vmid=${mid}`);
    const data = response.data.data;
    
    return {
      platform: 'bilibili',
      mid: mid,
      followers: data.follower || 0,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error('❌ B站数据获取失败:', error.message);
    return null;
  }
}

// 拉取 YouTube数据
async function fetchYouTube(channelId, apiKey) {
  if (!channelId || !apiKey) return null;
  
  try {
    const url = `https://www.googleapis.com/youtube/v3/channels?part=statistics&id=${channelId}&key=${apiKey}`;
    const response = await axios.get(url);
    const data = response.data.items[0].statistics;
    
    return {
      platform: 'youtube',
      channelId: channelId,
      subscribers: parseInt(data.subscriberCount) || 0,
      views: parseInt(data.viewCount) || 0,
      videoCount: parseInt(data.videoCount) || 0,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error('❌ YouTube数据获取失败:', error.message);
    return null;
  }
}

// 拉取 X (Twitter)数据
async function fetchTwitter(username, bearerToken) {
  if (!username || !bearerToken) return null;
  
  try {
    const url = `https://api.twitter.com/2/users/by/username/${username}?user.fields=public_metrics`;
    const response = await axios.get(url, {
      headers: { Authorization: `Bearer ${bearerToken}` }
    });
    const metrics = response.data.data.public_metrics;
    
    return {
      platform: 'twitter',
      username: username,
      followers: metrics.followers_count || 0,
      tweets: metrics.tweet_count || 0,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    console.error('❌ X数据获取失败:', error.message);
    return null;
  }
}

// 更新飞书多维表格
async function updateFeishuBitable(appToken, tableId, data) {
  if (!appToken || !tableId) {
    console.log('⚠️  飞书多维表格未配置，跳过更新');
    return;
  }
  
  // TODO: 调用飞书 API 更新表格
  console.log('📊 更新飞书多维表格:', { appToken, tableId, data });
}

// 主函数
async function main() {
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('  📊 流年 - 社交媒体数据统计');
  console.log('  时间:', new Date().toLocaleString('zh-CN'));
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('');
  
  const config = loadConfig();
  if (!config) {
    console.error('❌ 配置加载失败');
    process.exit(1);
  }
  
  const results = [];
  
  // 拉取所有平台数据
  for (const account of config.accounts) {
    console.log(`\n📥 拉取 ${account.name} 数据...`);
    
    let data = null;
    switch (account.platform) {
      case 'bilibili':
        data = await fetchBilibili(account.mid);
        break;
      case 'youtube':
        data = await fetchYouTube(account.channelId, process.env.YOUTUBE_API_KEY);
        break;
      case 'twitter':
        data = await fetchTwitter(account.username, process.env.TWITTER_BEARER_TOKEN);
        break;
    }
    
    if (data) {
      results.push(data);
      console.log(`✅ ${account.name}:`, data);
    } else {
      console.log(`⚠️  ${account.name}: 暂无数据（可能未配置）`);
    }
  }
  
  // 更新飞书多维表格
  if (results.length > 0 && config.feishuBitable.appToken) {
    await updateFeishuBitable(
      config.feishuBitable.appToken,
      config.feishuBitable.tableId,
      results
    );
  }
  
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`✅ 完成！共拉取 ${results.length} 个平台数据`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
}

main().catch(console.error);
