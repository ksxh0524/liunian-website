/**
 * Memory Block Store - 记忆块存储
 */

import db from '../database/index.js';

// 默认记忆块
const DEFAULT_BLOCKS = [
  { label: 'core', description: '核心身份和行为准则', value: '', limit: 1000, priority: 1 },
  { label: 'user', description: '用户偏好和设置', value: '', limit: 500, priority: 2 },
  { label: 'facts', description: '关键事实和关系', value: '', limit: 1000, priority: 3 },
  { label: 'episodes', description: '重要对话摘要', value: '', limit: 2000, priority: 4 },
  { label: 'context', description: '当前上下文', value: '', limit: 500, priority: 5 },
];

export class BlockStore {
  constructor() {
    this.initDefaults();
  }

  /**
   * 初始化默认记忆块
   */
  initDefaults() {
    const existing = db.prepare(`SELECT COUNT(*) as count FROM memory_blocks`).get();
    if (existing.count === 0) {
      const stmt = db.prepare(`
        INSERT INTO memory_blocks (label, description, value, "limit", priority)
        VALUES (?, ?, ?, ?, ?)
      `);
      for (const block of DEFAULT_BLOCKS) {
        stmt.run(block.label, block.description, block.value, block.limit, block.priority);
      }
    }
  }

  /**
   * 获取记忆块
   */
  get(label) {
    return db.prepare(`SELECT * FROM memory_blocks WHERE label = ?`).get(label);
  }

  /**
   * 获取所有记忆块（按优先级排序）
   */
  getAll() {
    return db.prepare(`SELECT * FROM memory_blocks ORDER BY priority ASC`).all();
  }

  /**
   * 更新记忆块值
   */
  update(label, value) {
    const stmt = db.prepare(`
      UPDATE memory_blocks SET value = ?, updated_at = datetime('now')
      WHERE label = ?
    `);
    stmt.run(value, label);
  }

  /**
   * 创建新的记忆块
   */
  create(label, value, description = '') {
    try {
      const stmt = db.prepare(`
        INSERT INTO memory_blocks (label, description, value, "limit", priority)
        VALUES (?, ?, ?, 500, 10)
      `);
      stmt.run(label, description, value);
      return true;
    } catch (error) {
      console.error('创建记忆块失败:', error);
      return false;
    }
  }

  /**
   * 构建系统提示（所有记忆块拼接）
   */
  buildSystemPrompt(maxChars = 4000) {
    const blocks = this.getAll();
    let result = '';
    
    for (const block of blocks) {
      if (block.value && block.value.trim()) {
        const section = `[${block.label}]\n${block.value}\n\n`;
        if (result.length + section.length > maxChars) break;
        result += section;
      }
    }
    
    return result.trim();
  }

  /**
   * 删除记忆块
   */
  delete(label) {
    try {
      // 不允许删除默认块，只清空值
      const stmt = db.prepare(`UPDATE memory_blocks SET value = '' WHERE label = ?`);
      stmt.run(label);
      return true;
    } catch (error) {
      console.error('删除记忆块失败:', error);
      return false;
    }
  }
}

export default new BlockStore();
