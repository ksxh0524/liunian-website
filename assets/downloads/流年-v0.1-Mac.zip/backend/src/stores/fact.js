/**
 * Fact Store - 事实存储
 */

import { nanoid } from 'nanoid';
import db from '../database/index.js';

/**
 * 计算余弦相似度
 */
function cosineSimilarity(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  
  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  
  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

export class FactStore {
  /**
   * 保存事实
   */
  save(subject, predicate, object, sourceEpisode, confidence = 1.0, embedding = null) {
    const id = nanoid();
    const embeddingBlob = embedding ? Buffer.from(new Float32Array(embedding).buffer) : null;
    
    // 确保 source_episode 存在（外键约束）
    const episodeExists = db.prepare('SELECT 1 FROM episodes WHERE id = ?').get(sourceEpisode);
    if (!episodeExists) {
      // 创建占位 episode 以满足外键约束
      db.prepare(`
        INSERT OR IGNORE INTO episodes (id, chat_id, user_message, assistant_response)
        VALUES (?, 'system', 'manual entry', 'manual entry')
      `).run(sourceEpisode);
    }
    
    const stmt = db.prepare(`
      INSERT INTO facts (id, subject, predicate, object, valid_at, source_episode, confidence, embedding)
      VALUES (?, ?, ?, ?, datetime('now'), ?, ?, ?)
    `);
    stmt.run(id, subject, predicate, object, sourceEpisode, confidence, embeddingBlob);
    return id;
  }

  /**
   * 更新 embedding
   */
  updateEmbedding(id, embedding) {
    const embeddingBlob = Buffer.from(new Float32Array(embedding).buffer);
    const stmt = db.prepare(`
      UPDATE facts SET embedding = ? WHERE id = ?
    `);
    stmt.run(embeddingBlob, id);
  }

  /**
   * 搜索事实
   */
  searchBySubject(subject) {
    const stmt = db.prepare(`
      SELECT * FROM facts
      WHERE subject = ? AND invalid_at IS NULL
      ORDER BY confidence DESC, created_at DESC
    `);
    return stmt.all(subject);
  }

  /**
   * 搜索相关事实（关键词）
   */
  search(query, limit = 10) {
    const stmt = db.prepare(`
      SELECT * FROM facts
      WHERE (subject LIKE ? OR object LIKE ?) AND invalid_at IS NULL
      ORDER BY confidence DESC, mention_count DESC
      LIMIT ?
    `);
    const pattern = `%${query}%`;
    return stmt.all(pattern, pattern, limit);
  }

  /**
   * 向量搜索事实
   */
  searchByVector(embedding, limit = 10) {
    const stmt = db.prepare(`
      SELECT * FROM facts
      WHERE invalid_at IS NULL AND embedding IS NOT NULL
      ORDER BY confidence DESC, mention_count DESC
    `);
    const facts = stmt.all();
    
    // 计算余弦相似度
    const results = facts.map(fact => {
      if (!fact.embedding) return null;
      // 正确地从 Buffer 恢复 Float32Array
      const buffer = Buffer.isBuffer(fact.embedding) ? fact.embedding : Buffer.from(fact.embedding);
      const factEmbedding = Array.from(new Float32Array(buffer.buffer, buffer.byteOffset, buffer.length / 4));
      const similarity = cosineSimilarity(embedding, factEmbedding);
      return { ...fact, similarity };
    }).filter(r => r !== null && r.similarity > 0.3) // 降低阈值到 0.3
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, limit);
    
    return results;
  }

  /**
   * 使事实失效
   */
  invalidate(factId) {
    const stmt = db.prepare(`
      UPDATE facts SET invalid_at = datetime('now')
      WHERE id = ?
    `);
    stmt.run(factId);
  }

  /**
   * 增加提及次数
   */
  incrementMentions(factId) {
    const stmt = db.prepare(`
      UPDATE facts SET mention_count = mention_count + 1
      WHERE id = ?
    `);
    stmt.run(factId);
  }

  /**
   * 获取所有有效事实
   */
  getAll(limit = 100) {
    const stmt = db.prepare(`
      SELECT * FROM facts
      WHERE invalid_at IS NULL
      ORDER BY confidence DESC, mention_count DESC
      LIMIT ?
    `);
    return stmt.all(limit);
  }

  /**
   * 删除单条事实
   */
  delete(id) {
    try {
      const stmt = db.prepare('DELETE FROM facts WHERE id = ?');
      const result = stmt.run(id);
      return result.changes > 0;
    } catch (error) {
      console.error('删除事实失败:', error);
      return false;
    }
  }

  /**
   * 删除某个对话相关的所有事实
   */
  deleteByEpisode(episodeId) {
    try {
      const stmt = db.prepare('DELETE FROM facts WHERE source_episode = ?');
      const result = stmt.run(episodeId);
      return result.changes;
    } catch (error) {
      console.error('删除对话相关事实失败:', error);
      return 0;
    }
  }

  /**
   * 更新事实
   */
  update(id, subject, predicate, object) {
    try {
      const stmt = db.prepare(`
        UPDATE facts SET 
          subject = ?, 
          predicate = ?, 
          object = ?
        WHERE id = ?
      `);
      const result = stmt.run(subject, predicate, object, id);
      return result.changes > 0;
    } catch (error) {
      console.error('更新事实失败:', error);
      return false;
    }
  }

  /**
   * 清空所有事实
   */
  clear() {
    try {
      const stmt = db.prepare('DELETE FROM facts');
      stmt.run();
      console.log('✅ 所有事实已清空');
    } catch (error) {
      console.error('清空事实失败:', error);
    }
  }
}

export default new FactStore();
