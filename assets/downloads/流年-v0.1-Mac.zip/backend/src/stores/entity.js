/**
 * Entity Store - 实体存储
 */

import { nanoid } from 'nanoid';
import db from '../database/index.js';

export class EntityStore {
  /**
   * 创建或更新实体
   */
  upsert(name, type = 'unknown', summary = '') {
    // 先检查是否存在
    const existing = db.prepare(`SELECT * FROM entities WHERE name = ?`).get(name);
    
    if (existing) {
      // 更新
      const stmt = db.prepare(`
        UPDATE entities SET
          mention_count = mention_count + 1,
          last_mentioned = datetime('now'),
          summary = CASE WHEN ? != '' THEN ? ELSE summary END
        WHERE name = ?
      `);
      stmt.run(summary, summary, name);
      return existing.id;
    } else {
      // 创建
      const id = nanoid();
      const stmt = db.prepare(`
        INSERT INTO entities (id, name, type, summary)
        VALUES (?, ?, ?, ?)
      `);
      stmt.run(id, name, type, summary);
      return id;
    }
  }

  /**
   * 获取实体
   */
  get(name) {
    return db.prepare(`SELECT * FROM entities WHERE name = ?`).get(name);
  }

  /**
   * 搜索实体
   */
  search(query, limit = 10) {
    const stmt = db.prepare(`
      SELECT * FROM entities
      WHERE name LIKE ? OR summary LIKE ?
      ORDER BY mention_count DESC
      LIMIT ?
    `);
    const pattern = `%${query}%`;
    return stmt.all(pattern, pattern, limit);
  }

  /**
   * 获取所有实体
   */
  getAll(limit = 100) {
    return db.prepare(`
      SELECT * FROM entities
      ORDER BY mention_count DESC
      LIMIT ?
    `).all(limit);
  }

  /**
   * 删除单条实体
   */
  delete(id) {
    try {
      const stmt = db.prepare('DELETE FROM entities WHERE id = ?');
      const result = stmt.run(id);
      return result.changes > 0;
    } catch (error) {
      console.error('删除实体失败:', error);
      return false;
    }
  }

  /**
   * 更新实体摘要
   */
  updateSummary(id, summary) {
    try {
      const stmt = db.prepare(`
        UPDATE entities SET summary = ? WHERE id = ?
      `);
      const result = stmt.run(summary, id);
      return result.changes > 0;
    } catch (error) {
      console.error('更新实体失败:', error);
      return false;
    }
  }

  /**
   * 清空所有实体
   */
  clear() {
    try {
      const stmt = db.prepare('DELETE FROM entities');
      stmt.run();
      console.log('✅ 所有实体已清空');
    } catch (error) {
      console.error('清空实体失败:', error);
    }
  }
}

export default new EntityStore();
