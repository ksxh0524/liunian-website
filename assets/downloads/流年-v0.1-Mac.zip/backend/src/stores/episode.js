/**
 * Episode Store - 对话历史存储
 */

import { nanoid } from 'nanoid';
import db from '../database/index.js';

/**
 * 计算余弦相似度
 */
function cosineSimilarity(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  
  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  
  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

export class EpisodeStore {
  /**
   * 保存对话
   */
  save(chatId, userMessage, assistantResponse, embedding = null) {
    const id = nanoid();
    const embeddingBlob = embedding ? Buffer.from(new Float32Array(embedding).buffer) : null;
    const stmt = db.prepare(`
      INSERT INTO episodes (id, chat_id, user_message, assistant_response, embedding)
      VALUES (?, ?, ?, ?, ?)
    `);
    stmt.run(id, chatId, userMessage, assistantResponse, embeddingBlob);
    return id;
  }

  /**
   * 更新 embedding
   */
  updateEmbedding(id, embedding) {
    const embeddingBlob = Buffer.from(new Float32Array(embedding).buffer);
    const stmt = db.prepare(`
      UPDATE episodes SET embedding = ? WHERE id = ?
    `);
    stmt.run(embeddingBlob, id);
  }

  /**
   * 获取最近的对话
   */
  getRecent(chatId, limit = 20) {
    const stmt = db.prepare(`
      SELECT * FROM episodes
      WHERE chat_id = ?
      ORDER BY created_at DESC
      LIMIT ?
    `);
    return stmt.all(chatId, limit).reverse();
  }

  /**
   * 搜索对话（关键词）
   */
  search(query, limit = 10) {
    const stmt = db.prepare(`
      SELECT * FROM episodes
      WHERE user_message LIKE ? OR assistant_response LIKE ?
      ORDER BY created_at DESC
      LIMIT ?
    `);
    const pattern = `%${query}%`;
    return stmt.all(pattern, pattern, limit);
  }

  /**
   * 向量搜索对话
   */
  searchByVector(embedding, limit = 10) {
    const stmt = db.prepare(`
      SELECT * FROM episodes
      WHERE embedding IS NOT NULL
      ORDER BY created_at DESC
    `);
    const episodes = stmt.all();
    
    // 计算余弦相似度
    const results = episodes.map(ep => {
      if (!ep.embedding) return null;
      // 正确地从 Buffer 恢复 Float32Array
      const buffer = Buffer.isBuffer(ep.embedding) ? ep.embedding : Buffer.from(ep.embedding);
      const epEmbedding = Array.from(new Float32Array(buffer.buffer, buffer.byteOffset, buffer.length / 4));
      const similarity = cosineSimilarity(embedding, epEmbedding);
      return { ...ep, similarity };
    }).filter(r => r !== null && r.similarity > 0.3) // 降低阈值到 0.3
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, limit);
    
    return results;
  }

  /**
   * 获取所有对话
   */
  getAll(limit = 100) {
    const stmt = db.prepare(`
      SELECT * FROM episodes
      ORDER BY created_at DESC
      LIMIT ?
    `);
    return stmt.all(limit);
  }

  /**
   * 删除单条对话
   */
  delete(id) {
    try {
      const stmt = db.prepare('DELETE FROM episodes WHERE id = ?');
      const result = stmt.run(id);
      return result.changes > 0;
    } catch (error) {
      console.error('删除对话失败:', error);
      return false;
    }
  }

  /**
   * 清空所有对话
   */
  clear() {
    try {
      const stmt = db.prepare('DELETE FROM episodes');
      stmt.run();
      console.log('✅ 所有对话已清空');
    } catch (error) {
      console.error('清空对话失败:', error);
    }
  }
}

export default new EpisodeStore();
