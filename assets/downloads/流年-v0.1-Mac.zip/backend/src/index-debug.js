/**
 * 流年 v3.0 - Node.js 后端（调试版本）
 * 完整迁移自 Rust 版本
 */

// 修复 SSL 证书问题（仅开发环境）
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

import express from 'express';
import cors from 'cors';
import { homedir } from 'os';
import { join } from 'path';
import Database from 'better-sqlite3';
import * as Lark from '@larksuiteoapi/node-sdk';
import { CREATE_TABLES } from './database/schema.js';
import { loadConfig, saveConfig, updateConfig } from './config.js';
import { MemorySystem } from './memory/index.js';

// 数据库路径
const DB_FILE = join(homedir(), '.liunian', 'memory.db');

// 初始化数据库
console.log('📁 初始化数据库:', DB_FILE);
const db = new Database(DB_FILE);
db.exec(CREATE_TABLES);
console.log('✅ 数据库已初始化');

// 加载配置
let config = loadConfig();
console.log('⚙️  配置已加载');

// 初始化记忆系统
const memorySystem = new MemorySystem(config);

// Express 应用
const app = express();
app.use(cors());
app.use(express.json());

// ==================== API 路由 ====================

// 健康检查
app.get('/health', (req, res) => res.send('OK'));

// 获取设置
app.get('/api/settings', (req, res) => {
  res.json({
    baseUrl: config.baseUrl,
    model: config.model,
    hasApiKey: !!config.apiKey,
    embeddingModel: config.embeddingModel,
    embeddingBaseUrl: config.embeddingBaseUrl,
    enableEmbedding: config.enableEmbedding !== false,
    maxRecentEpisodes: config.maxRecentEpisodes,
    maxFactsInContext: config.maxFactsInContext,
    enableAutoExtract: config.enableAutoExtract,
    feishu: {
      appId: config.feishu?.appId || '',
      hasSecret: !!config.feishu?.appSecret
    }
  });
});

// 更新设置
app.post('/api/settings', (req, res) => {
  const { baseUrl, apiKey, model, feishuAppId, feishuAppSecret, ...other } = req.body;
  
  if (baseUrl) config.baseUrl = baseUrl;
  if (apiKey) config.apiKey = apiKey;
  if (model) config.model = model;
  
  // 更新其他配置
  Object.assign(config, other);
  
  // 飞书配置
  if (feishuAppId || feishuAppSecret) {
    config.feishu = {
      appId: feishuAppId || config.feishu?.appId || '',
      appSecret: feishuAppSecret || config.feishu?.appSecret || ''
    };
  }
  
  saveConfig(config);
  memorySystem.updateConfig(config);
  
  res.json({ success: true });
});

// 获取模型列表
app.get('/api/models', async (req, res) => {
  try {
    const models = await memorySystem.llm.getModels();
    res.json(models);
  } catch (error) {
    res.json([]);
  }
});

// 聊天接口
app.post('/api/chat', async (req, res) => {
  const { message, chat_id } = req.body;
  
  if (!message || !message.trim()) {
    return res.status(400).json({ error: '消息不能为空' });
  }
  
  try {
    const reply = await memorySystem.chat(chat_id || 'default', message);
    res.json({ response: reply, chat_id: chat_id || 'default' });
  } catch (error) {
    console.error('聊天错误:', error);
    res.status(500).json({ error: error.message });
  }
});

// 记忆搜索
app.get('/api/memory/search', async (req, res) => {
  const { query } = req.query;
  if (!query) {
    return res.status(400).json({ error: '缺少查询参数' });
  }
  
  try {
    const result = await memorySystem.searchMemory(query);
    res.json(result);
  } catch (error) {
    console.error('搜索失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 获取所有记忆
app.get('/api/memory/all', (req, res) => {
  const result = memorySystem.getAllMemory();
  res.json(result);
});

// 添加事实
app.post('/api/memory/fact', (req, res) => {
  const { subject, predicate, object } = req.body;
  if (!subject || !predicate || !object) {
    return res.status(400).json({ error: '缺少参数' });
  }
  
  const id = memorySystem.addFact(subject, predicate, object);
  res.json({ success: true, id });
});

// 获取/更新记忆块
app.get('/api/memory/block/:label', (req, res) => {
  const block = memorySystem.getBlock(req.params.label);
  res.json(block || { error: '不存在' });
});

app.post('/api/memory/block/:label', (req, res) => {
  const { value } = req.body;
  memorySystem.updateBlock(req.params.label, value);
  res.json({ success: true });
});

// 删除单条记忆
app.delete('/api/memory/:id', (req, res) => {
  const { id } = req.params;
  try {
    const success = memorySystem.deleteMemory(id);
    res.json({ success });
  } catch (error) {
    console.error('删除记忆失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 修改单条记忆
app.put('/api/memory/:id', (req, res) => {
  const { id } = req.params;
  const { content, category } = req.body;
  
  try {
    const success = memorySystem.updateMemory(id, content, category);
    res.json({ success });
  } catch (error) {
    console.error('修改记忆失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 手动添加记忆（通用接口）
app.post('/api/memory/add', (req, res) => {
  const { content, category, importance } = req.body;
  
  try {
    const memory = memorySystem.addMemory(content, category, importance);
    res.json(memory);
  } catch (error) {
    console.error('添加记忆失败:', error);
    res.status(500).json({ error: error.message });
  }
});


// 清空所有记忆
app.delete('/api/memory/all', (req, res) => {
  try {
    memorySystem.clearAllMemory();
    res.json({ success: true, message: '所有记忆已清空' });
  } catch (error) {
    console.error('清空记忆失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 飞书状态
app.get('/api/feishu/status', (req, res) => {
  res.json({ status: feishuClient ? 'Running' : 'Stopped' });
});

// 启动飞书
app.post('/api/feishu/start', async (req, res) => {
  try {
    // 重新加载配置（可能前端刚更新了）
    config = loadConfig();
    
    if (!config.feishu?.appId || !config.feishu?.appSecret) {
      return res.status(400).json({ error: '请先配置飞书 App ID 和 Secret' });
    }
    
    if (feishuClient) {
      return res.json({ status: 'Running', message: '飞书已在运行中' });
    }
    
    await startFeishu();
    res.json({ status: 'Running', message: '飞书启动成功' });
  } catch (err) {
    console.error('启动飞书失败:', err);
    res.status(500).json({ error: err.message });
  }
});

// 停止飞书
app.post('/api/feishu/stop', async (req, res) => {
  try {
    if (feishuClient) {
      // Lark SDK 没有提供 stop 方法，只能设为 null
      feishuClient = null;
    }
    res.json({ status: 'Stopped', message: '飞书已停止' });
  } catch (err) {
    console.error('停止飞书失败:', err);
    res.status(500).json({ error: err.message });
  }
});

// ==================== 启动服务器 ====================

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`\n🚀 流年 v3.0 - Node.js 后端`);
  console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
  console.log(`📍 服务地址: http://localhost:${PORT}`);
  console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`);
});

// ==================== 飞书长连接（调试版本）====================

let feishuClient = null;

async function startFeishu() {
  if (!config.feishu?.appId || !config.feishu?.appSecret) {
    console.log('⚠️  飞书未配置，跳过长连接');
    return;
  }
  
  console.log('📡 启动飞书长连接...');
  console.log('   App ID:', config.feishu.appId);
  
  const larkClient = new Lark.Client({
    appId: config.feishu.appId,
    appSecret: config.feishu.appSecret
  });
  
  // 创建事件分发器
  const eventDispatcher = new Lark.EventDispatcher({});
  
  // 注册事件处理器（调试版本，增加日志）
  console.log('🔗 注册事件处理器: im.message.receive_v1');
  
  eventDispatcher.register({
    'im.message.receive_v1': async (data) => {
      console.log('\n🔔 ===== 收到飞书事件 =====');
      console.log('📦 事件类型: im.message.receive_v1');
      console.log('📦 原始数据:', JSON.stringify(data, null, 2));
      
      try {
        const { message } = data;
        console.log('📝 消息类型:', message.message_type);
        
        if (message.message_type !== 'text') {
          console.log('⏭️  跳过非文本消息');
          return;
        }
        
        let text = message.content;
        try {
          const content = JSON.parse(message.content);
          text = content.text || message.content;
        } catch (e) {
          console.log('⚠️  解析消息内容失败:', e.message);
        }
        
        if (!text?.trim()) {
          console.log('⏭️  跳过空消息');
          return;
        }
        
        console.log(`\n📥 飞书消息: ${text}`);
        console.log('💬 Chat ID:', message.chat_id);
        
        // 调用记忆系统聊天
        console.log('🤖 调用记忆系统...');
        const reply = await memorySystem.chat(`feishu_${message.chat_id}`, text);
        console.log('📤 回复内容:', reply.substring(0, 100));
        
        // 发送回复
        console.log('📤 发送回复到飞书...');
        await larkClient.im.v1.message.create({
          params: { receive_id_type: 'chat_id' },
          data: {
            receive_id: message.chat_id,
            msg_type: 'text',
            content: JSON.stringify({ text: reply })
          }
        });
        
        console.log(`✅ 已回复成功`);
      } catch (err) {
        console.error('❌ 处理飞书消息失败:', err);
        console.error('❌ 错误堆栈:', err.stack);
      }
    }
  });
  
  // 创建 WebSocket 客户端
  const wsClient = new Lark.WSClient({
    appId: config.feishu.appId,
    appSecret: config.feishu.appSecret,
    loggerLevel: Lark.LoggerLevel.debug // 改为 debug 级别
  });
  
  // 启动长连接
  console.log('🔌 启动 WebSocket 连接...');
  const result = await wsClient.start({
    eventDispatcher: eventDispatcher
  });
  
  console.log('✅ WebSocket 启动结果:', result);
  
  feishuClient = wsClient;
  console.log('✅ 飞书长连接已建立\n');
}

// 自动启动飞书（如果已配置）
startFeishu().catch(err => {
  console.error('飞书启动失败:', err.message);
  console.error('错误堆栈:', err.stack);
});
