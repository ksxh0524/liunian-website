/**
 * 配置管理
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';
import { homedir } from 'os';

const CONFIG_DIR = join(homedir(), '.liunian');
const CONFIG_FILE = join(CONFIG_DIR, 'config.json');

// 确保目录存在
if (!existsSync(CONFIG_DIR)) {
  mkdirSync(CONFIG_DIR, { recursive: true });
}

// 默认配置
const DEFAULT_CONFIG = {
  baseUrl: 'https://api.n1n.ai',
  apiKey: '',
  model: 'gpt-4o-mini',
  embeddingModel: 'text-embedding-3-small', // 可选: text-embedding-3-small 或 text-embedding-3-large
  embeddingBaseUrl: 'https://api.n1n.ai', // embedding 专用 base URL（默认与 baseUrl 相同）
  enableEmbedding: true, // 启用向量搜索（需要额外 API 调用）
  maxRecentEpisodes: 10,
  maxFactsInContext: 20,
  enableAutoExtract: true,
  feishu: {
    appId: '',
    appSecret: ''
  }
};

/**
 * 加载配置
 */
export function loadConfig() {
  if (existsSync(CONFIG_FILE)) {
    try {
      const saved = JSON.parse(readFileSync(CONFIG_FILE, 'utf-8'));
      return { ...DEFAULT_CONFIG, ...saved };
    } catch (e) {
      console.error('配置加载失败:', e.message);
    }
  }
  return { ...DEFAULT_CONFIG };
}

/**
 * 保存配置
 */
export function saveConfig(config) {
  writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

/**
 * 更新配置
 */
export function updateConfig(updates) {
  const config = loadConfig();
  const newConfig = { ...config, ...updates };
  saveConfig(newConfig);
  return newConfig;
}

export default { loadConfig, saveConfig, updateConfig };
