/**
 * 流年 v3.0 - Node.js 后端
 * 完整迁移自 Rust 版本
 */

// 修复 SSL 证书问题（仅开发环境）
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

import express from 'express';
import cors from 'cors';
import { homedir } from 'os';
import { join } from 'path';
import Database from 'better-sqlite3';
import * as Lark from '@larksuiteoapi/node-sdk';
import { CREATE_TABLES } from './database/schema.js';
import { loadConfig, saveConfig, updateConfig } from './config.js';
import { MemorySystem } from './memory/index.js';

// 数据库路径
const DB_FILE = join(homedir(), '.liunian', 'memory.db');

// 初始化数据库
console.log('📁 初始化数据库:', DB_FILE);
const db = new Database(DB_FILE);
db.exec(CREATE_TABLES);
console.log('✅ 数据库已初始化');

// 加载配置
let config = loadConfig();
console.log('⚙️  配置已加载');

// 初始化记忆系统
const memorySystem = new MemorySystem(config);

// Express 应用
const app = express();
app.use(cors());
app.use(express.json());

// ==================== API 路由 ====================

// 健康检查
app.get('/health', (req, res) => res.send('OK'));

// 获取设置
app.get('/api/settings', (req, res) => {
  res.json({
    baseUrl: config.baseUrl,
    model: config.model,
    hasApiKey: !!config.apiKey,
    embeddingModel: config.embeddingModel,
    embeddingBaseUrl: config.embeddingBaseUrl,
    enableEmbedding: config.enableEmbedding !== false,
    maxRecentEpisodes: config.maxRecentEpisodes,
    maxFactsInContext: config.maxFactsInContext,
    enableAutoExtract: config.enableAutoExtract,
    feishu: {
      appId: config.feishu?.appId || '',
      hasSecret: !!config.feishu?.appSecret
    }
  });
});

// 更新设置
app.post('/api/settings', (req, res) => {
  const { baseUrl, apiKey, model, feishuAppId, feishuAppSecret, ...other } = req.body;
  
  if (baseUrl) config.baseUrl = baseUrl;
  if (apiKey) config.apiKey = apiKey;
  if (model) config.model = model;
  
  // 更新其他配置
  Object.assign(config, other);
  
  // 飞书配置
  if (feishuAppId || feishuAppSecret) {
    config.feishu = {
      appId: feishuAppId || config.feishu?.appId || '',
      appSecret: feishuAppSecret || config.feishu?.appSecret || ''
    };
  }
  
  saveConfig(config);
  memorySystem.updateConfig(config);
  
  res.json({ success: true });
});

// 获取模型列表
app.get('/api/models', async (req, res) => {
  try {
    const models = await memorySystem.llm.getModels();
    res.json(models);
  } catch (error) {
    res.json([]);
  }
});

// 聊天接口
app.post('/api/chat', async (req, res) => {
  const { message, chat_id } = req.body;
  
  if (!message || !message.trim()) {
    return res.status(400).json({ error: '消息不能为空' });
  }
  
  try {
    const reply = await memorySystem.chat(chat_id || 'default', message);
    res.json({ response: reply, chat_id: chat_id || 'default' });
  } catch (error) {
    console.error('聊天错误:', error);
    res.status(500).json({ error: error.message });
  }
});

// 记忆搜索
app.get('/api/memory/search', async (req, res) => {
  const { query } = req.query;
  if (!query) {
    return res.status(400).json({ error: '缺少查询参数' });
  }
  
  try {
    const result = await memorySystem.searchMemory(query);
    res.json(result);
  } catch (error) {
    console.error('搜索失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 获取所有记忆
app.get('/api/memory/all', (req, res) => {
  const result = memorySystem.getAllMemory();
  res.json(result);
});

// 添加事实
app.post('/api/memory/fact', (req, res) => {
  const { subject, predicate, object } = req.body;
  if (!subject || !predicate || !object) {
    return res.status(400).json({ error: '缺少参数' });
  }
  
  const id = memorySystem.addFact(subject, predicate, object);
  res.json({ success: true, id });
});

// 获取/更新记忆块
app.get('/api/memory/block/:label', (req, res) => {
  const block = memorySystem.getBlock(req.params.label);
  res.json(block || { error: '不存在' });
});

app.post('/api/memory/block/:label', (req, res) => {
  const { value } = req.body;
  memorySystem.updateBlock(req.params.label, value);
  res.json({ success: true });
});

// 删除单条记忆
app.delete('/api/memory/:id', (req, res) => {
  const { id } = req.params;
  try {
    const success = memorySystem.deleteMemory(id);
    res.json({ success });
  } catch (error) {
    console.error('删除记忆失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 修改单条记忆
app.put('/api/memory/:id', (req, res) => {
  const { id } = req.params;
  const { content, category } = req.body;
  
  try {
    const success = memorySystem.updateMemory(id, content, category);
    res.json({ success });
  } catch (error) {
    console.error('修改记忆失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 手动添加记忆（通用接口）
app.post('/api/memory/add', (req, res) => {
  const { content, category, importance } = req.body;
  
  try {
    const memory = memorySystem.addMemory(content, category, importance);
    res.json(memory);
  } catch (error) {
    console.error('添加记忆失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 清空所有记忆
app.delete('/api/memory/all', (req, res) => {
  try {
    memorySystem.clearAllMemory();
    res.json({ success: true, message: '所有记忆已清空' });
  } catch (error) {
    console.error('清空记忆失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// ==================== 导出功能 ====================

// 导出为 JSON 格式
app.get('/api/export/json', (req, res) => {
  try {
    const exportData = {
      version: '3.0',
      exportedAt: new Date().toISOString(),
      tables: {}
    };

    // 导出各个表的数据（排除敏感信息）
    const tables = ['episodes', 'facts', 'entities', 'memory_blocks', 'graph_nodes', 'graph_edges', 'feishu_bindings'];

    for (const table of tables) {
      try {
        // 排除 embedding 字段（通常很大）
        let rows;
        if (table === 'episodes' || table === 'facts' || table === 'entities') {
          rows = db.prepare(`SELECT * FROM ${table}`).all().map(row => {
            const { embedding, ...rest } = row;
            return rest;
          });
        } else {
          rows = db.prepare(`SELECT * FROM ${table}`).all();
        }
        exportData.tables[table] = rows;
      } catch (e) {
        console.error(`导出表 ${table} 失败:`, e);
        exportData.tables[table] = [];
      }
    }

    // 设置响应头
    const filename = `liunian-memory-${new Date().toISOString().slice(0, 10)}.json`;
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.json(exportData);
  } catch (error) {
    console.error('导出 JSON 失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 导出为 SQLite 数据库文件
app.get('/api/export/sqlite', async (req, res) => {
  try {
    const { createReadStream, existsSync, statSync } = await import('fs');

    // 读取数据库文件
    const dbPath = DB_FILE;
    if (!existsSync(dbPath)) {
      return res.status(404).json({ error: '数据库文件不存在' });
    }

    const stat = statSync(dbPath);
    const filename = `liunian-memory-${new Date().toISOString().slice(0, 10)}.db`;

    res.setHeader('Content-Type', 'application/x-sqlite3');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Length', stat.size);

    // 创建读取流并管道到响应
    const fileStream = createReadStream(dbPath);
    fileStream.pipe(res);

    fileStream.on('error', (err) => {
      console.error('读取数据库文件失败:', err);
      if (!res.headersSent) {
        res.status(500).json({ error: err.message });
      }
    });
  } catch (error) {
    console.error('导出 SQLite 失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 导出为 Markdown 格式
app.get('/api/export/markdown', (req, res) => {
  try {
    let markdown = `# 流年记忆导出\n\n`;
    markdown += `> 导出时间: ${new Date().toLocaleString('zh-CN')}\n`;
    markdown += `> 版本: 3.0\n\n`;

    // 导出对话历史
    markdown += `## 📜 对话历史\n\n`;
    const episodes = db.prepare('SELECT * FROM episodes ORDER BY created_at DESC').all();
    if (episodes.length > 0) {
      for (const ep of episodes) {
        const date = new Date(ep.created_at).toLocaleString('zh-CN');
        markdown += `### ${date}\n`;
        markdown += `**用户**: ${ep.user_message}\n\n`;
        markdown += `**助手**: ${ep.assistant_response}\n\n`;
        markdown += `---\n\n`;
      }
    } else {
      markdown += `*暂无对话历史*\n\n`;
    }

    // 导出事实
    markdown += `## 📌 事实\n\n`;
    const facts = db.prepare('SELECT * FROM facts ORDER BY created_at DESC').all();
    if (facts.length > 0) {
      for (const fact of facts) {
        markdown += `- **${fact.subject}** ${fact.predicate} **${fact.object}**\n`;
        if (fact.confidence < 1.0) {
          markdown += `  - 置信度: ${(fact.confidence * 100).toFixed(0)}%\n`;
        }
      }
      markdown += `\n`;
    } else {
      markdown += `*暂无事实*\n\n`;
    }

    // 导出实体
    markdown += `## 👤 实体\n\n`;
    const entities = db.prepare('SELECT * FROM entities ORDER BY mention_count DESC').all();
    if (entities.length > 0) {
      for (const entity of entities) {
        markdown += `- **${entity.name}** (${entity.type})`;
        if (entity.summary) {
          markdown += ` - ${entity.summary}`;
        }
        markdown += `\n`;
      }
      markdown += `\n`;
    } else {
      markdown += `*暂无实体*\n\n`;
    }

    // 导出记忆块
    markdown += `## 📦 记忆块\n\n`;
    const blocks = db.prepare('SELECT * FROM memory_blocks ORDER BY priority DESC').all();
    if (blocks.length > 0) {
      for (const block of blocks) {
        markdown += `### ${block.label}\n`;
        markdown += `> ${block.description}\n\n`;
        if (block.value) {
          markdown += `${block.value}\n\n`;
        }
        markdown += `---\n\n`;
      }
    } else {
      markdown += `*暂无记忆块*\n\n`;
    }

    // 设置响应头
    const filename = `liunian-memory-${new Date().toISOString().slice(0, 10)}.md`;
    res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(markdown);
  } catch (error) {
    console.error('导出 Markdown 失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 飞书状态
app.get('/api/feishu/status', (req, res) => {
  res.json({ status: feishuClient ? 'Running' : 'Stopped' });
});

// 飞书绑定 - 检查是否已绑定
app.get('/api/feishu/bindings', (req, res) => {
  try {
    const bindings = db.prepare('SELECT open_id, user_info, bind_at FROM feishu_bindings').all();
    res.json(bindings);
  } catch (error) {
    console.error('查询绑定失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 飞书绑定 - 添加绑定
app.post('/api/feishu/bind', (req, res) => {
  const { open_id, user_info } = req.body;
  
  if (!open_id) {
    return res.status(400).json({ error: '缺少 open_id' });
  }
  
  try {
    const stmt = db.prepare('INSERT OR REPLACE INTO feishu_bindings (open_id, user_info) VALUES (?, ?)');
    stmt.run(open_id, JSON.stringify(user_info || {}));
    res.json({ success: true, message: '绑定成功' });
  } catch (error) {
    console.error('绑定失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 飞书绑定 - 删除绑定
app.delete('/api/feishu/bind/:open_id', (req, res) => {
  const { open_id } = req.params;
  
  try {
    const stmt = db.prepare('DELETE FROM feishu_bindings WHERE open_id = ?');
    stmt.run(open_id);
    res.json({ success: true, message: '解绑成功' });
  } catch (error) {
    console.error('解绑失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 启动飞书
app.post('/api/feishu/start', async (req, res) => {
  try {
    // 重新加载配置（可能前端刚更新了）
    config = loadConfig();
    
    if (!config.feishu?.appId || !config.feishu?.appSecret) {
      return res.status(400).json({ error: '请先配置飞书 App ID 和 Secret' });
    }
    
    if (feishuClient) {
      return res.json({ status: 'Running', message: '飞书已在运行中' });
    }
    
    await startFeishu();
    res.json({ status: 'Running', message: '飞书启动成功' });
  } catch (err) {
    console.error('启动飞书失败:', err);
    res.status(500).json({ error: err.message });
  }
});

// 停止飞书
app.post('/api/feishu/stop', async (req, res) => {
  try {
    if (feishuClient) {
      // Lark SDK 没有提供 stop 方法，只能设为 null
      feishuClient = null;
    }
    res.json({ status: 'Stopped', message: '飞书已停止' });
  } catch (err) {
    console.error('停止飞书失败:', err);
    res.status(500).json({ error: err.message });
  }
});

// ==================== 启动服务器 ====================

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`\n🚀 流年 v3.0 - Node.js 后端`);
  console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
  console.log(`📍 服务地址: http://localhost:${PORT}`);
  console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`);
});

// ==================== 飞书长连接 ====================

let feishuClient = null;

async function startFeishu() {
  if (!config.feishu?.appId || !config.feishu?.appSecret) {
    console.log('⚠️  飞书未配置，跳过长连接');
    return;
  }
  
  console.log('📡 启动飞书长连接...');
  console.log('   App ID:', config.feishu.appId);
  
  const larkClient = new Lark.Client({
    appId: config.feishu.appId,
    appSecret: config.feishu.appSecret
  });
  
  const wsClient = new Lark.WSClient({
    appId: config.feishu.appId,
    appSecret: config.feishu.appSecret,
    loggerLevel: Lark.LoggerLevel.info
  });
  
  wsClient.start({
    eventDispatcher: new Lark.EventDispatcher({}).register({
      'im.message.receive_v1': async (data) => {
        try {
          const { message } = data;
          if (message.message_type !== 'text') return;
          
          let text = message.content;
          try {
            const content = JSON.parse(message.content);
            text = content.text || message.content;
          } catch {}
          
          if (!text?.trim()) return;
          
          // 获取发送者的 open_id
          const senderOpenId = message.sender?.sender_id?.open_id;
          console.log(`\n📥 飞书消息: ${text}`);
          console.log(`👤 发送者 open_id: ${senderOpenId}`);
          
          // 自动绑定（如果第一次发消息）
          let binding = db.prepare('SELECT * FROM feishu_bindings WHERE open_id = ?').get(senderOpenId);
          
          if (!binding) {
            // 第一次发消息，自动绑定
            console.log(`🔗 第一次发消息，自动绑定: ${senderOpenId}`);
            db.prepare('INSERT INTO feishu_bindings (open_id, user_info) VALUES (?, ?)').run(senderOpenId, '{}');
            binding = { open_id: senderOpenId };
          }
          
          console.log(`✅ 用户已绑定: ${senderOpenId}`);
          
          // 调用记忆系统聊天
          const reply = await memorySystem.chat(`feishu_${message.chat_id}`, text);
          
          // 发送回复
          await larkClient.im.v1.message.create({
            params: { receive_id_type: 'chat_id' },
            data: {
              receive_id: message.chat_id,
              msg_type: 'text',
              content: JSON.stringify({ text: reply })
            }
          });
          
          console.log(`📤 已回复: ${reply.substring(0, 50)}...`);
        } catch (err) {
          console.error('处理飞书消息失败:', err);
        }
      }
    })
  });
  
  feishuClient = wsClient;
  console.log('✅ 飞书长连接已建立\n');
}

// 自动启动飞书（如果已配置）
startFeishu().catch(err => {
  console.error('飞书启动失败:', err.message);
});
