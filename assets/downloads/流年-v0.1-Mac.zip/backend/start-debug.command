#!/bin/bash

# 流年后端调试模式启动脚本

cd "$(dirname "$0")"

echo "🐛 启动流年后端（调试模式）..."
echo ""

# 检查是否已有进程在运行
PID=$(lsof -ti:3001)
if [ ! -z "$PID" ]; then
  echo "⚠️  端口 3001 已被占用，正在停止..."
  kill $PID
  sleep 1
fi

# 启动调试版本
NODE_TLS_REJECT_UNAUTHORIZED=0 node src/index-debug.js
