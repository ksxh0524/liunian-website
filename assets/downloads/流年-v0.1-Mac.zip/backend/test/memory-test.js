/**
 * 记忆系统测试脚本
 * 模拟真实用户长时间聊天场景
 */

const API_BASE = 'http://localhost:3001';

// 测试用例
const TEST_CASES = [
  // 第一阶段：建立身份
  { role: 'user', message: '你好，我叫刘洋，是一名独立开发者' },
  { role: 'check', expected: ['刘洋', '独立开发者'] },
  
  { role: 'user', message: '我今年28岁，住在北京' },
  { role: 'check', expected: ['28', '北京'] },
  
  { role: 'user', message: '我的兴趣爱好是编程和玩游戏，特别喜欢Rust语言' },
  { role: 'check', expected: ['编程', '游戏', 'Rust'] },
  
  // 第二阶段：建立关系
  { role: 'user', message: '我有一个大学同学叫小明，我们经常一起打游戏' },
  { role: 'check', expected: ['小明', '同学'] },
  
  { role: 'user', message: '我的合作伙伴张三帮我做技术顾问，他擅长前端' },
  { role: 'check', expected: ['张三', '技术顾问'] },
  
  // 第三阶段：时间和事件
  { role: 'user', message: '我的生日是3月15号，别忘了给我送祝福' },
  { role: 'check', expected: ['3月15', '生日'] },
  
  { role: 'user', message: '流年项目是2026年3月1号启动的' },
  { role: 'check', expected: ['2026', '3月1', '流年'] },
  
  // 第四阶段：偏好和状态
  { role: 'user', message: '我比较喜欢晚上工作，因为比较安静' },
  { role: 'check', expected: ['晚上', '工作'] },
  
  { role: 'user', message: '最近工作压力有点大，心情有些焦虑' },
  { role: 'check', expected: ['压力', '焦虑'] },
  
  // 第五阶段：记忆检索测试
  { role: 'user', message: '你还记得我叫什么名字吗？' },
  { role: 'validate', check: 'name' },
  
  { role: 'user', message: '我多大年纪了？' },
  { role: 'validate', check: 'age' },
  
  { role: 'user', message: '我的生日是什么时候？' },
  { role: 'validate', check: 'birthday' },
  
  { role: 'user', message: '我有哪些朋友？' },
  { role: 'validate', check: 'friends' },
  
  { role: 'user', message: '我最近在做什么项目？' },
  { role: 'validate', check: 'project' },
  
  { role: 'user', message: '我的工作习惯是什么？' },
  { role: 'validate', check: 'work_habit' },
];

// 聊天函数
async function chat(message, chatId) {
  const response = await fetch(`${API_BASE}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message, chat_id: chatId })
  });
  const data = await response.json();
  return data.response;
}

// 检查记忆
async function checkMemory(query) {
  const response = await fetch(`${API_BASE}/api/memory/search?query=${encodeURIComponent(query)}`);
  return await response.json();
}

// 获取所有记忆
async function getAllMemory() {
  const response = await fetch(`${API_BASE}/api/memory/all`);
  return await response.json();
}

// 手动添加事实
async function addFact(subject, predicate, object) {
  const response = await fetch(`${API_BASE}/api/memory/fact`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ subject, predicate, object })
  });
  return await response.json();
}

// 验证回复是否包含关键词
function containsKeywords(response, keywords) {
  const lower = response.toLowerCase();
  return keywords.every(kw => lower.includes(kw.toLowerCase()));
}

// 主测试函数
async function runTests() {
  console.log('========================================');
  console.log('  流年记忆系统测试');
  console.log('========================================\n');
  
  const chatId = `test_${Date.now()}`;
  let testCount = 0;
  let passCount = 0;
  
  console.log(`📋 测试会话 ID: ${chatId}\n`);
  
  for (const testCase of TEST_CASES) {
    if (testCase.role === 'user') {
      // 发送消息
      testCount++;
      console.log(`\n[用户] ${testCase.message}`);
      
      const response = await chat(testCase.message, chatId);
      console.log(`[AI]   ${response.substring(0, 100)}...`);
      
    } else if (testCase.role === 'check') {
      // 检查事实是否被记住
      const memory = await getAllMemory();
      const facts = memory.facts.map(f => `${f.subject} ${f.predicate} ${f.object}`).join(' ');
      const hasAll = testCase.expected.every(kw => 
        facts.toLowerCase().includes(kw.toLowerCase())
      );
      
      if (hasAll) {
        passCount++;
        console.log(`[✅] 记忆检查通过: ${testCase.expected.join(', ')}`);
      } else {
        console.log(`[❌] 记忆检查失败: ${testCase.expected.join(', ')}`);
        console.log(`     当前事实: ${facts.substring(0, 100)}...`);
      }
      
    } else if (testCase.role === 'validate') {
      // 验证回复是否正确
      const lastMessage = TEST_CASES[TEST_CASES.indexOf(testCase) - 1].message;
      const response = await chat(lastMessage, chatId);
      console.log(`[验证] ${response.substring(0, 150)}...`);
    }
    
    // 短暂延迟
    await new Promise(r => setTimeout(r, 500));
  }
  
  // 最终统计
  console.log('\n========================================');
  console.log('  测试结果统计');
  console.log('========================================\n');
  
  const finalMemory = await getAllMemory();
  console.log(`📊 对话历史: ${finalMemory.episodes.length} 条`);
  console.log(`📊 事实存储: ${finalMemory.facts.length} 条`);
  console.log(`📊 实体识别: ${finalMemory.entities.length} 个`);
  
  console.log('\n📝 已存储的事实:');
  finalMemory.facts.slice(0, 10).forEach(f => {
    console.log(`   - ${f.subject} ${f.predicate} ${f.object}`);
  });
  
  // 手动添加记忆测试
  console.log('\n🧪 手动添加记忆测试...');
  await addFact('刘洋', '喜欢', '喝咖啡');
  await addFact('刘洋', '工作时长', '每天8小时');
  
  const afterAdd = await getAllMemory();
  console.log(`   添加后事实数: ${afterAdd.facts.length} 条`);
  
  // 搜索测试
  console.log('\n🔍 搜索测试...');
  const searchResult = await checkMemory('刘洋');
  console.log(`   搜索"刘洋": ${searchResult.facts.length} 条相关事实`);
  
  console.log('\n========================================');
  console.log('  测试完成');
  console.log('========================================\n');
}

// 运行测试
runTests().catch(console.error);
