#!/bin/bash

echo "🔍 流年飞书诊断"
echo "================================"
echo ""

# 1. 检查后端是否运行
echo "1️⃣ 检查后端是否运行..."
if curl -s http://localhost:3001/health > /dev/null; then
  echo "   ✅ 后端运行正常"
else
  echo "   ❌ 后端未运行，请先启动"
  exit 1
fi

echo ""

# 2. 检查飞书配置
echo "2️⃣ 检查飞书配置..."
CONFIG=$(curl -s http://localhost:3001/api/settings | jq -r '.feishu')

if echo "$CONFIG" | jq -e '.appId' > /dev/null 2>&1; then
  APP_ID=$(echo "$CONFIG" | jq -r '.appId')
  HAS_SECRET=$(echo "$CONFIG" | jq -r '.hasSecret')

  echo "   App ID: $APP_ID"
  echo "   已配置 Secret: $HAS_SECRET"

  if [ "$HAS_SECRET" = "true" ]; then
    echo "   ✅ 飞书配置完整"
  else
    echo "   ⚠️  飞书未配置 Secret"
  fi
else
  echo "   ❌ 飞书未配置"
  exit 1
fi

echo ""

# 3. 检查飞书状态
echo "3️⃣ 检查飞书长连接状态..."
STATUS=$(curl -s http://localhost:3001/api/feishu/status | jq -r '.status')
echo "   状态: $STATUS"

if [ "$STATUS" = "Running" ]; then
  echo "   ✅ 飞书长连接已建立"
else
  echo "   ❌ 飞书长连接未建立"
fi

echo ""

# 4. 检查绑定
echo "4️⃣ 检查飞书绑定..."
BINDINGS=$(curl -s http://localhost:3001/api/feishu/bindings | jq -r '.')
if [ "$BINDINGS" = "[]" ]; then
  echo "   ⚠️  还没有绑定用户"
  echo "   提示: 给机器人发一条消息后会自动绑定"
else
  echo "   已绑定用户:"
  echo "$BINDINGS" | jq -r '.[] | "   - open_id: \(.open_id)"'
fi

echo ""

# 5. 检查日志
echo "5️⃣ 检查最近的日志..."
echo "   最近 10 行日志:"
tail -10 ~/codes/liunian/backend.log | sed 's/^/   /'

echo ""
echo "================================"
echo "✅ 诊断完成"
echo ""
echo "📋 下一步检查："
echo ""
echo "1. 登录飞书开发者后台: https://open.feishu.cn/app"
echo "2. 找到你的应用（App ID: $APP_ID）"
echo "3. 检查以下配置："
echo "   - 事件订阅 → 是否启用了 'im.message.receive_v1' 事件"
echo "   - 权限管理 → 是否有 'im:message:receive_as_bot' 权限"
echo "   - 应用发布 → 是否已发布到企业"
echo ""
