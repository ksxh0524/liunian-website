#!/bin/bash
# Mac/Linux 一键启动（优先使用系统 Node.js）

cd "$(dirname "$0")"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "🚀 启动流年 v0.1..."
echo ""

# 优先使用系统 Node.js（v22+）
SYSTEM_NODE=""
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -ge 22 ]; then
        SYSTEM_NODE="true"
        echo "✅ 使用系统 Node.js ($(node --version))"
    fi
fi

# 如果系统 Node.js 不合适，使用虚拟环境
if [ -z "$SYSTEM_NODE" ]; then
    if [ -d "./node" ]; then
        export PATH="./node/bin:$PATH"
        echo "✅ 使用虚拟环境中的 Node.js ($(node --version))"
    else
        echo "❌ 未找到合适的 Node.js（需要 v22+）"
        echo "正在自动安装..."
        ./install.sh
        if [ $? -ne 0 ]; then
            echo "❌ 安装失败"
            read -p "按回车键退出..."
            exit 1
        fi
        export PATH="./node/bin:$PATH"
    fi
fi

# 检查依赖
if ! command -v node &> /dev/null; then
    echo "❌ Node.js 未安装（异常情况）"
    read -p "按回车键退出..."
    exit 1
fi

echo "Node.js 版本: $(node --version)"
echo "npm 版本: $(npm --version)"
echo ""

# 检查端口是否被占用
if lsof -i :3001 > /dev/null 2>&1; then
    echo "⚠️  端口 3001 已被占用"
    echo "请先关闭其他服务，或运行 'stop.command'"
    read -p "按回车键退出..."
    exit 1
fi

# 检查依赖是否已安装
if [ ! -d "backend/node_modules" ] || [ ! -d "node_modules" ]; then
    echo "⚠️  依赖未安装，正在自动安装..."
    ./install.sh
    if [ $? -ne 0 ]; then
        echo "❌ 依赖安装失败"
        read -p "按回车键退出..."
        exit 1
    fi
else
    # 检查原生模块是否需要重新编译
    if [ -f "backend/node_modules/better-sqlite3/build/Release/better_sqlite3.node" ]; then
        echo "🔧 检查原生模块兼容性..."
        cd backend
        if ! node -e "require('better-sqlite3')" 2>/dev/null; then
            echo "⚠️  原生模块需要重新编译..."
            npm rebuild better-sqlite3
            if [ $? -ne 0 ]; then
                echo "❌ 原生模块编译失败"
                read -p "按回车键退出..."
                exit 1
            fi
            echo "✅ 原生模块重新编译完成"
        fi
        cd ..
    fi
fi

# 创建日志目录
mkdir -p ~/.liunian/logs

# 启动后端（日志输出到控制台和文件）
echo "🔧 启动后端服务..."
cd backend
if [ -n "$SYSTEM_NODE" ]; then
    # 使用系统 Node.js
    node src/index.js 2>&1 | tee ~/.liunian/logs/backend.log &
else
    # 使用虚拟环境 Node.js
    "$SCRIPT_DIR/node/bin/node" src/index.js 2>&1 | tee ~/.liunian/logs/backend.log &
fi
SERVER_PID=$!
cd ..

# 等待后端启动（最多 30 秒）
echo "⏳ 等待后端启动..."
for i in {1..30}; do
    if curl -s http://localhost:3001/health > /dev/null 2>&1; then
        echo "✅ 后端已启动 (http://localhost:3001)"
        break
    fi
    if [ $i -eq 30 ]; then
        echo "❌ 后端启动超时"
        echo "查看日志: cat ~/.liunian/logs/backend.log"
        kill $SERVER_PID 2>/dev/null
        read -p "按回车键退出..."
        exit 1
    fi
    sleep 1
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  流年 v0.1 已启动"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📍 访问: http://localhost:5999"
echo "📋 日志: ~/.liunian/logs/backend.log"
echo ""
echo "💡 按 Ctrl+C 停止服务"
echo ""

# 打开浏览器（静默）
open http://localhost:5999 2>/dev/null || true

# 启动前端（后台）
if [ -n "$SYSTEM_NODE" ]; then
    # 使用系统 Node.js
    npm run dev &
else
    # 使用虚拟环境 Node.js
    "$SCRIPT_DIR/node/bin/npm" run dev &
fi
FRONTEND_PID=$!

# 持续输出后端日志
tail -f ~/.liunian/logs/backend.log &

# 等待前端进程
wait $FRONTEND_PID
