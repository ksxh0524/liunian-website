#!/bin/bash

# 流年 v0.1 - 安装脚本
# 自动下载并配置 Node.js 虚拟环境

set -e

# 颜色定义
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_section() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# ========================================
# 国内镜像加速配置（自动切换）
# ========================================
# Node.js 镜像（淘宝）
NODE_MIRROR="https://npmmirror.com/mirrors/node"

# npm 镜像（淘宝）
NPM_REGISTRY="https://registry.npmmirror.com"

# 检测当前系统
OS=$(uname -s)
ARCH=$(uname -m)

print_info "当前系统: $OS $ARCH"
echo ""

# Node.js 版本（使用 LTS 20.19.0 以满足依赖要求）
NODE_VERSION="20.19.0"

# 根据系统选择下载链接
if [ "$OS" = "Darwin" ]; then
    if [ "$ARCH" = "arm64" ]; then
        NODE_FILE="node-v${NODE_VERSION}-darwin-arm64.tar.gz"
        NODE_DIR="node-v${NODE_VERSION}-darwin-arm64"
    else
        NODE_FILE="node-v${NODE_VERSION}-darwin-x64.tar.gz"
        NODE_DIR="node-v${NODE_VERSION}-darwin-x64"
    fi
elif [ "$OS" = "Linux" ]; then
    NODE_FILE="node-v${NODE_VERSION}-linux-x64.tar.gz"
    NODE_DIR="node-v${NODE_VERSION}-linux-x64"
else
    print_error "不支持的操作系统: $OS"
    exit 1
fi

# 选择镜像源
if [ "$USE_CHINA_MIRROR" = "true" ]; then
    NODE_URL="${NODE_MIRROR}/v${NODE_VERSION}/${NODE_FILE}"
else
    NODE_URL="https://nodejs.org/dist/v${NODE_VERSION}/${NODE_FILE}"
fi

print_section "步骤 1/4: 下载 Node.js"

# 创建临时目录
TEMP_DIR="$SCRIPT_DIR/.temp"
mkdir -p "$TEMP_DIR"

# 下载 Node.js
NODE_ARCHIVE="$TEMP_DIR/node.tar.gz"

if [ -d "$SCRIPT_DIR/node" ]; then
    print_info "Node.js 虚拟环境已存在，跳过下载"
else
    print_info "下载 Node.js v${NODE_VERSION}..."
    
    # 先尝试官方源
    OFFICIAL_URL="https://nodejs.org/dist/v${NODE_VERSION}/${NODE_FILE}"
    CHINA_MIRROR_URL="${NODE_MIRROR}/v${NODE_VERSION}/${NODE_FILE}"
    
    print_info "尝试官方源: $OFFICIAL_URL"
    if curl -L --connect-timeout 10 --max-time 60 -o "$NODE_ARCHIVE" "$OFFICIAL_URL" 2>/dev/null; then
        print_info "✅ 官方源下载成功"
        NODE_URL="$OFFICIAL_URL"
    else
        print_warning "官方源下载失败，切换到淘宝镜像"
        print_info "镜像源: $CHINA_MIRROR_URL"
        if curl -L -o "$NODE_ARCHIVE" "$CHINA_MIRROR_URL"; then
            print_info "✅ 淘宝镜像下载成功"
            NODE_URL="$CHINA_MIRROR_URL"
        else
            print_error "所有下载源都失败，请检查网络连接"
            exit 1
        fi
    fi
    
    print_info "解压 Node.js..."
    tar -xzf "$NODE_ARCHIVE" -C "$TEMP_DIR"
    
    # 重命名为 node
    mv "$TEMP_DIR/$NODE_DIR" "$SCRIPT_DIR/node"
    
    print_info "✅ Node.js 安装完成"
fi

# 设置 Node.js 路径
NODE_BIN="$SCRIPT_DIR/node/bin"
export PATH="$NODE_BIN:$PATH"

print_section "步骤 2/4: 安装前端依赖"

# 检查关键依赖是否存在
check_frontend_deps() {
    [ -d "node_modules/vitest" ] && \
    [ -d "node_modules/@testing-library" ] && \
    [ -d "node_modules/@tauri-apps" ]
}

if [ -d "node_modules" ] && check_frontend_deps; then
    print_info "前端依赖已存在且完整，跳过安装"
else
    if [ -d "node_modules" ]; then
        print_warning "检测到依赖不完整，重新安装..."
        rm -rf node_modules package-lock.json
    fi
    print_info "安装前端依赖..."
    
    # 使用国内镜像（如果官方源失败）
    if npm install 2>&1 | grep -q "ETIMEDOUT\|ENOTFOUND"; then
        print_warning "官方源失败，切换到淘宝镜像"
        npm install --registry="$NPM_REGISTRY"
    else
        npm install
    fi
    
    print_info "✅ 前端依赖安装完成"
fi

print_section "步骤 3/4: 安装后端依赖"

# 检查后端依赖是否存在
check_backend_deps() {
    [ -d "backend/node_modules/express" ] && \
    [ -d "backend/node_modules/cors" ]
}

if [ -d "backend/node_modules" ] && check_backend_deps; then
    print_info "后端依赖已存在且完整，跳过安装"
else
    if [ -d "backend/node_modules" ]; then
        print_warning "检测到后端依赖不完整，重新安装..."
        rm -rf backend/node_modules backend/package-lock.json
    fi
    print_info "安装后端依赖..."
    cd backend
    
    # 使用国内镜像（如果官方源失败）
    if npm install 2>&1 | grep -q "ETIMEDOUT\|ENOTFOUND"; then
        print_warning "官方源失败，切换到淘宝镜像"
        npm install --registry="$NPM_REGISTRY"
    else
        npm install
    fi
    
    cd ..
    print_info "✅ 后端依赖安装完成"
fi

print_section "步骤 4/4: 构建前端"

if [ -d "dist" ]; then
    print_info "前端已构建，跳过"
else
    print_info "构建前端..."
    npm run build
    print_info "✅ 前端构建完成"
fi

# 清理临时文件
rm -rf "$TEMP_DIR"

echo ""
print_section "安装完成！"
echo ""
echo "🚀 启动方法:"
echo "   Mac: 双击 start.command"
echo "   或运行: ./start.sh"
echo ""
echo "📍 访问地址: http://localhost:5999"
echo ""
print_info "Node.js 虚拟环境位置: $SCRIPT_DIR/node"
print_info "Node.js 版本: $(node --version)"
print_info "npm 版本: $(npm --version)"
