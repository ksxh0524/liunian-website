# 🍡 流年 v3.0

**轻量级 AI 聊天 + 记忆系统**

---

## 🚀 快速开始

### 启动

**Mac**: 双击 `start.command`

**Windows**: 双击 `start.bat`

### 关闭

**Mac**: 双击 `stop.command`

**Windows**: 双击 `stop.bat`

---

## 📍 访问地址

启动后浏览器会自动打开：http://localhost:5999

---

## ⚙️ 首次配置

编辑 `config/config.json`，填入 API Key：

```json
{
  "api_key": "your-api-key-here",
  "default_model": "gpt-4o-mini"
}
```

---

## 📖 功能

- ✅ 智能聊天
- ✅ 记忆管理
- ✅ OpenClaw 集成
- ✅ 飞书机器人

---

## ❓ 常见问题

**Q: 浏览器没打开？**
A: 手动访问 http://localhost:5999

**Q: 如何确认运行？**
A: 访问 http://localhost:3001/health

---

**版本**: v3.0
