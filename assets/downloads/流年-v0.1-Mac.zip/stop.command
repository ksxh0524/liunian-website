#!/bin/bash
# Mac/Linux 一键关闭

cd "$(dirname "$0")"

echo "🛑 停止流年 v3.0..."
echo ""

# 停止后端（端口 3001）
BACKEND_PIDS=$(lsof -ti:3001 2>/dev/null || true)
if [ ! -z "$BACKEND_PIDS" ]; then
    echo "停止后端..."
    echo "$BACKEND_PIDS" | xargs kill -9 2>/dev/null || true
    echo "✅ 后端已停止"
else
    echo "⚠️  后端未运行"
fi

# 停止前端（端口 5999）
FRONTEND_PIDS=$(lsof -ti:5999 2>/dev/null || true)
if [ ! -z "$FRONTEND_PIDS" ]; then
    echo "停止前端..."
    echo "$FRONTEND_PIDS" | xargs kill -9 2>/dev/null || true
    echo "✅ 前端已停止"
else
    echo "⚠️  前端未运行"
fi

# 清理可能的僵尸进程
pkill -f "node.*liunian.*index.js" 2>/dev/null || true
pkill -f "vite.*5999" 2>/dev/null || true

echo ""
echo "✅ 流年已停止"
echo ""
