@echo off
REM 流年 v0.1 启动脚本 (Windows)
REM 使用虚拟环境中的 Node.js

echo 🚀 启动流年 v0.1...
echo.

REM 获取脚本所在目录
set SCRIPT_DIR=%~dp0
cd /d "%SCRIPT_DIR%"

REM 检查虚拟环境
if exist "%SCRIPT_DIR%node" (
    set PATH=%SCRIPT_DIR%node;%SCRIPT_DIR%node\bin;%PATH%
    echo ✅ 使用虚拟环境中的 Node.js
) else (
    echo ❌ 虚拟环境未安装
    echo 正在自动安装...
    call install.bat
    if %ERRORLEVEL% neq 0 (
        echo ❌ 安装失败
        pause
        exit /b 1
    )
    set PATH=%SCRIPT_DIR%node;%SCRIPT_DIR%node\bin;%PATH%
)

REM 检查 Node.js 是否可用
where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo ❌ 错误: 未找到 Node.js（异常情况）
    echo 虚拟环境应该已安装，但 Node.js 不可用
    pause
    exit /b 1
)

REM 显示版本
echo Node.js 版本:
node --version
echo npm 版本:
npm --version
echo.

REM 创建日志目录
if not exist "%USERPROFILE%\.liunian\logs" mkdir "%USERPROFILE%\.liunian\logs"

REM 检查依赖是否已安装
if not exist "backend\node_modules" (
    echo ⚠️  依赖未安装，正在自动安装...
    call install.bat
    if %ERRORLEVEL% neq 0 (
        echo ❌ 依赖安装失败
        pause
        exit /b 1
    )
) else (
    REM 检查原生模块是否需要重新编译
    if exist "backend\node_modules\better-sqlite3\build\Release\better_sqlite3.node" (
        echo 🔧 检查原生模块兼容性...
        cd backend
        node -e "require('better-sqlite3')" 2>nul
        if %ERRORLEVEL% neq 0 (
            echo ⚠️  原生模块需要重新编译...
            call npm rebuild better-sqlite3
            if %ERRORLEVEL% neq 0 (
                echo ❌ 原生模块编译失败
                pause
                exit /b 1
            )
            echo ✅ 原生模块重新编译完成
        )
        cd ..
    )
)

if not exist "node_modules" (
    echo ⚠️  依赖未安装，正在自动安装...
    call install.bat
    if %ERRORLEVEL% neq 0 (
        echo ❌ 依赖安装失败
        pause
        exit /b 1
    )
)

REM 检查前端是否已构建
if not exist "dist" (
    echo ⚠️  前端未构建，正在构建...
    call npm run build
)

REM 启动 Node.js 后端
echo 🔧 启动后端服务...
cd backend
start /B node src\index.js > "%USERPROFILE%\.liunian\logs\backend.log" 2>&1
cd ..

REM 等待服务启动
timeout /t 2 /nobreak >nul

REM 检查服务（Windows 下使用 PowerShell）
powershell -Command "try { Invoke-WebRequest -Uri 'http://localhost:3001/health' -UseBasicParsing -TimeoutSec 2 | Out-Null; Write-Host '✅ 后端服务已启动' } catch { Write-Host '⚠️  后端服务启动中...' }"

echo.
echo ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
echo 📍 后端 API: http://localhost:3001
echo 📍 前端界面: http://localhost:5999
echo ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
echo.
echo 💡 提示: 按 Ctrl+C 停止服务
echo.

REM 持续输出日志
echo 正在输出日志（按 Ctrl+C 退出）...
echo.
type "%USERPROFILE%\.liunian\logs\backend.log"

REM 持续监控日志文件（类似 tail -f）
:loop
timeout /t 1 /nobreak >nul
powershell -Command "Get-Content '%USERPROFILE%\.liunian\logs\backend.log' -Tail 10 -Wait"
goto loop
