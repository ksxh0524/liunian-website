@echo off
REM 流年 v0.1 - 安装脚本 (Windows)
REM 自动下载并配置 Node.js 虚拟环境

setlocal enabledelayedexpansion

echo ========================================
echo   流年 v0.1 - 自动安装
echo ========================================
echo.

REM 获取脚本所在目录
set SCRIPT_DIR=%~dp0
cd /d "%SCRIPT_DIR%"

REM 检测系统架构
if "%PROCESSOR_ARCHITECTURE%"=="AMD64" (
    set ARCH=x64
) else (
    set ARCH=x86
)

echo [INFO] 当前系统: Windows %ARCH%
echo.

REM Node.js 版本
set NODE_VERSION=20.11.0
set NODE_MIRROR=https://npmmirror.com/mirrors/node
set NPM_REGISTRY=https://registry.npmmirror.com

echo ========================================
echo   步骤 1/4: 下载 Node.js
echo ========================================

REM 创建临时目录
set TEMP_DIR=%SCRIPT_DIR%.temp
if not exist "%TEMP_DIR%" mkdir "%TEMP_DIR%"

REM 检查 Node.js 虚拟环境是否已存在
if exist "%SCRIPT_DIR%node" (
    echo [INFO] Node.js 虚拟环境已存在，跳过下载
) else (
    echo [INFO] 下载 Node.js v%NODE_VERSION%...
    
    REM 先尝试官方源
    set OFFICIAL_URL=https://nodejs.org/dist/v%NODE_VERSION%/node-v%NODE_VERSION%-win-%ARCH%.zip
    set CHINA_URL=%NODE_MIRROR%/v%NODE_VERSION%/node-v%NODE_VERSION%-win-%ARCH%.zip
    set NODE_ARCHIVE=%TEMP_DIR%\node.zip
    
    echo [INFO] 尝试官方源...
    curl -L --connect-timeout 10 --max-time 60 -o "%NODE_ARCHIVE%" "%OFFICIAL_URL%"
    
    REM 检查是否下载成功（文件大小 > 1MB）
    for %%A in ("%NODE_ARCHIVE%") do set FILE_SIZE=%%~zA
    if %FILE_SIZE% LSS 1000000 (
        echo [WARNING] 官方源下载失败，切换到淘宝镜像
        curl -L -o "%NODE_ARCHIVE%" "%CHINA_URL%"
    ) else (
        echo [INFO] ✅ 官方源下载成功
    )
    
    echo [INFO] 解压 Node.js...
    
    REM 使用 PowerShell 解压（Windows 自带）
    powershell -Command "Expand-Archive -Path '%NODE_ARCHIVE%' -DestinationPath '%TEMP_DIR%' -Force"
    
    REM 重命名为 node
    set NODE_DIR=node-v%NODE_VERSION%-win-%ARCH%
    move "%TEMP_DIR%\%NODE_DIR%" "%SCRIPT_DIR%node"
    
    echo [INFO] ✅ Node.js 安装完成
)

REM 设置 Node.js 路径
set PATH=%SCRIPT_DIR%node;%SCRIPT_DIR%node\bin;%PATH%

echo ========================================
echo   步骤 2/4: 安装前端依赖
echo ========================================

if exist "node_modules" (
    echo [INFO] 前端依赖已存在，跳过安装
) else (
    echo [INFO] 安装前端依赖...
    npm install 2>&1 | findstr /C:"ETIMEDOUT" /C:"ENOTFOUND" >nul
    if %ERRORLEVEL% equ 0 (
        echo [WARNING] 官方源失败，切换到淘宝镜像
        npm install --registry=%NPM_REGISTRY%
    ) else (
        npm install
    )
    echo [INFO] ✅ 前端依赖安装完成
)

echo ========================================
echo   步骤 3/4: 安装后端依赖
echo ========================================

if exist "backend\node_modules" (
    echo [INFO] 后端依赖已存在，跳过安装
) else (
    echo [INFO] 安装后端依赖...
    cd backend
    npm install 2>&1 | findstr /C:"ETIMEDOUT" /C:"ENOTFOUND" >nul
    if %ERRORLEVEL% equ 0 (
        echo [WARNING] 官方源失败，切换到淘宝镜像
        npm install --registry=%NPM_REGISTRY%
    ) else (
        npm install
    )
    cd ..
    echo [INFO] ✅ 后端依赖安装完成
)

echo ========================================
echo   步骤 4/4: 构建前端
echo ========================================

if exist "dist" (
    echo [INFO] 前端已构建，跳过
) else (
    echo [INFO] 构建前端...
    call npm run build
    echo [INFO] ✅ 前端构建完成
)

REM 清理临时文件
if exist "%TEMP_DIR%" rd /s /q "%TEMP_DIR%"

echo.
echo ========================================
echo   安装完成！
echo ========================================
echo.
echo 🚀 启动方法:
echo    Windows: 双击 start.bat
echo    或运行: start.bat
echo.
echo 📍 访问地址: http://localhost:5999
echo.
echo [INFO] Node.js 虚拟环境位置: %SCRIPT_DIR%node

REM 显示版本
node --version
npm --version

echo.
echo 按任意键退出...
pause >nul
