@echo off
chcp 65001 >nul
REM Windows 一键关闭

echo ========================================
echo   流年 v0.1 关闭中...
echo ========================================
echo.

REM 关闭后端（Node.js 进程）
echo 🔧 关闭后端...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":3001"') do (
    taskkill /F /PID %%a >nul 2>nul
)

REM 关闭前端（Vite 进程）
echo 🎨 关闭前端...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":5999"') do (
    taskkill /F /PID %%a >nul 2>nul
)

REM 关闭所有 node.exe 进程（可选，更彻底）
REM taskkill /F /IM node.exe >nul 2>nul

echo.
echo ✅ 流年已关闭
echo.
pause
